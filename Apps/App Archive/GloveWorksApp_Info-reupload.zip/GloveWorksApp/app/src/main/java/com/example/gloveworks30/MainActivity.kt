package com.example.gloveworks30

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gloveworks30.ui.theme.Gloveworks30Theme
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.jtransforms.fft.DoubleFFT_1D
import java.nio.charset.Charset
import java.util.UUID
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt
import android.os.SystemClock
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.layout.offset




class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)


        setContent {
            Gloveworks30Theme {
                val navController = rememberNavController()
                val userInfoViewModel: UserInfoViewModel = viewModel()

                val context = LocalContext.current
                var startDestination by remember { mutableStateOf<String?>(null) }

                LaunchedEffect(Unit) {
                    val sharedPref = context.getSharedPreferences(
                        "gloveworks_prefs",
                        Context.MODE_PRIVATE
                    )
                    val userId = sharedPref.getString("user_id", null)

                    startDestination = if (userId == null) "onboarding" else "home"
                }

                if (startDestination != null) {
                    NavHost(navController = navController, startDestination = startDestination!!) {
                        composable("onboarding") {
                            OnboardingScreen(
                                onComplete = {
                                    navController.navigate("home") {
                                        popUpTo("onboarding") { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable("home") { HomeScreen(navController) }
                        composable("main") { MainScreen(navController, userInfoViewModel) }
                        composable("voice") { VoiceScreen(navController) }
                        composable("settings") { SettingsScreen(navController) }
                        composable("user_info") { UserInfoScreen(navController) }
                        composable("glove_control") { GloveControlScreen(navController) }
                        composable("symptom_tracker") { SymptomTrackerScreen(navController) }
                        composable("symptom_medication") { MedicationsScreen(navController) }
                        composable("Medication_history") { MedicationsHistoryScreen(navController) }
                        composable("symptom_lifestyle") {
                            SymptomQuestionScreen(
                                title = "Lifestyle",
                                questions = placeholderLifestyleQuestions(),
                                navController = navController
                            )
                        }

                        composable("symptom_physical") {
                            SymptomQuestionScreen(
                                title = "Physical",
                                questions = placeholderPhysicalQuestions(),
                                navController = navController
                            )
                        }

                        composable("symptom_psychological") {
                            SymptomQuestionScreen(
                                title = "Psychological",
                                questions = placeholderPsychologicalQuestions(),
                                navController = navController
                            )
                        }

                        composable("about") {
                            AboutScreen(navController)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OnboardingScreen(onComplete: () -> Unit) {
    var isGloveWorksMember by remember { mutableStateOf<Boolean?>(null) }

    // Participant form
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    val pdqResponses = remember { mutableStateListOf<Int>().apply { repeat(8) { add(0) } } }

    // Anonymous form
    var shareMotion by remember { mutableStateOf(false) }
    var shareVoice by remember { mutableStateOf(false) }
    var age by remember { mutableStateOf("") }
    var diagnosedPD by remember { mutableStateOf(false) }

    val context = LocalContext.current

    Scaffold(
        bottomBar = {
            if (isGloveWorksMember != null) {
                BottomAppBar {
                    Spacer(modifier = Modifier.weight(1f))
                    Button(onClick = {
                        firstName = ""
                        lastName = ""
                        email = ""
                        dob = ""
                        phone = ""
                        pdqResponses.forEachIndexed { index, _ -> pdqResponses[index] = 0 }
                        shareMotion = false
                        shareVoice = false
                        age = ""
                        diagnosedPD = false
                        isGloveWorksMember = null
                    }) {
                        Text("Back")
                    }
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Welcome to GloveWorks", style = MaterialTheme.typography.headlineSmall)
            if (isGloveWorksMember == null) {
                Text("Are you a participant in the GloveWorks research project?")
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Button(onClick = { isGloveWorksMember = true }) {
                        Text("Yes")
                    }
                    Button(onClick = { isGloveWorksMember = false }) {
                        Text("No")
                    }
                }
            } else if (isGloveWorksMember == true) {
                val context = LocalContext.current
                var firstName by remember { mutableStateOf("") }
                var lastName by remember { mutableStateOf("") }
                var email by remember { mutableStateOf("") }
                var dob by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                val pdqResponses = remember { mutableStateListOf<Int>() }
                val pdqQuestions = listOf(
                    "1. Difficulty carrying out daily activities (e.g., getting dressed)?",
                    "2. Trouble walking short distances?",
                    "3. Difficulty keeping balance or falling over?",
                    "4. Difficulty with handwriting or using utensils?",
                    "5. Emotional well-being affected (e.g., feeling depressed)?",
                    "6. Difficulty speaking clearly?",
                    "7. Experiencing bodily discomfort (pain, cramps, etc.)?",
                    "8. Feeling isolated from others due to your condition?"
                )
                val pdqOptions = listOf("Never", "Occasionally", "Sometimes", "Often", "Always")
                if (pdqResponses.size < pdqQuestions.size) {
                    pdqResponses.addAll(List(pdqQuestions.size) { 0 })
                }
                val isFormValid = firstName.isNotBlank() &&
                        lastName.isNotBlank() &&
                        email.isNotBlank() &&
                        dob.isNotBlank() &&
                        phone.isNotBlank() &&
                        pdqResponses.none { it == 0 }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        "GloveWorks Participant Info",
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedTextField(value = firstName,
                        onValueChange = { firstName = it }, label = { Text("First Name") })
                    OutlinedTextField(value = lastName,
                        onValueChange = { lastName = it }, label = { Text("Last Name") })
                    OutlinedTextField(value = email,
                        onValueChange = { email = it }, label = { Text("Email") })
                    OutlinedTextField(value = dob,
                        onValueChange = { dob = it },
                        label = { Text("Date of Birth, please use the MM/DD/YYYY format.") })
                    OutlinedTextField(value = phone,
                        onValueChange = { phone = it }, label = { Text("Phone") })
                    Text("Parkinson’s Questionnaire", style = MaterialTheme.typography.titleMedium)
                    pdqQuestions.forEachIndexed { index, question ->
                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            Text(question, style = MaterialTheme.typography.bodyMedium)
                            Column {
                                pdqOptions.forEachIndexed { optIndex, label ->
                                    OutlinedButton(
                                        onClick = { pdqResponses[index] = optIndex + 1 },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (pdqResponses[index] == optIndex + 1)
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                            else Color.Transparent
                                        )
                                    ) {
                                        Text(label)
                                    }
                                }
                            }
                        }
                    }
                    if (!isFormValid) {
                        Text(
                            text = "Please complete all fields and answer all questions.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val userId = generateUserId(
                                isAnonymous = false,
                                firstName = firstName.lowercase(),
                                lastName = lastName.lowercase(),
                                dob = dob
                            )
                            val sharedPref = context.getSharedPreferences(
                                "gloveworks_prefs",
                                Context.MODE_PRIVATE
                            )
                            with(sharedPref.edit()) {
                                putString("user_id", userId)
                                putString("type", "gloveworks")
                                putString("name", firstName)
                                putString("lastName", lastName)
                                putString("email", email)
                                putString("dob", dob)
                                putString("phone", phone)
                                putString("pdq", pdqResponses.joinToString(","))
                                putBoolean("share_motion", true)
                                putBoolean("share_voice", true)
                                apply()
                            }
                            val userMap = mapOf(
                                "type" to "gloveworks",
                                "consent" to true,
                                "profile" to mapOf(
                                    "name" to firstName,
                                    "lastName" to lastName,
                                    "email" to email,
                                    "dob" to dob,
                                    "phone" to phone
                                ),
                                "pdq" to pdqResponses.toList()
                            )
                            uploadUserInfoToFirebase(context, userMap)
                            onComplete()
                        }) {
                        Text("Submit")
                    }
                }
            } else {
                Text("Anonymous Consent", style = MaterialTheme.typography.titleMedium)

                Text(
                    "Please click buttons below to choose the type of anonymous" +
                            " data you would like to share."
                )
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Button(onClick = { shareMotion = !shareMotion }) {
                        Text(if (shareMotion) "✓ Motion" else "Motion")
                    }
                    Button(onClick = { shareVoice = !shareVoice }) {
                        Text(if (shareVoice) "✓ Voice" else "Voice")
                    }
                }
                OutlinedTextField(value = age, onValueChange = { age = it },
                    label = { Text("Your Age (optional)") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = diagnosedPD, onCheckedChange = { diagnosedPD = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Diagnosed with Parkinson’s?")
                }
                Button(onClick = {
                    val userId = generateUserId(isAnonymous = true)
                    val sharedPref = context.getSharedPreferences(
                        "gloveworks_prefs",
                        Context.MODE_PRIVATE
                    )
                    with(sharedPref.edit()) {
                        putString("user_id", userId)
                        putString("type", "anonymous")
                        putBoolean("share_motion", shareMotion)
                        putBoolean("share_voice", shareVoice)
                        putString("age", age)
                        putBoolean("diagnosedWithPD", diagnosedPD)
                        apply()
                    }
                    val anonMap = mapOf(
                        "type" to "anonymous",
                        "consent" to mapOf(
                            "motion" to shareMotion,
                            "voice" to shareVoice
                        ),
                        "profile" to mapOf(
                            "age" to age,
                            "diagnosedWithPD" to diagnosedPD
                        )
                    )
                    uploadUserInfoToFirebase(context, anonMap)
                    onComplete()
                }) {
                    Text("Submit")
                }
            }
        }
    }
}

@Composable
fun RealTimeGraph(sensorData: List<Pair<Float, Float>>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.primary.toArgb()
    AndroidView(
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                setTouchEnabled(false)
                isDragEnabled = false
                setScaleEnabled(false)
                setPinchZoom(false)
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setViewPortOffsets(0f, 0f, 0f, 0f)
                xAxis.apply {
                    isEnabled = false
                    setDrawLabels(false)
                    setDrawGridLines(false)
                    setDrawAxisLine(false)
                }
                axisLeft.apply {
                    isEnabled = true
                    axisMinimum = 0f
                    axisMaximum = 40f
                    setDrawLabels(false)
                    setDrawGridLines(false)
                    setDrawAxisLine(false)
                }
                axisRight.isEnabled = false
                legend.isEnabled = false
            }
        },
        update = { chart ->
            if (sensorData.isNotEmpty()) {
                val maxTime = sensorData.maxOf { it.first }
                val entries = sensorData.map { (time, magnitude) -> Entry(time, magnitude) }

                val dataSet = LineDataSet(entries, "").apply {
                    color = lineColor
                    setDrawCircles(false)
                    setDrawValues(false)
                    lineWidth = 4f
                    mode = LineDataSet.Mode.LINEAR
                }

                chart.data = LineData(dataSet)
                chart.xAxis.axisMinimum = maxTime - 5f
                chart.xAxis.axisMaximum = maxTime

                chart.notifyDataSetChanged()
                chart.invalidate()
            }
        },
        modifier = modifier.fillMaxWidth()
    )
}

// Original RealTimeGraph
//@Composable
//fun RealTimeGraph(sensorData: List<Pair<Float, Float>>, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
//            LineChart(context).apply {
//                description.isEnabled = false
//                setTouchEnabled(false)
//                isDragEnabled = false
//                setScaleEnabled(false)
//                xAxis.position = XAxis.XAxisPosition.BOTTOM
//                xAxis.setDrawGridLines(true)
//                xAxis.textColor = android.graphics.Color.GRAY
//                axisLeft.setDrawGridLines(true)
//                axisLeft.textColor = android.graphics.Color.GRAY
//                axisRight.isEnabled = false
//                legend.isEnabled = false
//
//                // ✅ Fixed Y-Axis Range
//                axisLeft.axisMinimum = 0f
//                axisLeft.axisMaximum = 20f
//            }
//        },
//        update = { chart ->
//            if (sensorData.isNotEmpty()) {
//                val minTime = sensorData.minOf { it.first }
//                val maxTime = sensorData.maxOf { it.first }
//
//                val entries = sensorData.map { (time, magnitude) -> Entry(time, magnitude) }
//
//                val dataSet = LineDataSet(entries, "Acceleration").apply {
//                    color = android.graphics.Color.BLUE
//                    valueTextColor = android.graphics.Color.BLACK
//                    setDrawCircles(false)
//                    setDrawValues(false)
//                    lineWidth = 2f
//                }
//
//                chart.data = LineData(dataSet)
//                chart.xAxis.axisMinimum = maxTime - 5f
//                chart.xAxis.axisMaximum = maxTime
//
//                chart.notifyDataSetChanged()
//                chart.invalidate()
//            }
//        },
//        modifier = modifier.fillMaxWidth(),
//
//        )
//}

fun computeFFT(accelerationData: List<Float>): List<Pair<Float, Float>> {
    if (accelerationData.isEmpty()) return emptyList()

    val n = accelerationData.size
    val fft = DoubleFFT_1D(n.toLong())

    val mean = accelerationData.average().toFloat()
    val adjustedData = accelerationData.map { it - mean }

    val fftInput = DoubleArray(n * 2)
    for (i in adjustedData.indices) {
        fftInput[2 * i] = adjustedData[i].toDouble()
        fftInput[2 * i + 1] = 0.0
    }

    fft.realForward(fftInput)

    val fftOutput = mutableListOf<Pair<Float, Float>>()
    val samplingRate = 40f
    val nyquistLimit = samplingRate / 2

    for (i in 0 until n / 2) {
        val real = fftInput[2 * i]
        val imag = fftInput[2 * i + 1]
        val magnitude = sqrt(real.pow(2) + imag.pow(2)).toFloat()
        val power = magnitude.pow(2)
        val frequency = (i.toFloat() / (n / 2)) * nyquistLimit
        if (frequency > 15) break
        fftOutput.add(Pair(frequency, power))
    }

    return fftOutput
}

@Composable
fun FFTGraph(fftData: List<Pair<Float, Float>>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.secondary.toArgb()
    AndroidView(
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                setTouchEnabled(false)
                isDragEnabled = false
                setScaleEnabled(false)
                setPinchZoom(false)
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setViewPortOffsets(0f, 0f, 0f, 0f)

                xAxis.apply {
                    isEnabled = true
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisLeft.apply {
                    isEnabled = true
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisRight.isEnabled = false
                legend.isEnabled = false
            }
        },
        update = { chart ->
            if (fftData.isNotEmpty()) {
                val entries = fftData.map { (freq, power) -> Entry(freq, power) }

                val dataSet = LineDataSet(entries, "").apply {
                    color = lineColor
                    setDrawCircles(false)
                    setDrawValues(false)
                    lineWidth = 4f
                }

                chart.data = LineData(dataSet)

                val maxPower = fftData.maxOfOrNull { it.second } ?: 1000f
                chart.axisLeft.axisMaximum = maxPower * 1.1f
                chart.axisLeft.axisMinimum = 0f

                chart.notifyDataSetChanged()
                chart.invalidate()
            }
        },
        modifier = modifier.fillMaxWidth()
    )
}

// Original FFT Graph
//@Composable
//fun FFTGraph(fftData: List<Pair<Float, Float>>, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
//            LineChart(context).apply {
//                description.isEnabled = false
//                setTouchEnabled(false)
//                isDragEnabled = false
//                setScaleEnabled(false)
//                xAxis.position = XAxis.XAxisPosition.BOTTOM
//                xAxis.setDrawGridLines(true)
//                xAxis.textColor = android.graphics.Color.GRAY
//                xAxis.textSize = 12f
//                xAxis.labelRotationAngle = 0f
//                xAxis.valueFormatter = object : ValueFormatter() {
//                    override fun getFormattedValue(value: Float): String {
//                        return String.format("%.1f Hz", value)
//                    }
//                }
//                axisRight.isEnabled = false
//                legend.isEnabled = true
//            }
//        },
//        update = { chart ->
//            if (fftData.isNotEmpty()) {
//                val entries = fftData.map { (freq, power) -> Entry(freq, power) }
//
//                val dataSet = LineDataSet(entries, "FFT Power").apply {
//                    color = android.graphics.Color.BLUE
//                    valueTextColor = android.graphics.Color.BLACK
//                    setDrawCircles(false)
//                    setDrawValues(false)
//                    lineWidth = 2f
//                }
//
//                chart.data = LineData(dataSet)
//
//                val maxPower = fftData.maxOfOrNull { it.second } ?: 1000f
//                chart.axisLeft.axisMaximum = maxPower * 1.1f
//                chart.axisLeft.axisMinimum = 0f
//                chart.axisLeft.textColor = android.graphics.Color.GRAY
//
//                chart.notifyDataSetChanged()
//                chart.invalidate()
//            }
//        },
//        modifier = modifier.fillMaxWidth(),
//
//        )
//}

@Composable
fun AudioWaveformGraph(audioData: List<Short>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.primary.toArgb() // NEW

    AndroidView(
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                setTouchEnabled(false)
                setScaleEnabled(false)
                setPinchZoom(false)
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setViewPortOffsets(0f, 0f, 0f, 0f)

                xAxis.apply {
                    isEnabled = true
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisLeft.apply {
                    isEnabled = true
                    axisMinimum = -32768f
                    axisMaximum = 32767f
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisRight.isEnabled = false
                legend.isEnabled = false
            }
        },
        update = { chart ->
            if (audioData.isNotEmpty()) {
                val downsampled = audioData
                    .withIndex()
                    .filter { it.index % 100 == 0 }
                    .mapNotNull {
                        val y = it.value.toFloat()
                        if (y.isFinite()) Entry(it.index.toFloat(), y) else null
                    }

                if (downsampled.isNotEmpty()) {
                    val dataSet = LineDataSet(downsampled, "").apply {
                        color = lineColor // CHANGED
                        setDrawCircles(false)
                        setDrawValues(false)
                        lineWidth = 1f
                    }

                    try {
                        chart.data = LineData(dataSet)
                        chart.notifyDataSetChanged()
                        chart.invalidate()
                    } catch (e: Exception) {
                        Log.e("ChartError", "Chart update failed: ${e.localizedMessage}")
                    }
                }
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
    )
}

// original waveform graph:
//@Composable
//fun AudioWaveformGraph(audioData: List<Short>, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
//            LineChart(context).apply {
//                description.text = "Audio Waveform"
//                setTouchEnabled(false)
//                setScaleEnabled(false)
//                xAxis.position = XAxis.XAxisPosition.BOTTOM
//                axisRight.isEnabled = false
//                axisLeft.axisMinimum = -32768f  // 16-bit audio range
//                axisLeft.axisMaximum = 32767f
//                legend.isEnabled = false
//            }
//        },
//        update = { chart ->
//            if (audioData.isNotEmpty()) {
//                val downsampled = audioData
//                    .withIndex()
//                    .filter { it.index % 100 == 0 }
//                    .mapNotNull {
//                        val y = it.value.toFloat()
//                        if (y.isFinite()) Entry(it.index.toFloat(), y) else null
//                    }
//
//                if (downsampled.isNotEmpty()) {
//                    val dataSet = LineDataSet(downsampled, "Audio").apply {
//                        color = android.graphics.Color.BLUE
//                        valueTextColor = android.graphics.Color.BLACK
//                        setDrawCircles(false)
//                        setDrawValues(false)
//                        lineWidth = 1f
//                    }
//
//                    try {
//                        chart.data = LineData(dataSet)
//                        chart.notifyDataSetChanged()
//                        chart.invalidate()
//                    } catch (e: Exception) {
//                        Log.e("ChartError", "Chart update failed: ${e.localizedMessage}")
//                    }
//                }
//            }
//        },
//        modifier = modifier
//            .fillMaxWidth()
//            .height(200.dp)
//    )
//}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoOverlay(
    title: String,
    body: String,
    onClose: () -> Unit,
    lockMs: Long = 900L
) {
    // When the overlay opens, we “lock” closing for a short time
    val openedAt = remember { SystemClock.elapsedRealtime() }

    Dialog(
        onDismissRequest = { onClose() }, // back button will close
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false // IMPORTANT: we handle taps ourselves (with delay-lock)
        )
    ) {
        // Full-screen clickable dim background
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f))
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - openedAt >= lockMs) {
                        onClose()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            // The info “card” in the middle
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineSmall,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = body,
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Start
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Tap anywhere to close",
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(navController: NavHostController) {
    val context = LocalContext.current
    var showInfo by rememberSaveable { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("gloveworks_prefs", Context.MODE_PRIVATE) }

    LaunchedEffect(Unit) {
        val seen = prefs.getBoolean("home_info_seen", false)
        if (!seen) {
            showInfo = true
            prefs.edit().putBoolean("home_info_seen", true).apply()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            BottomAppBar(containerColor = MaterialTheme.colorScheme.surface) {

                val btnW = 97.dp   // smaller width
                val btnH = 43.dp    // smaller height
                val gap  = 12.dp    // space between Info and Exit

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Exit stays DEAD CENTER
                    Button(
                        onClick = { (context as? Activity)?.finish() },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                    ) {
                        Text("Exit", fontSize = 15.sp)
                    }

                    // Info sits just left of Exit
                    Button(
                        onClick = { showInfo = true },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                            .offset(x = -(btnW + gap))
                    ) {
                        Text("Info", fontSize = 15.sp)
                    }
                }
            }
        }
    ) { innerPadding ->
        if (showInfo) {
            InfoOverlay(
                title = "How to Use This App",
                body = """
            • Gait Monitor: records your walking movement.
            • Voice Analysis: records a short voice sample.
            • Glove Control: connect to your glove and adjust settings.
            • Symptom Tracker: log symptoms and medication times.
            • Settings: user info and app info.

            Need help? Tap Info anytime for directions.
        """.trimIndent(),
                onClose = { showInfo = false }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Española GloveWorks",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(36.dp))


            Button(
                onClick = { navController.navigate("main") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
            ) {
                Text("Gait Monitor", fontSize = 26.sp)
            }

            Button(
                onClick = { navController.navigate("voice") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
            ) {
                Text("Voice Analysis", fontSize = 26.sp)
            }

            Button(
                onClick = { navController.navigate("glove_control") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
            ) {
                Text("Glove Control", fontSize = 26.sp)

            }

            Button(
                onClick = { navController.navigate("symptom_tracker") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
            ) { Text("Symptom Tracker", fontSize = 26.sp) }

            Button(
                onClick = { navController.navigate("settings") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
            ) {
                Text("Settings", fontSize = 26.sp)
            }

        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceScreen(navController: NavHostController) {
    val context = LocalContext.current
    var showInfo by rememberSaveable { mutableStateOf(false) }
    val permissionState = remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        if (!permissionState.value && context is Activity) {
            ActivityCompat.requestPermissions(
                context,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                1001
            )

            delay(500)
            permissionState.value = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    val sampleRate = 22050
    val bufferSize = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    )

    var audioRecord by remember { mutableStateOf<AudioRecord?>(null) }
    var isRecording by remember { mutableStateOf(false) }
    var collectedSamples by remember { mutableStateOf(mutableListOf<Short>()) }
    var rmsValues by remember { mutableStateOf(mutableListOf<Float>()) }
    var fftResults by remember { mutableStateOf<List<Pair<Float, Float>>>(emptyList()) }
    var epochFreqList by remember { mutableStateOf(mutableListOf<Pair<Int, Float>>()) }

    val downsampledSamples = remember(collectedSamples) {
        if (collectedSamples.size <= 2000) {
            collectedSamples
        } else {
            collectedSamples.filterIndexed { index, _ -> index % 10 == 0 }
        }
    }

    fun calculateRMS(samples: List<Short>): Float {
        if (samples.isEmpty()) return 0f
        val sumSquares = samples.fold(0.0) { acc, s -> acc + s * s }
        return kotlin.math.sqrt(sumSquares / samples.size).toFloat()
    }

    fun startRecording() {
        val sharedPref = context.getSharedPreferences(
            "gloveworks_prefs",
            Context.MODE_PRIVATE
        )
        sharedPref.edit().remove("voice_session_id").apply()
        collectedSamples = mutableListOf()
        rmsValues = mutableListOf()
        epochFreqList = mutableListOf()
        fftResults = emptyList()
        coroutineScope.launch {
            withContext(Dispatchers.Main) {
                isRecording = true
                collectedSamples = mutableListOf()
            }

            try {
                val record = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )

                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    withContext(Dispatchers.Main) { isRecording = false }
                    return@launch
                }

                audioRecord = record
                record.startRecording()

                repeat(4) { epochIndex ->
                    val buffer = ShortArray(bufferSize)
                    val epochSamples = mutableListOf<Short>()
                    val startTime = System.currentTimeMillis()

                    while (System.currentTimeMillis() - startTime < 5000 && isRecording) {
                        val read = record.read(buffer, 0, buffer.size)
                        if (read > 0) {
                            epochSamples.addAll(buffer.take(read))
                        } else break
                        delay(100)
                    }

                    val (rms, fftData, dominantFreq) = withContext(Dispatchers.Default) {
                        val rms = calculateRMS(epochSamples)
                        val fftData = computeFFT(epochSamples, sampleRate)
                        val dominantFreq = fftData.maxByOrNull { it.second }?.first ?: 0f
                        Triple(rms, fftData, dominantFreq)
                    }

                    withContext(Dispatchers.Main) {
                        collectedSamples.addAll(epochSamples)
                        rmsValues.add(rms)
                        epochFreqList.add(Pair(epochIndex + 1, dominantFreq))
                    }

                    uploadRawAudioToStorage(
                        context = context,
                        epochIndex = epochIndex + 1,
                        audioData = epochSamples
                    )
                }

            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    audioRecord?.let {
                        if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop()
                        it.release()
                    }
                } catch (_: Exception) {
                }
                audioRecord = null

                withContext(Dispatchers.Main) {
                    isRecording = false
                }
            }
        }
    }

    fun stopRecording() {
        coroutineScope.launch {
            withContext(Dispatchers.Main) {
                isRecording = false
            }

            try {
                audioRecord?.let {
                    if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        it.stop()
                    }
                    it.release()
                }
            } catch (e: Exception) {
                println("StopRecording error: ${e.message}")
            }
            audioRecord = null
        }
    }


    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Voice Analysis") }) },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val btnW = 97.dp
                val btnH = 43.dp
                val gap  = 12.dp

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = { navController.navigate("home") },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                    ) { Text("Home", fontSize = 15.sp) }

                    Button(
                        onClick = { showInfo = true },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                            .offset(x = -(btnW + gap))
                    ) { Text("Info", fontSize = 15.sp) }
                }
            }
        }
    ) { innerPadding ->
        if (showInfo) {
            InfoOverlay(
                title = "Voice Analysis Directions",
                body = """
        • Find a quiet room.
        • Hold the bottom of the phone 6–12 inches from your mouth.
        • Tap Start.
        • Take a breath and say "Ahhh" in a steady voice for 10 seconds.
        • Tap Stop anytime.
        • Tap Home to return.
    """.trimIndent(),
                onClose = { showInfo = false }
            )

        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            if (isRecording) {
                val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
                val pulseSize by infiniteTransition.animateFloat(
                    initialValue = 20f,
                    targetValue = 40f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "PulseSize"
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier.size(40.dp), // reserve max space
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(pulseSize.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.error)
                        )
                    }

                }
            }

            Button(
                onClick = {
                    if (permissionState.value && !isRecording) {
                        startRecording()
                    } else {
                        println("Microphone permission not granted.")
                    }
                },
                enabled = !isRecording,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Start")
            }

            Button(
                onClick = { stopRecording() },
                enabled = isRecording,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Stop")
            }

            Text("Samples collected: ${collectedSamples.size}")



            AudioWaveformGraph(downsampledSamples, modifier = Modifier.height(150.dp))
            RMSGraph(rmsValues, modifier = Modifier.height(150.dp))
            FFTAudioTrendGraph(epochFreqList, modifier = Modifier.height(150.dp))


        }
    }
}

fun computeFFT(samples: List<Short>, sampleRate: Int): List<Pair<Float, Float>> {
    val n = samples.size
    val fft = DoubleArray(n * 2) // real + imag

    for (i in samples.indices) {
        fft[2 * i] = samples[i].toDouble()
        fft[2 * i + 1] = 0.0
    }

    val fftInstance = DoubleFFT_1D(n.toLong())
    fftInstance.complexForward(fft)

    val result = mutableListOf<Pair<Float, Float>>()
    val freqResolution = sampleRate.toFloat() / n

    for (i in 0 until n / 2) {
        val real = fft[2 * i]
        val imag = fft[2 * i + 1]
        val magnitude = sqrt(real * real + imag * imag).toFloat()
        val freq = i * freqResolution
        result.add(Pair(freq, magnitude))
    }

    return result
}

@Composable
fun RMSGraph(rmsValues: List<Float>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.secondary.toArgb() // NEW

    AndroidView(
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                setTouchEnabled(false)
                setScaleEnabled(false)
                setPinchZoom(false)
                isDragEnabled = false
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setViewPortOffsets(0f, 0f, 0f, 0f)

                xAxis.apply {
                    isEnabled = true
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisLeft.apply {
                    isEnabled = true
                    axisMinimum = 0f
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisRight.isEnabled = false
                legend.isEnabled = false
            }
        },
        update = { chart ->
            if (rmsValues.isNotEmpty()) {
                val entries = rmsValues.mapIndexed { index, value ->
                    Entry(index.toFloat(), value)
                }

                val dataSet = LineDataSet(entries, "").apply {
                    color = lineColor // CHANGED
                    setDrawCircles(false)
                    circleRadius = 4f
                    setDrawValues(false)
                    lineWidth = 2f
                    mode = LineDataSet.Mode.LINEAR
                }

                chart.data = LineData(dataSet)
                chart.notifyDataSetChanged()
                chart.invalidate()
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
    )
}

//Original RMSGraph

//@Composable
//fun RMSGraph(rmsValues: List<Float>, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
//            LineChart(context).apply {
//                description.text = "RMS Over Time"
//                setTouchEnabled(false)
//                setScaleEnabled(false)
//                setPinchZoom(false)
//                isDragEnabled = false
//
//                xAxis.position = XAxis.XAxisPosition.BOTTOM
//                xAxis.setDrawGridLines(true)
//                xAxis.textColor = android.graphics.Color.GRAY
//                xAxis.textSize = 12f
//                xAxis.labelRotationAngle = 0f
//                xAxis.valueFormatter = object : ValueFormatter() {
//                    override fun getFormattedValue(value: Float): String {
//                        return "${(value.toInt() + 1) * 5}s"
//                    }
//                }
//
//                axisLeft.axisMinimum = 0f
//                axisLeft.textColor = android.graphics.Color.GRAY
//                axisLeft.valueFormatter = object : ValueFormatter() {
//                    override fun getFormattedValue(value: Float): String {
//                        return String.format("%.0f", value)
//                    }
//                }
//
//                axisRight.isEnabled = false
//                legend.isEnabled = false
//            }
//        },
//        update = { chart ->
//            if (rmsValues.isNotEmpty()) {
//                val entries = rmsValues.mapIndexed { index, value ->
//                    Entry(index.toFloat(), value)
//                }
//
//                val dataSet = LineDataSet(entries, "RMS").apply {
//                    color = android.graphics.Color.BLUE
//                    setDrawCircles(true)
//                    circleRadius = 4f
//                    valueTextColor = android.graphics.Color.BLACK
//                    setDrawValues(true)
//                    lineWidth = 2f
//                }
//
//                chart.data = LineData(dataSet)
//                chart.notifyDataSetChanged()
//                chart.invalidate()
//            }
//        },
//        modifier = modifier
//            .fillMaxWidth()
//            .height(200.dp)
//    )
//}

@Composable
fun FFTAudioTrendGraph(epochFreqList: List<Pair<Int, Float>>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.tertiary.toArgb() // NEW

    AndroidView(
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                setTouchEnabled(false)
                setScaleEnabled(false)
                setPinchZoom(false)
                isDragEnabled = false
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setViewPortOffsets(0f, 0f, 0f, 0f)

                xAxis.apply {
                    isEnabled = true
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisLeft.apply {
                    isEnabled = true
                    axisMinimum = 0f
                    axisMaximum = 40f
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisRight.isEnabled = false
                legend.isEnabled = false
            }
        },
        update = { chart ->
            if (epochFreqList.isNotEmpty()) {
                val maxY = epochFreqList.maxOfOrNull { it.second }?.coerceAtLeast(20f) ?: 20f
                chart.axisLeft.axisMaximum = maxY

                val entries = epochFreqList.map { Entry(it.first.toFloat(), it.second) }

                val dataSet = LineDataSet(entries, "").apply {
                    color = lineColor // CHANGED
                    setDrawCircles(false)
                    circleRadius = 4f
                    setDrawValues(false)
                    lineWidth = 2f
                    mode = LineDataSet.Mode.LINEAR
                }

                chart.data = LineData(dataSet)
                chart.notifyDataSetChanged()
                chart.invalidate()
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
    )
}

//original audio fft trend graph:

//@Composable
//fun FFTAudioTrendGraph(epochFreqList: List<Pair<Int, Float>>, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
//            LineChart(context).apply {
//                description.text = "Dominant Frequency Over Time"
//                setTouchEnabled(false)
//                setScaleEnabled(false)
//                setPinchZoom(false)
//                isDragEnabled = false
//
//                xAxis.position = XAxis.XAxisPosition.BOTTOM
//                xAxis.setDrawGridLines(true)
//                xAxis.textColor = android.graphics.Color.GRAY
//                xAxis.textSize = 12f
//                xAxis.labelRotationAngle = 0f
//                xAxis.valueFormatter = object : ValueFormatter() {
//                    override fun getFormattedValue(value: Float): String {
//                        return "${value.toInt() * 5}s"
//                    }
//                }
//
//                axisLeft.axisMinimum = 0f
//                axisLeft.axisMaximum = 12f
//                axisLeft.textColor = android.graphics.Color.GRAY
//                axisLeft.valueFormatter = object : ValueFormatter() {
//                    override fun getFormattedValue(value: Float): String {
//                        return String.format("%.1f Hz", value)
//                    }
//                }
//
//                axisRight.isEnabled = false
//                legend.isEnabled = false
//            }
//        },
//        update = { chart ->
//            if (epochFreqList.isNotEmpty()) {
//                val maxY = epochFreqList.maxOfOrNull { it.second }?.coerceAtLeast(20f) ?: 20f
//                chart.axisLeft.axisMaximum = maxY
//
//                val entries = epochFreqList.map { Entry(it.first.toFloat(), it.second) }
//                val dataSet = LineDataSet(entries, "Dominant Frequency").apply {
//                    color = android.graphics.Color.MAGENTA
//                    setDrawCircles(true)
//                    circleRadius = 4f
//                    valueTextColor = android.graphics.Color.BLACK
//                    setDrawValues(true)
//                    lineWidth = 2f
//                }
//                chart.data = LineData(dataSet)
//                chart.notifyDataSetChanged()
//                chart.invalidate()
//            }
//        },
//        modifier = modifier.fillMaxWidth().height(200.dp)
//    )
//}

@Composable
fun FFTTrendGraph(epochFreqList: List<Pair<Int, Float>>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.tertiary.toArgb() // NEW

    AndroidView(
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                setTouchEnabled(false)
                setScaleEnabled(false)
                setPinchZoom(false)
                isDragEnabled = false
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setViewPortOffsets(0f, 0f, 0f, 0f)

                xAxis.apply {
                    isEnabled = true
                    setDrawGridLines(false)
                    setDrawLabels(false)
                    setDrawAxisLine(false)
                }

                axisLeft.apply {
                    isEnabled = true
                    axisMinimum = 0f
                    axisMaximum = 16f
                    setDrawLabels(false)
                    setDrawGridLines(false)
                    setDrawAxisLine(false)
                }

                axisRight.isEnabled = false
                legend.isEnabled = false
            }
        },
        update = { chart ->
            if (epochFreqList.isNotEmpty()) {
                val entries = epochFreqList.map { Entry(it.first.toFloat(), it.second) }

                val dataSet = LineDataSet(entries, "").apply {
                    color = lineColor // CHANGED
                    setDrawCircles(false)
                    circleRadius = 4f
                    setDrawValues(false)
                    lineWidth = 3f
                    mode = LineDataSet.Mode.LINEAR
                }

                chart.data = LineData(dataSet)
                chart.notifyDataSetChanged()
                chart.invalidate()
            }
        },
        modifier = modifier.fillMaxWidth()
    )
}

// original FFTTrendGraph

//@Composable
//fun FFTTrendGraph(epochFreqList: List<Pair<Int, Float>>, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
//            LineChart(context).apply {
//                description.text = "Dominant Frequency Over Time"
//                setTouchEnabled(false)
//                setScaleEnabled(false)
//                setPinchZoom(false)
//                isDragEnabled = false
//
//                xAxis.position = XAxis.XAxisPosition.BOTTOM
//                xAxis.setDrawGridLines(true)
//                xAxis.textColor = android.graphics.Color.GRAY
//                xAxis.textSize = 12f
//                xAxis.labelRotationAngle = 0f
//                xAxis.valueFormatter = object : ValueFormatter() {
//                    override fun getFormattedValue(value: Float): String {
//                        return "${value.toInt() * 5}s"
//                    }
//                }
//
//                axisLeft.axisMinimum = 0f
//                axisLeft.axisMaximum = 12f
//                axisLeft.textColor = android.graphics.Color.GRAY
//                axisLeft.valueFormatter = object : ValueFormatter() {
//                    override fun getFormattedValue(value: Float): String {
//                        return String.format("%.1f Hz", value)
//                    }
//                }
//
//                axisRight.isEnabled = false
//                legend.isEnabled = false
//            }
//        },
//        update = { chart ->
//            if (epochFreqList.isNotEmpty()) {
//                val entries = epochFreqList.map { Entry(it.first.toFloat(), it.second) }
//                val dataSet = LineDataSet(entries, "Dominant Frequency").apply {
//                    color = android.graphics.Color.MAGENTA
//                    setDrawCircles(true)
//                    circleRadius = 4f
//                    valueTextColor = android.graphics.Color.BLACK
//                    setDrawValues(true)
//                    lineWidth = 2f
//                }
//                chart.data = LineData(dataSet)
//                chart.notifyDataSetChanged()
//                chart.invalidate()
//            }
//        },
//        modifier = modifier.fillMaxWidth(),
//
//
//    )
//}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavHostController, userInfoViewModel: UserInfoViewModel) {
    val context = LocalContext.current
    val sensorManager = remember {
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }
    val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    var showInfo by rememberSaveable { mutableStateOf(false) }
    var isCollecting by remember {
        mutableStateOf(false)
    }
    var sensorDataList by remember {
        mutableStateOf<List<Pair<Float, Float>>>(emptyList())
    }
    var fftDataList by remember {
        mutableStateOf<List<Pair<Float, Float>>>(emptyList())
    }
    var epochFreqList by remember {
        mutableStateOf<List<Pair<Int, Float>>>(emptyList())
    }
    var elapsedTime by remember {
        mutableStateOf(0f)
    }
    var epochSamples by remember {
        mutableStateOf(mutableListOf<Triple<Float, Float, Float>>())
    }

    val coroutineScope = rememberCoroutineScope()

    val sensorListener = remember {
        object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    if (isCollecting) {
                        val x = it.values[0]
                        val y = it.values[1]
                        val z = it.values[2]
                        val magnitude = sqrt(x * x + y * y + z * z)
                        elapsedTime += 0.1f
                        sensorDataList = sensorDataList + Pair(elapsedTime, magnitude)
                        sensorDataList = sensorDataList.filter { it.first >= elapsedTime - 5f }
                        epochSamples.add(Triple(x, y, z))
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
    }

    fun stopCollecting() {
        isCollecting = false
        sensorManager.unregisterListener(sensorListener)
        elapsedTime = 0f
    }

    fun startCollecting() {
        val sharedPref = context.getSharedPreferences(
            "gloveworks_prefs",
            Context.MODE_PRIVATE
        )
        sharedPref.edit().remove("motion_session_id").apply()

        isCollecting = true
        sensorDataList = emptyList()
        fftDataList = emptyList()
        epochFreqList = emptyList()
        elapsedTime = 0f

        sensorManager.registerListener(
            sensorListener, accelerometer,
            SensorManager.SENSOR_DELAY_UI
        )

        coroutineScope.launch {
            for (epochIndex in 1..4) {
                epochSamples = mutableListOf()

                val cycleStartTime = System.currentTimeMillis()
                while (isCollecting) {
                    val elapsedMillis = System.currentTimeMillis() - cycleStartTime
                    if (elapsedMillis >= 5000) break
                    delay(100)
                }
                if (!isCollecting) break

                val accelerationValues = sensorDataList.map { it.second }
                val fftResult = computeFFT(accelerationValues)
                fftDataList = fftResult

                val dominantFrequency = fftResult.maxByOrNull { it.second }?.first ?: 0f
                epochFreqList = epochFreqList + Pair(epochIndex, dominantFrequency)

                uploadMotionEpochToFirebase(
                    context = context,
                    epochIndex = epochIndex, // ✅ fixed
                    accelerometerSamples = epochSamples
                )
            }

            stopCollecting()
        }
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { CenterAlignedTopAppBar(title = { Text("GloveWorks Gait Monitor") }) },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val btnW = 97.dp
                val btnH = 43.dp
                val gap  = 12.dp
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = { navController.navigate("home") },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                    ) { Text("Home", fontSize = 15.sp) }

                    Button(
                        onClick = { showInfo = true },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                            .offset(x = -(btnW + gap))
                    ) { Text("Info", fontSize = 15.sp) }
                }
            }
        }
    ) { innerPadding ->
        if (showInfo) {
            InfoOverlay(
                title = "Gait Monitor Directions",
                body = """
        • Find a safe, open space.
        • Put the phone in a pocket(Use Same Pocket Every Time).
        • Tap Start.
        • Walk straight for about 20 seconds.
        • Tap Stop anytime.
        • Not enough room? Turn around and keep walking.
        • No straight path? Walk in a wide circle.
    """.trimIndent(),
                onClose = { showInfo = false }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { startCollecting() },
                    enabled = !isCollecting,
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                ) { Text("Start") }

                Button(
                    onClick = { stopCollecting() },
                    enabled = isCollecting,
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                ) { Text("Stop") }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(600.dp) // You can adjust this as needed
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RealTimeGraph(sensorDataList, modifier = Modifier.weight(1f))
                FFTGraph(fftDataList, modifier = Modifier.weight(1f))
                FFTTrendGraph(epochFreqList, modifier = Modifier.weight(1f))
            }


        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavHostController) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { CenterAlignedTopAppBar(title = { Text("Settings") }) },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { navController.navigate("home") }) { Text("Home") }
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = { navController.navigate("user_info") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    Text("User Information", fontSize = 24.sp)
                }

                Button(
                    onClick = { navController.navigate("about") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)

                ) {
                    Text("About", fontSize = 24.sp)
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(navController: NavHostController) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("About", style = MaterialTheme.typography.headlineSmall)

            Spacer(modifier = Modifier.height(32.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                )

                {
                    Text("GloveWorks App", style = MaterialTheme.typography.titleMedium)
                    Text("Version: 1.0.0")
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Developed by:")
                    Text("Ali Nazım Aslan", style = MaterialTheme.typography.bodyMedium)
                    Text("Niel Kirby Salero", style = MaterialTheme.typography.bodyMedium)
                    Text("Nicholas Lopez", style = MaterialTheme.typography.bodyMedium)
                    Text("Emily Schutz", style = MaterialTheme.typography.bodyMedium)
                    Text("for Española GloveWorks")
                    Text(
                        "at Northern New Mexico College, 2025",
                        style = MaterialTheme.typography.bodyMedium
                    )


                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Learn more at:")

                    Spacer(modifier = Modifier.height(2.dp))

                    Button(onClick = {
                        val url = "https://sites.google.com/nnmc.edu/espanolagloveworks/home"
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        context.startActivity(intent)
                    }) {
                        Text("GloveWorks Website")
                    }
                }
            }
        }

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .padding(bottom = 24.dp)
        ) {
            Text("Back")
        }
    }
}

class GloveBleController(
    private val context: Context,
    private val serviceUuid: UUID
) {
    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager.adapter
    private val scanner: BluetoothLeScanner? get() = adapter?.bluetoothLeScanner

    private var gatt: BluetoothGatt? = null
    private var connectedDevice: BluetoothDevice? = null

    private val _devices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val devices: StateFlow<List<BluetoothDevice>> = _devices

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected

    private val _statusText = MutableStateFlow("Disconnected")
    val statusText: StateFlow<String> = _statusText

    // --- Permissions (mirrors MIT app flow) ---
    fun ensureBlePermissions(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val need = mutableListOf<String>()
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED
            ) need.add(Manifest.permission.BLUETOOTH_SCAN)

            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
            ) need.add(Manifest.permission.BLUETOOTH_CONNECT)

            if (need.isNotEmpty()) {
                ActivityCompat.requestPermissions(activity, need.toTypedArray(), 7001)
            }
        } else {
            // Pre-Android 12 scanning often requires location permission
            if (ActivityCompat.checkSelfPermission(
                    activity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    activity,
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    7002
                )
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        _statusText.value = "Scanning..."
        _devices.value = emptyList()

        val s = scanner ?: run {
            _statusText.value = "Bluetooth not available"
            return
        }

        val filters = listOf(
            ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(serviceUuid))
                .build()
        )

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        s.startScan(filters, settings, scanCallback)
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        scanner?.stopScan(scanCallback)
        if (!_isConnected.value) _statusText.value = "Disconnected"
    }

    @SuppressLint("MissingPermission")
    fun connectByIndex(index: Int) {
        val list = _devices.value
        if (index !in list.indices) return
        stopScan()
        val device = list[index]
        connect(device)
    }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        connectedDevice = device
        _statusText.value = "Connecting..."
        gatt?.close()
        gatt = device.connectGatt(context, false, gattCallback)
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        stopScan()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        connectedDevice = null
        _isConnected.value = false
        _statusText.value = "Disconnected"
    }

    @SuppressLint("MissingPermission")
    fun writeIntAsString(characteristicUuid: UUID, value: Int) {
        val g = gatt ?: return
        val service = g.getService(serviceUuid) ?: return
        val ch = service.getCharacteristic(characteristicUuid) ?: return

        // MIT app writes strings; we match that: "100", "744", etc.
        ch.value = value.toString().toByteArray(Charset.forName("UTF-8"))

        // “false” in MIT WriteStrings likely corresponds to write type no-response off;
        // safest default is WRITE_TYPE_DEFAULT (with response).
        ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        g.writeCharacteristic(ch)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val current = _devices.value
            if (current.none { it.address == device.address }) {
                _devices.value = current + device
            }
        }

        override fun onScanFailed(errorCode: Int) {
            _statusText.value = "Scan failed: $errorCode"
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                _statusText.value = "Connected"
                _isConnected.value = true
                gatt.discoverServices()
            } else {
                _isConnected.value = false
                _statusText.value = "Disconnected"
                try {
                    gatt.close()
                } catch (_: Exception) {
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            // No-op; services are available for writing.
        }
    }
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GloveControlScreen(navController: NavHostController) {
    val context = LocalContext.current
    val activity = context as? Activity
    val prefs = remember {
        context.getSharedPreferences("gloveworks_prefs", Context.MODE_PRIVATE)
    }

    // PIN LOCK
    // Default PIN is 1234
    val storedPin = remember { prefs.getString("glove_control_pin", "1234") ?: "1234" }

    var isUnlocked by rememberSaveable { mutableStateOf(false) }
    var showPinDialog by rememberSaveable { mutableStateOf(true) }
    var pinInput by rememberSaveable { mutableStateOf("") }
    var pinError by rememberSaveable { mutableStateOf<String?>(null) }

    if (!isUnlocked && showPinDialog) {
        AlertDialog(
            onDismissRequest = {
                showPinDialog = false
                navController.popBackStack()
            },
            title = { Text("Enter PIN") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            pinInput = it.filter { ch -> ch.isDigit() }.take(8)
                            pinError = null
                        },
                        label = { Text("PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (pinError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = pinError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinInput == storedPin) {
                            isUnlocked = true
                            showPinDialog = false
                            pinInput = ""
                            pinError = null
                        } else {
                            pinError = "Incorrect PIN"
                        }
                    }
                ) { Text("Unlock") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPinDialog = false
                        navController.popBackStack()
                    }
                ) { Text("Cancel") }
            }
        )
    }
    if (!isUnlocked) return
    var showInfo by rememberSaveable { mutableStateOf(false) }

    val SERVICE_UUID = remember { UUID.fromString("4fafc201-1fb5-459e-8fcc-c5c9c331914b") }
    val CHAR_MOTOR_AMP =
        remember { UUID.fromString("beb5483e-36e1-4688-b7f5-ea07361b26a8") }     // Char1
    val CHAR_PATTERN_DUR =
        remember { UUID.fromString("e3223119-9445-4e96-a4a1-85358c4046a2") }   // Char2
    val CHAR_BURST_DUR =
        remember { UUID.fromString("e3223119-9445-4e96-a4a1-85358c4046a3") }     // Char3

    val defaultMA = 100
    val defaultPD = 744
    val defaultBD = 100

    // Slider limits
    val MA_RANGE = 50..100          // percent
    val PD_RANGE = 500..1000        // ms
    val BD_RANGE = 50..150          // ms

    var motorAmp by remember { mutableIntStateOf(prefs.getInt("MAval", defaultMA)) }
    var patternDur by remember { mutableIntStateOf(prefs.getInt("PDval", defaultPD)) }
    var burstDur by remember { mutableIntStateOf(prefs.getInt("BDval", defaultBD)) }

    val bleController = remember { GloveBleController(context, SERVICE_UUID) }
    val devices by bleController.devices.collectAsState()
    val isConnected by bleController.isConnected.collectAsState()
    val statusText by bleController.statusText.collectAsState()

    LaunchedEffect(Unit) {
        if (activity != null) {
            bleController.ensureBlePermissions(activity)
        }
    }

    fun persistValues() {
        prefs.edit()
            .putInt("MAval", motorAmp)
            .putInt("PDval", patternDur)
            .putInt("BDval", burstDur)
            .apply()
    }

    fun coerceAllToValidRanges() {
        motorAmp = motorAmp.coerceIn(MA_RANGE)
        burstDur = burstDur.coerceIn(BD_RANGE)

        val minPd = (4 * burstDur).coerceIn(PD_RANGE)
        patternDur = patternDur.coerceIn(minPd..PD_RANGE.last)
    }

    LaunchedEffect(Unit) {
        coerceAllToValidRanges()
        persistValues()
    }

    fun sendAllIfConnected() {
        if (!isConnected) return
        bleController.writeIntAsString(CHAR_MOTOR_AMP, motorAmp)
        bleController.writeIntAsString(CHAR_PATTERN_DUR, patternDur)
        bleController.writeIntAsString(CHAR_BURST_DUR, burstDur)
    }

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Glove Control") }) },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val btnW = 97.dp
                val btnH = 43.dp
                val gap  = 12.dp

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = { navController.navigate("home") },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                    ) { Text("Home", fontSize = 15.sp) }

                    Button(
                        onClick = { showInfo = true },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                            .offset(x = -(btnW + gap))
                    ) { Text("Info", fontSize = 15.sp) }
                }
            }
        }

    ) { innerPadding ->
        if (showInfo) {
            InfoOverlay(
                title = "Glove Control Directions",
                body = """
        • Turn on the glove.
        • Tap Start Scanning.
        • Tap your glove name to connect.
        • Use the 3 sliders to adjust the glove:
          - Motor Amplitude: strength
          - Burst Duration: pulse length
          - Pattern Duration: time between pulses
        • When finished, tap Disconnect.
        • Tap Home to return.
    """.trimIndent(),
                onClose = { showInfo = false }
            )

        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            Text(
                "Scan for your glove, connect, then tune the three parameters below.",
                style = MaterialTheme.typography.bodyMedium
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { bleController.startScan() },
                    modifier = Modifier.weight(1f)
                ) { Text("Start Scanning") }

                Button(
                    onClick = { bleController.disconnect() },
                    enabled = isConnected,
                    modifier = Modifier.weight(1f)
                ) { Text("Disconnect") }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("BLE Status:")
                Text(statusText)
            }

            if (devices.isNotEmpty() && !isConnected) {
                Text("Devices Found:", style = MaterialTheme.typography.titleSmall)

                Card {
                    Column(modifier = Modifier.padding(8.dp)) {
                        devices.forEachIndexed { index, device ->
                            val label = buildString {
                                append(device.name ?: "Unnamed Device")
                                append("  •  ")
                                append(device.address)
                            }
                            OutlinedButton(
                                onClick = { bleController.connectByIndex(index) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(label)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            ParameterSlider(
                title = "Motor Amplitude",
                value = motorAmp,
                valueRange = MA_RANGE,
                enabled = isConnected,
                onValueChanged = { newVal ->
                    motorAmp = newVal.coerceIn(MA_RANGE)
                    persistValues()
                    bleController.writeIntAsString(CHAR_MOTOR_AMP, motorAmp)
                }
            )

            ParameterSlider(
                title = "Burst Duration",
                value = burstDur,
                valueRange = BD_RANGE,
                enabled = isConnected,
                onValueChanged = { newVal ->
                    burstDur = newVal.coerceIn(BD_RANGE)

                    val minPd = (4 * burstDur).coerceIn(PD_RANGE)
                    if (patternDur < minPd) {
                        patternDur = minPd
                        if (isConnected) {
                            bleController.writeIntAsString(CHAR_PATTERN_DUR, patternDur)
                        }
                    }

                    persistValues()
                    bleController.writeIntAsString(CHAR_BURST_DUR, burstDur)
                }
            )

            ParameterSlider(
                title = "Pattern Duration",
                value = patternDur,
                valueRange = PD_RANGE,
                enabled = isConnected,
                onValueChanged = { newVal ->
                    val minPd = (4 * burstDur).coerceIn(PD_RANGE)
                    patternDur = newVal.coerceIn(minPd..PD_RANGE.last)

                    persistValues()
                    bleController.writeIntAsString(CHAR_PATTERN_DUR, patternDur)
                }
            )

            if (isConnected) {
                OutlinedButton(
                    onClick = { sendAllIfConnected() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Re-Send All Values")
                }
            }
        }
    }
}

@Composable
fun ParameterSlider(
    title: String,
    value: Int,
    valueRange: IntRange,
    enabled: Boolean,
    onValueChanged: (Int) -> Unit,
    unit: String? = null,
    helperText: String? = null,
) {
    val displayValue = if (unit.isNullOrBlank()) "$value" else "$value $unit"
    val disabledAlpha = if (enabled) 1f else 0.45f

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(disabledAlpha),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!helperText.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = helperText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                AssistChip(
                    onClick = { /* no-op */ },
                    enabled = false,
                    label = {
                        Text(
                            text = displayValue,
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Slider(
                value = value.toFloat(),
                onValueChange = { newFloat ->
                    // Keep the slider feeling smooth but always commit whole ints
                    val newInt = newFloat.roundToInt().coerceIn(valueRange)
                    onValueChanged(newInt)
                },
                valueRange = valueRange.first.toFloat()..valueRange.last.toFloat(),
                enabled = enabled
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = valueRange.first.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = valueRange.last.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SymptomTrackerScreen(navController: NavHostController) {
    var showInfo by rememberSaveable { mutableStateOf(false) }
    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("GloveWorks Symptom Tracker") }) },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val btnW = 97.dp
                val btnH = 43.dp
                val gap  = 12.dp

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = { navController.navigate("home") },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                    ) { Text("Home", fontSize = 15.sp) }

                    Button(
                        onClick = { showInfo = true },
                        modifier = Modifier
                            .width(btnW)
                            .height(btnH)
                            .align(Alignment.Center)
                            .offset(x = -(btnW + gap))
                    ) { Text("Info", fontSize = 15.sp) }
                }
            }
        }

    ) { innerPadding ->
        if (showInfo) {
            InfoOverlay(
                title = "Symptom Tracker Directions",
                body = """
• Choose a category
  Medication
  Lifestyle
  Physical
  Psychological
• Answer compared to last week
• Update medications if anything changed
• Tap Submit
        """.trimIndent(),
                onClose = { showInfo = false }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(32.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Select a Category", style = MaterialTheme.typography.titleLarge)

            Button(
                onClick = { navController.navigate("symptom_medication") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
            ) { Text("Medication", fontSize = 26.sp) }

            Button(
                onClick = { navController.navigate("symptom_lifestyle") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
            ) { Text("Lifestyle", fontSize = 26.sp) }

            Button(
                onClick = { navController.navigate("symptom_physical") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
            ) { Text("Physical", fontSize = 26.sp) }

            Button(
                onClick = { navController.navigate("symptom_psychological") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
            ) { Text("Psychological", fontSize = 26.sp) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SymptomQuestionScreen(
    title: String,
    questions: List<String>,
    navController: NavHostController
) {
    val responses =
        remember { mutableStateListOf<Int>().apply { repeat(questions.size) { add(0) } } }

    val options = listOf("Never", "Occasionally", "Sometimes", "Often", "Always")

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text(title) }) },
        bottomBar = {
            BottomAppBar {
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { navController.popBackStack() }) { Text("Back") }
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { navController.navigate("home") }) { Text("Home") }
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            questions.forEachIndexed { index, question ->
                Card {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(question, style = MaterialTheme.typography.bodyLarge)

                        options.forEachIndexed { optIndex, label ->
                            OutlinedButton(
                                onClick = { responses[index] = optIndex + 1 },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor =
                                    if (responses[index] == optIndex + 1)
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                    else Color.Transparent
                                )
                            ) {
                                Text(label)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Placeholder submit for later (Firebase, history, etc.)
            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Submit")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

fun placeholderLifestyleQuestions(): List<String> = listOf(
    "Difficulty maintaining a regular sleep schedule?",
    "Changes in appetite or eating habits?",
    "Difficulty keeping a consistent daily routine?",
    "Low energy during the day?",
    "Reduced participation in hobbies or activities?",
    "Difficulty managing stress?",
    "Changes in social engagement?"
)

fun placeholderPhysicalQuestions(): List<String> = listOf(
    "Muscle stiffness or rigidity?",
    "Difficulty with balance?",
    "Slowness of movement?",
    "Shakiness or tremor?",
    "Fatigue during physical activity?",
    "Difficulty standing up from sitting?",
    "Problems with coordination?"
)

fun placeholderPsychologicalQuestions(): List<String> = listOf(
    "Feeling anxious or worried?",
    "Feeling depressed or sad?",
    "Difficulty concentrating?",
    "Feeling overwhelmed?",
    "Loss of motivation?",
    "Mood swings or irritability?",
    "Feeling mentally fatigued?"
)

data class MedOption(
    val name: String,
    val dosage: String,
    val frequency: String
)


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicationsScreen(navController: NavHostController) {

    // Keep your list for names (defaults are no longer forced)
    val medOptions = remember {
        listOf(
            MedOption("Carbidopa/Levodopa (Sinemet)", "", ""),
            MedOption("Pramipexole (Mirapex)", "", ""),
            MedOption("Ropinirole (Requip)", "", ""),
            MedOption("Rotigotine (Neupro patch)", "", ""),
            MedOption("Apomorphine (Apokyn)", "", ""),
            MedOption("Rasagiline (Azilect)", "", ""),
            MedOption("Selegiline (Eldepryl/Zelapar)", "", ""),
            MedOption("Safinamide (Xadago)", "", ""),
            MedOption("Entacapone (Comtan)", "", ""),
            MedOption("Opicapone (Ongentys)", "", ""),
            MedOption("Benztropine (Cogentin)", "", ""),
            MedOption("Trihexyphenidyl (Artane)", "", ""),
            MedOption("Amantadine (Symmetrel)", "", ""),
            MedOption("Amantadine ER (Gocovri)", "", "")
        )
    }

    val frequencyOptions = remember {
        listOf(
            "Once daily",
            "2x daily",
            "3x daily",
            "4x daily",
            "Every 4 hours",
            "Every 6 hours",
            "Every 8 hours",
            "At bedtime",
            "As needed"
        )
    }

    var medExpanded by remember { mutableStateOf(false) }
    var selectedMed by remember { mutableStateOf<MedOption?>(null) }

    var freqExpanded by remember { mutableStateOf(false) }
    var selectedFrequency by remember { mutableStateOf(frequencyOptions.first()) }

    var dosageInput by remember { mutableStateOf("") }

    val context = LocalContext.current

    val selectedMeds = remember {
        mutableStateListOf<MedOption>().apply {
            addAll(loadSelectedMeds(context))
        }
    }

    var showGreatJobDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Medications") }) },
        bottomBar = {
            BottomAppBar {
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { navController.popBackStack() }) { Text("Back") }
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Select a medication, then enter your dosage and frequency.")

            // --- Medication dropdown ---
            ExposedDropdownMenuBox(
                expanded = medExpanded,
                onExpandedChange = { medExpanded = !medExpanded }
            ) {
                OutlinedTextField(
                    value = selectedMed?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Medication") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = medExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )

                ExposedDropdownMenu(
                    expanded = medExpanded,
                    onDismissRequest = { medExpanded = false }
                ) {
                    medOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.name) },
                            onClick = {
                                selectedMed = option
                                // reset fields when choosing a new med
                                dosageInput = ""
                                selectedFrequency = frequencyOptions.first()
                                medExpanded = false
                            }
                        )
                    }
                }
            }

            // --- Dosage textbox ---
            OutlinedTextField(
                value = dosageInput,
                onValueChange = { dosageInput = it },
                label = { Text("Dosage") },
                placeholder = { Text("e.g., 25/100 mg or 2 mg") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
            )

            // --- Frequency dropdown ---
            ExposedDropdownMenuBox(
                expanded = freqExpanded,
                onExpandedChange = { freqExpanded = !freqExpanded }
            ) {
                OutlinedTextField(
                    value = selectedFrequency,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Frequency") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = freqExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )

                ExposedDropdownMenu(
                    expanded = freqExpanded,
                    onDismissRequest = { freqExpanded = false }
                ) {
                    frequencyOptions.forEach { freq ->
                        DropdownMenuItem(
                            text = { Text(freq) },
                            onClick = {
                                selectedFrequency = freq
                                freqExpanded = false
                            }
                        )
                    }
                }
            }

            // --- Add Medication ---
            Button(
                onClick = {
                    val med = selectedMed ?: return@Button
                    val dosage = dosageInput.trim()
                    val freq = selectedFrequency.trim()

                    // store user-defined prescription in the same MedOption model
                    val customMed = MedOption(
                        name = med.name,
                        dosage = if (dosage.isBlank()) "(not set)" else dosage,
                        frequency = freq
                    )

                    // prevent duplicates (same med name)
                    if (!selectedMeds.any { it.name == customMed.name }) {
                        selectedMeds.add(customMed)
                        saveSelectedMeds(context, selectedMeds)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = selectedMed != null
            ) {
                Text("Add Medication")
            }

            Divider()

            Text("My Medications Today:")

            if (selectedMeds.isEmpty()) {
                Text("No medications selected yet.")
            } else {
                // No nested LazyColumn — keep one scroll container (the outer Column)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    selectedMeds.forEach { med ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(med.name)
                                    Text("• ${med.dosage} • ${med.frequency}")
                                }
                                IconButton(
                                    onClick = {
                                        selectedMeds.remove(med)
                                        saveSelectedMeds(context, selectedMeds)
                                    }
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Remove")
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = { navController.navigate("Medication_history") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Medication History")
            }

            Button(
                onClick = { showGreatJobDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Confirm")
            }
        }
    }

    if (showGreatJobDialog) {
        AlertDialog(
            onDismissRequest = { showGreatJobDialog = false },
            title = { Text("Great Job!") },
            text = { Text("Medication selection saved (placeholder).") },
            confirmButton = {
                Button(onClick = { showGreatJobDialog = false }) { Text("OK") }
            }
        )
    }
}

private const val PREFS_NAME = "gloveworks_prefs"
private const val KEY_SELECTED_MEDS = "selected_meds_today_v1"

private fun saveSelectedMeds(context: Context, meds: List<MedOption>) {
    val arr = JSONArray()
    meds.forEach { med ->
        val obj = JSONObject().apply {
            put("name", med.name)
            put("dosage", med.dosage)
            put("frequency", med.frequency)
        }
        arr.put(obj)
    }

    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_SELECTED_MEDS, arr.toString())
        .apply()
}

private fun loadSelectedMeds(context: Context): List<MedOption> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_SELECTED_MEDS, null) ?: return emptyList()

    return try {
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                add(
                    MedOption(
                        name = obj.optString("name"),
                        dosage = obj.optString("dosage"),
                        frequency = obj.optString("frequency")
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun clearSelectedMeds(context: Context) {
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .remove(KEY_SELECTED_MEDS)
        .apply()
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicationsHistoryScreen(navController: NavHostController) {
    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Medication History") }) },
        bottomBar = {
            BottomAppBar {
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { navController.popBackStack() }) { Text("Back") }
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Text("Coming soon!")
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserInfoScreen(navController: NavHostController) {
    val context = LocalContext.current
    val sharedPref = context.getSharedPreferences(
        "gloveworks_prefs",
        Context.MODE_PRIVATE
    )

    val userId = sharedPref.getString("user_id", null)
    val userType =
        if (userId?.startsWith("glw_anon_") == true) "Anonymous" else "GloveWorks Participant"

    val database = FirebaseDatabase.getInstance().reference
    var userInfo by remember { mutableStateOf<Map<String, Any>?>(null) }

    // Load user data from Firebase
    LaunchedEffect(userId) {
        userId?.let {
            database.child("users").child(it).get().addOnSuccessListener { snapshot ->
                userInfo = snapshot.value as? Map<String, Any>
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("User Information") }
            )
        },
        bottomBar = {
            BottomAppBar {
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { navController.popBackStack() }) {
                    Text("Back")
                }
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            if (userId == null) {
                Text("No user found.")
                return@Column
            }

            Text("User Type: $userType")
            Text("User ID: $userId")

            Spacer(modifier = Modifier.height(16.dp))

            userInfo?.let { info ->
                val profile = info["profile"] as? Map<*, *>
                when (userType) {
                    "GloveWorks Participant" -> {
                        Text("Name: ${profile?.get("name") ?: "N/A"} ${profile?.get("lastName") ?: ""}")
                        Text("Email: ${profile?.get("email") ?: "N/A"}")
                        Text("Date of Birth: ${profile?.get("dob") ?: "N/A"}")
                        Text("Phone: ${profile?.get("phone") ?: "N/A"}")

                        val pdqAnswers = info["pdq"] as? List<*>
                        if (pdqAnswers != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("PDQ-8 Questionnaire: Submitted")
                        }
                    }

                    "Anonymous" -> {
                        Text("Age: ${profile?.get("age") ?: "N/A"}")
                        Text("Diagnosed with PD: ${profile?.get("diagnosedWithPD") ?: "N/A"}")

                        val consent = info["consent"] as? Map<*, *>
                        if (consent != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Sharing Motion: ${consent["motion"]}")
                            Text("Sharing Voice: ${consent["voice"]}")
                        }
                    }
                }
            } ?: run {
                Text("Loading user data...")
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(onClick = {
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                sharedPref.edit()
                    .clear()
                    .remove("motion_session_id")
                    .remove("voice_session_id")
                    .apply()
                context.startActivity(intent)
            }) {
                Text("Reset and Re-Onboard")
            }
        }
    }
}









