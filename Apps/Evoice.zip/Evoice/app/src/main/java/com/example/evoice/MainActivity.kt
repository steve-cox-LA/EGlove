package com.example.Evoice

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {

    private val sampleRate = 44100
    private val frameSize = 1024
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VoiceAppUI() }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun VoiceAppUI() {
        var isRecording by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Idle") }
        var jitter by remember { mutableStateOf(0.0) }
        var shimmer by remember { mutableStateOf(0.0) }
        var duration by remember { mutableStateOf(5f) } // seconds

        val amplitudeData = remember { mutableStateListOf<Float>() }
        val frequencyData = remember { mutableStateListOf<Float>() }

        val context = this@MainActivity
        val audioPermissionLauncher =
            rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                if (!granted) {
                    status = "Microphone permission denied"
                }
            }

        Scaffold { padding ->
            Column(modifier = Modifier.padding(padding).padding(16.dp)) {
                Text("Status: $status")
                Spacer(modifier = Modifier.height(8.dp))

                Text("Recording Duration: ${duration.toInt()} sec")
                Slider(
                    value = duration,
                    onValueChange = { duration = it },
                    valueRange = 1f..15f,
                    steps = 14
                )
                Spacer(modifier = Modifier.height(8.dp))

                Button(onClick = {
                    val permissionStatus = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    )
                    if (permissionStatus != PackageManager.PERMISSION_GRANTED) {
                        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        return@Button
                    }

                    if (isRecording) return@Button
                    isRecording = true
                    status = "Recording..."
                    amplitudeData.clear()
                    frequencyData.clear()

                    scope.launch {
                        recordAudioLive(amplitudeData, frequencyData, duration.toInt())
                        val (jit, shim) = withContext(Dispatchers.Default) {
                            analyzeJitterShimmer(amplitudeData.toList(), frequencyData.toList())
                        }
                        jitter = jit
                        shimmer = shim
                        status = "Done"
                        isRecording = false
                    }
                }) {
                    Text("Record + Analyze")
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("Jitter: ${"%.3f".format(jitter)}")
                Text("Shimmer: ${"%.3f".format(shimmer)}")
                Spacer(modifier = Modifier.height(16.dp))

                Text("Amplitude over time")
                LineGraph(amplitudeData.toList(), Color.Green, Modifier.fillMaxWidth().height(150.dp))

                Text("Pitch over time")
                LineGraph(frequencyData.toList(), Color.Magenta, Modifier.fillMaxWidth().height(150.dp))
            }
        }
    }

    @Composable
    fun LineGraph(data: List<Float>, color: Color, modifier: Modifier = Modifier) {
        if (data.isEmpty()) return
        Canvas(modifier = modifier) {
            val widthPerPoint = size.width / (data.size - 1).coerceAtLeast(1)
            val minVal = data.minOrNull() ?: 0f
            val maxVal = data.maxOrNull() ?: 1f
            val range = (maxVal - minVal).coerceAtLeast(1f)

            var prevX = 0f
            var prevY = size.height * (1f - (data[0] - minVal) / range)

            for (i in 1 until data.size) {
                val x = i * widthPerPoint
                val y = size.height * (1f - (data[i] - minVal) / range)
                drawLine(color, Offset(prevX, prevY), Offset(x, y), strokeWidth = 2f)
                prevX = x
                prevY = y
            }
        }
    }

    private suspend fun recordAudioLive(
        amplitudeData: MutableList<Float>,
        frequencyData: MutableList<Float>,
        durationSeconds: Int
    ) {
        withContext(Dispatchers.IO) {
            val context = this@MainActivity
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) != PackageManager.PERMISSION_GRANTED
            ) return@withContext

            val minBuffer = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuffer
            )

            try { audioRecord.startRecording() } catch (e: SecurityException) { return@withContext }

            val buffer = ShortArray(frameSize)
            val totalFrames = durationSeconds * sampleRate / frameSize

            repeat(totalFrames) {
                val read = audioRecord.read(buffer, 0, buffer.size)
                if (read > 0) {
                    val rms = sqrt(buffer.take(read).map { it * it.toFloat() }.average()).toFloat()
                    amplitudeData.add(rms)
                    val pitch = estimatePitch(buffer.take(read).toShortArray(), sampleRate)
                    frequencyData.add(pitch)
                }
            }

            audioRecord.stop()
            audioRecord.release()
        }
    }

    private fun estimatePitch(buffer: ShortArray, sampleRate: Int): Float {
        var crossings = 0
        for (i in 1 until buffer.size) {
            if ((buffer[i - 1] > 0 && buffer[i] <= 0) || (buffer[i - 1] < 0 && buffer[i] >= 0)) {
                crossings++
            }
        }
        return (crossings * sampleRate / (2.0 * buffer.size)).toFloat()
    }

    private fun analyzeJitterShimmer(amplitude: List<Float>, pitch: List<Float>): Pair<Double, Double> {
        val periods = pitch.filter { it.isFinite() && it > 20f }.map { 1.0 / it }
        val jitter = if (periods.size >= 2) {
            val diffs = periods.zipWithNext { a, b -> abs(a - b) }
            diffs.average() / periods.average()
        } else Double.NaN

        val shimmer = if (amplitude.size >= 2) {
            val diffs = amplitude.zipWithNext { a, b -> abs(a - b) }
            diffs.average() / amplitude.average()
        } else Double.NaN

        return Pair(jitter, shimmer)
    }
}

