package com.example.gloveworks30

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Window
import androidx.activity.ComponentActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.*

class SplashActivity : ComponentActivity() {
    private val splashScope = CoroutineScope(Dispatchers.Main)
    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setBackgroundDrawableResource(android.R.color.black)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        ensureFirebaseAuthThenContinue()
    }
    private fun ensureFirebaseAuthThenContinue() {
        val auth = FirebaseAuth.getInstance()
        // Already signed in
        if (auth.currentUser != null) {
            splashScope.launch { goToMainAfterDelay() }
            return
        }
        // Sign in anonymously(satisfies RTDB rules: auth.uid != null)
        auth.signInAnonymously()
            .addOnSuccessListener {
                Log.d("FirebaseAuth", "Anonymous sign-in OK uid=${auth.currentUser?.uid}")
                splashScope.launch { goToMainAfterDelay() }
            }
            .addOnFailureListener { e ->
                Log.e("FirebaseAuth", "Anonymous sign-in FAILED", e)
                splashScope.launch { goToMainAfterDelay() }
            }
    }
    private suspend fun goToMainAfterDelay() {
        delay(2000)
        startActivity(Intent(this@SplashActivity, MainActivity::class.java))
        finish()
    }
    override fun onDestroy() {
        splashScope.cancel()
        super.onDestroy()
    }
}
