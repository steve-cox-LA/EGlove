package com.example.gloveworks50.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gloveworks50.auth.FirebaseAuthManager
import com.example.gloveworks50.data.FirebaseUploader
import com.example.gloveworks50.data.GaitEpoch
import com.example.gloveworks50.data.GaitSession
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.StorageKeys
import com.example.gloveworks50.data.UploadQueue
import com.example.gloveworks50.data.isResearchOptedIn
import com.example.gloveworks50.db.GloveworksRepository
import com.example.gloveworks50.sensor.AccelerometerSensor
import com.example.gloveworks50.ui.GloveworksInfoDialog
import com.example.gloveworks50.ui.GloveworksTopBar
import com.example.gloveworks50.ui.JitterShimmerCard
import com.example.gloveworks50.ui.MonitorGraphCard
import com.example.gloveworks50.ui.SharedEpochFreqTrendGraph
import com.example.gloveworks50.ui.SharedFFTGraph
import com.example.gloveworks50.ui.fmtDec
import com.example.gloveworks50.util.FFTUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sqrt
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

private const val TOTAL_EPOCHS      = 15
private const val EPOCH_DURATION_MS = 2000L
private const val COUNTDOWN_SECONDS = 10

private val GAIT_INFO = """
• Tap Start to begin. A 10-second countdown will appear.
• Place your phone in your pocket during the countdown.
• Walk normally for ~${TOTAL_EPOCHS * EPOCH_DURATION_MS / 1000}s while the app records.
• The accelerometer samples at ${FFTUtil.GAIT_SAMPLE_RATE.toInt()} Hz across $TOTAL_EPOCHS x ${EPOCH_DURATION_MS/1000}s epochs.
• Two parallel FFT passes are computed per session:
    Pass 1 — $TOTAL_EPOCHS non-overlapping ${EPOCH_DURATION_MS/1000}s windows
    Pass 2 — overlapping windows with 1s step
• Jitter  = normalized variation of dominant step frequency epoch-to-epoch.
• Shimmer = normalized variation of signal amplitude epoch-to-epoch.
• Tap Stop at any time to end early.
• Tap View History to see past sessions and trends.
""".trim()

private sealed class GaitState {
    object Idle        : GaitState()
    data class Countdown(val secondsLeft: Int) : GaitState()
    data class Recording(val epoch: Int)       : GaitState()
    object Analysing   : GaitState()
    data class Done(val status: String)        : GaitState()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalTime::class)
@Composable
fun GaitMonitorScreen(
    repository: GloveworksRepository,
    uploadQueue: UploadQueue,
    onBack: () -> Unit,
    onHistory: () -> Unit
) {
    val storage        = remember { LocalStorage() }
    val sensor         = remember { AccelerometerSensor() }
    val uploader       = remember { FirebaseUploader() }
    val authManager    = remember { FirebaseAuthManager() }
    val coroutineScope = rememberCoroutineScope()
    var gaitState      by remember { mutableStateOf<GaitState>(GaitState.Idle) }
    var analysisResult by remember { mutableStateOf<FFTUtil.EpochAnalysisResult?>(null) }
    var sensorDataList by remember { mutableStateOf<List<Pair<Float, Float>>>(emptyList()) }
    var fftDataList    by remember { mutableStateOf<List<Pair<Float, Float>>>(emptyList()) }
    var epochFreqList  by remember { mutableStateOf<List<Pair<Int, Float>>>(emptyList()) }
    var elapsedTime    by remember { mutableStateOf(0f) }
    var showInfo       by remember { mutableStateOf(false) }
    var isCollecting   = false
    var currentSignal  = mutableListOf<Float>()
    var allSignal      = mutableListOf<Float>()

    fun onSensorData(x: Float, y: Float, z: Float) {
        if (!isCollecting) return
        elapsedTime += (1f / FFTUtil.GAIT_SAMPLE_RATE)
        val sample = x + y + z
        currentSignal.add(sample)
        allSignal.add(sample)
        val magnitude = sqrt(x * x + y * y + z * z)
        sensorDataList = (sensorDataList + Pair(elapsedTime, magnitude))
            .filter { it.first >= elapsedTime - 2f }
    }

    fun stopSession() {
        isCollecting = false
        sensor.stop()
        elapsedTime = 0f
        gaitState = GaitState.Idle
    }

    fun startSession() {
        sensorDataList = emptyList()
        fftDataList    = emptyList()
        epochFreqList  = emptyList()
        elapsedTime    = 0f
        analysisResult = null
        allSignal      = mutableListOf()
        isCollecting   = false

        coroutineScope.launch {
            for (sec in COUNTDOWN_SECONDS downTo 1) {
                gaitState = GaitState.Countdown(sec)
                delay(1000L)
            }
            isCollecting = true
            sensor.start(::onSensorData)

            val collectedEpochs = mutableListOf<GaitEpoch>()
            val epochPitches    = mutableListOf<Float>()
            val epochAmplitudes = mutableListOf<Float>()

            for (epochIndex in 1..TOTAL_EPOCHS) {
                if (!isCollecting) break
                gaitState = GaitState.Recording(epochIndex)
                currentSignal = mutableListOf()
                val epochStart = Clock.System.now().toEpochMilliseconds()
                while (isCollecting) {
                    if (Clock.System.now().toEpochMilliseconds() - epochStart >= EPOCH_DURATION_MS) break
                    delay(20)
                }
                if (!isCollecting) break
                val fftResult    = FFTUtil.getFFT(currentSignal.toList(), FFTUtil.GAIT_SAMPLE_RATE)
                fftDataList      = fftResult
                val dominantFreq = FFTUtil.dominantFrequency(fftResult)
                val rms          = FFTUtil.calculateRMSFloat(currentSignal.toList())
                epochPitches.add(dominantFreq)
                epochAmplitudes.add(rms)
                epochFreqList = epochFreqList + Pair(epochIndex, dominantFreq)
                collectedEpochs.add(GaitEpoch(epochIndex, dominantFreq))
            }

            sensor.stop(); isCollecting = false
            gaitState = GaitState.Analysing

            val overlappingPitches = FFTUtil.overlappingWindowFrequencies(allSignal.toList())
            val result = FFTUtil.analyseEpochs(epochPitches + overlappingPitches, epochAmplitudes)
            analysisResult = result

            val userId    = storage.getString(StorageKeys.USER_ID) ?: "unknown"
            val sessionId = "gait_${userId}_${Clock.System.now().toEpochMilliseconds()}"
            storage.putString(StorageKeys.MOTION_SESSION_ID, sessionId)

            val statusStr = if (result != null)
                "Saved ✓  J: ${fmtDec(result.jitter, 4)}  S: ${fmtDec(result.shimmer, 4)}"
            else "Saved ✓"

            val session = GaitSession(
                sessionId      = sessionId,
                userId         = userId,
                timestampMs    = Clock.System.now().toEpochMilliseconds(),
                epochs         = collectedEpochs,
                totalVariation = result?.jitter ?: 0.0,
                shimmer        = result?.shimmer ?: 0.0
            )
            try {
                repository.insertGaitSession(session)
                gaitState = GaitState.Done(statusStr)
            } catch (e: Exception) {
                gaitState = GaitState.Done("Local save failed"); return@launch
            }
            if (!storage.isResearchOptedIn()) return@launch
            gaitState = GaitState.Done("Uploading...")
            val uid = authManager.currentUid ?: authManager.signInAnonymously()
            if (uid == null) {
                uploadQueue.enqueueGaitSession(sessionId)
                gaitState = GaitState.Done("$statusStr (queued)"); return@launch
            }
            uploader.uploadGaitSession(uid, session)
                .onSuccess { gaitState = GaitState.Done("Saved & uploaded ✓") }
                .onFailure { uploadQueue.enqueueGaitSession(sessionId); gaitState = GaitState.Done("$statusStr (queued)") }
        }
    }

    DisposableEffect(Unit) { onDispose { sensor.stop() } }

    val isRunning    = gaitState is GaitState.Countdown ||
            gaitState is GaitState.Recording || gaitState is GaitState.Analysing
    val currentEpoch = (gaitState as? GaitState.Recording)?.epoch ?: 0

    Scaffold(
        topBar = {
            GloveworksTopBar(title = "Gait Monitor",
                onBack = { stopSession(); onBack() }, onInfo = { showInfo = true })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val (statusText, statusColor) = when (val s = gaitState) {
                is GaitState.Idle      -> "Ready — walk for ~${TOTAL_EPOCHS * EPOCH_DURATION_MS / 1000}s" to
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                is GaitState.Countdown -> "Place phone in pocket — starting in ${s.secondsLeft}s..." to
                        MaterialTheme.colorScheme.primary
                is GaitState.Recording -> "Recording — epoch ${s.epoch} / $TOTAL_EPOCHS  •  " +
                        "${s.epoch * EPOCH_DURATION_MS / 1000}s / ${TOTAL_EPOCHS * EPOCH_DURATION_MS / 1000}s" to
                        MaterialTheme.colorScheme.error
                is GaitState.Analysing -> "Analysing results..." to MaterialTheme.colorScheme.primary
                is GaitState.Done      -> s.status to MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            }
            Text(statusText, style = MaterialTheme.typography.bodyMedium,
                color = statusColor, textAlign = TextAlign.Center)

            val countdown = gaitState as? GaitState.Countdown
            if (countdown != null) {
                Text(countdown.secondsLeft.toString(), style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold, fontSize = 80.sp,
                    color = MaterialTheme.colorScheme.secondary)
            }

            if (gaitState is GaitState.Recording) {
                LinearProgressIndicator(
                    progress = { currentEpoch.toFloat() / TOTAL_EPOCHS },
                    modifier = Modifier.fillMaxWidth(),
                    color    = MaterialTheme.colorScheme.secondary)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Button(onClick = { startSession() }, enabled = !isRunning,
                    modifier = Modifier.weight(1f).height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) { Text("Start", color = MaterialTheme.colorScheme.onSecondary) }
                Button(onClick = { stopSession() }, enabled = isRunning,
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text("Stop") }
            }

            val result = analysisResult
            if (result != null) { JitterShimmerCard(result.jitter, result.shimmer) }

            MonitorGraphCard("Real-Time Acceleration (m/s²)", Modifier.height(150.dp)) {
                GaitRealTimeGraph(sensorDataList)
            }
            MonitorGraphCard(
                "Fourier Amplitude vs Frequency (Hz) — Epoch $currentEpoch",
                Modifier.height(150.dp)
            ) { SharedFFTGraph(fftDataList) }
            MonitorGraphCard("Peak Frequency per Epoch (Hz)", Modifier.height(180.dp)) {
                SharedEpochFreqTrendGraph(epochFreqList, TOTAL_EPOCHS)
            }

            OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("View Session History & Trends")
            }
        }
    }
    if (showInfo) GloveworksInfoDialog("Gait Monitor — How It Works", GAIT_INFO) { showInfo = false }
}

// Gait-specific real-time graph
@Composable
private fun GaitRealTimeGraph(data: List<Pair<Float, Float>>) {
    val lineColor  = MaterialTheme.colorScheme.primary
    val gridColor  = MaterialTheme.colorScheme.surfaceVariant
    val labelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
    val measurer   = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 9.sp, color = labelColor)
    Canvas(modifier = Modifier.fillMaxSize()) {
        val leftPad   = 44f
        val bottomPad = 20f
        val plotW     = size.width  - leftPad
        val plotH     = size.height - bottomPad
        val minY   = if (data.isEmpty()) -30f else data.minOf { it.second }.coerceAtMost(-1f)
        val maxY   = if (data.isEmpty())  30f else data.maxOf { it.second }.coerceAtLeast( 1f)
        val rangeY = maxY - minY
        listOf(minY, 0f, maxY).forEach { v ->
            val y = plotH - ((v - minY) / rangeY) * plotH
            drawLine(gridColor, Offset(leftPad, y), Offset(size.width, y), strokeWidth = 1f)
            val t = measurer.measure(fmtDec(v.toDouble(), 1), labelStyle)
            drawText(t, topLeft = Offset(leftPad - t.size.width - 4f, y - t.size.height / 2f))
        }
        if (data.size >= 2) {
            val minT = data.minOf { it.first }
            val maxT = data.maxOf { it.first }.coerceAtLeast(minT + 0.001f)
            listOf(0f, 0.5f, 1f).forEach { frac ->
                val tVal = minT + frac * (maxT - minT)
                val x    = leftPad + frac * plotW
                val t    = measurer.measure("${fmtDec(tVal.toDouble(), 1)}s", labelStyle)
                drawText(t, topLeft = Offset(x - t.size.width / 2f, plotH + 4f))
            }
        }
        if (data.size < 2) return@Canvas
        val minT = data.minOf { it.first }
        val maxT = data.maxOf { it.first }.coerceAtLeast(minT + 0.001f)
        val path = Path()
        data.forEachIndexed { i, (t, m) ->
            val x = leftPad + ((t - minT) / (maxT - minT)) * plotW
            val y = plotH   - ((m - minY) / rangeY) * plotH
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, lineColor, style = Stroke(width = 3f))
    }
}