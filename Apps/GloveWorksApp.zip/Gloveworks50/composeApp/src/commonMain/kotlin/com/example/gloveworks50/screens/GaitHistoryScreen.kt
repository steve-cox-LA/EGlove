package com.example.gloveworks50.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.StorageKeys
import com.example.gloveworks50.db.GloveworksRepository
import com.example.gloveworks50.ui.GloveworksTopBar
import com.example.gloveworks50.ui.SharedMetricTrendGraph

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GaitHistoryScreen(
    repository: GloveworksRepository,
    onBack: () -> Unit
) {
    val storage  = remember { LocalStorage() }
    val userId   = storage.getString(StorageKeys.USER_ID) ?: "unknown"
    val sessions = remember {
        repository.getGaitSessionsByUser(userId).sortedBy { it.timestampMs }
    }

    Scaffold(
        topBar = { GloveworksTopBar(title = "Gait History", onBack = onBack, onInfo = null) }
    ) { innerPadding ->
        if (sessions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding),
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("No gait sessions recorded yet.", textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    Text("Complete a session on the Gait Monitor screen to see trends here.",
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(innerPadding)
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Jitter Trend", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold)
                Text("Epoch-to-epoch pitch period variation across sessions. Lower = more consistent.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Card(modifier = Modifier.fillMaxWidth().height(200.dp),
                    elevation = CardDefaults.cardElevation(2.dp)) {
                    Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                        SharedMetricTrendGraph(sessions.map { it.totalVariation.toFloat() })
                    }
                }

                Text("Shimmer Trend", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold)
                Text("Epoch-to-epoch amplitude variation across sessions. Lower = more consistent.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Card(modifier = Modifier.fillMaxWidth().height(200.dp),
                    elevation = CardDefaults.cardElevation(2.dp)) {
                    Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                        SharedMetricTrendGraph(sessions.map { it.shimmer.toFloat() })
                    }
                }
            }
        }
    }
}