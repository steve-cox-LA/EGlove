package com.example.gloveworks50.audio


expect class AudioRecorder() {
    fun start(onAudioData: (samples: ShortArray) -> Unit)
    fun stop()
    var isRecording: Boolean
        private set
}