package com.example.gloveworks50.sensor



expect class AccelerometerSensor() {
    fun start(onData: (x: Float, y: Float, z: Float) -> Unit)
    fun stop()
}