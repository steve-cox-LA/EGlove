package com.example.gloveworks50.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gloveworks50.getPlatform

data class HomeCardItem(
    val title: String,
    val icon: ImageVector,
    val description: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    appName: String = "Española GloveWorks",
    onExit: () -> Unit = {},
    onNavigate: (String) -> Unit = {}
) {
    val isAndroid = getPlatform().name.startsWith("Android")

    val cards = listOf(
        HomeCardItem("Gait Monitor",       Icons.AutoMirrored.Filled.DirectionsWalk, "Track Walking Patterns"),
        HomeCardItem("Voice Monitor",      Icons.Default.Mic,                        "Analyze Vocal Changes"),
        HomeCardItem("Glove Control",      Icons.Default.PanTool,                    "Manage Glove Device"),
        HomeCardItem("Symptom Tracker",    Icons.Default.MonitorHeart,               "Log Daily Symptoms"),
        HomeCardItem("Medication Tracker", Icons.Default.Medication,                 "Track Medications"),
        HomeCardItem("Settings",           Icons.Default.Settings,                   "App Settings")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text       = appName,
                        fontWeight = FontWeight.Bold,
                        fontSize   = 22.sp,
                        textAlign  = TextAlign.Center,
                        color      = MaterialTheme.colorScheme.secondary,
                        modifier   = Modifier.fillMaxWidth()
                    )
                },
                actions = {
                    if (isAndroid) {
                        IconButton(onClick = onExit) {
                            Icon(
                                imageVector        = Icons.AutoMirrored.Filled.ExitToApp,
                                contentDescription = "Exit",
                                tint               = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.secondary
                )
            )
        }
    ) { innerPadding ->
        LazyVerticalGrid(
            columns          = GridCells.Fixed(2),
            modifier         = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement   = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(cards) { card ->
                HomeCard(card = card, onClick = { onNavigate(card.title) })
            }
        }
    }
}

@Composable
private fun HomeCard(card: HomeCardItem, onClick: () -> Unit) {
    ElevatedCard(
        onClick   = onClick,
        modifier  = Modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        shape     = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp),
        colors    = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier            = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape    = RoundedCornerShape(12.dp),
                color    = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.size(52.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        imageVector        = card.icon,
                        contentDescription = card.title,
                        tint               = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier           = Modifier.size(28.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text       = card.title,
                style      = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                textAlign  = TextAlign.Center,
                color      = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text      = card.description,
                style     = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color     = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}