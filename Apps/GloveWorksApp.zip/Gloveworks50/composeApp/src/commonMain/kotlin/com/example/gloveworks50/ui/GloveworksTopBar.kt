package com.example.gloveworks50.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GloveworksTopBar(
    title: String,
    onBack: () -> Unit,
    onInfo: (() -> Unit)? = null
) {
    TopAppBar(
        title = {
            Text(
                text      = title,
                fontWeight = FontWeight.Bold,
                fontSize   = 22.sp,
                textAlign  = TextAlign.Center,
                color      = MaterialTheme.colorScheme.secondary,
                modifier   = Modifier.fillMaxWidth()
            )
        },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector        = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back"
                )
            }
        },
        actions = {
            if (onInfo != null) {
                IconButton(onClick = onInfo) {
                    Icon(
                        imageVector        = Icons.Outlined.Info,
                        contentDescription = "More Info"
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor             = MaterialTheme.colorScheme.primary,
            titleContentColor          = MaterialTheme.colorScheme.secondary,
            navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
            actionIconContentColor     = MaterialTheme.colorScheme.onPrimary
        )
    )
}

@Composable
fun GloveworksInfoDialog(
    title: String,
    body: String,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector        = Icons.Outlined.Info,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.secondary
            )
        },
        title   = { Text(title, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary) },
        text    = { Text(body) },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Got it", color = MaterialTheme.colorScheme.secondary)
            }
        }
    )
}