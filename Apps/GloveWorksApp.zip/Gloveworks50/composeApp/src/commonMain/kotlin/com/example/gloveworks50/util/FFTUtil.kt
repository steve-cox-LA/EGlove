package com.example.gloveworks50.util

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object FFTUtil {

    // ── Global sample-rate constants ──────────────────────────────────────────
    const val GAIT_SAMPLE_RATE: Float = 50f      // Hz — accelerometer
    const val VOICE_SAMPLE_RATE: Int  = 44100    // Hz — microphone


    // ── SHARED FFT CORE ───────────────────────────────────────────────────────
    /**
     * Compute a power-spectrum FFT for any numeric input (Float for gait,
     * Short for voice).  The signal is mean-subtracted (detrended) before
     * the transform so DC drift does not dominate the result.
     *
     * @param signal     Raw samples as any [Number] subtype.
     * @param sampleRate Sampling rate in Hz (use [GAIT_SAMPLE_RATE] or
     *                   [VOICE_SAMPLE_RATE] — never hard-code the value).
     * @return List of (frequencyHz, power) pairs covering 0 … Nyquist.
     */
    fun getFFT(signal: List<Number>, sampleRate: Float): List<Pair<Float, Float>> {
        if (signal.size < 2) return emptyList()

        // Detrend: subtract the mean so DC offset doesn't dominate
        val doubles   = signal.map { it.toDouble() }
        val mean      = doubles.average()
        val detrended = doubles.map { it - mean }

        // Zero-pad to next power of two
        val n       = nextPow2(detrended.size)
        val realArr = DoubleArray(n) { if (it < detrended.size) detrended[it] else 0.0 }
        val imagArr = DoubleArray(n) { 0.0 }

        fft(realArr, imagArr)

        // Build (frequency, power) pairs for the positive half of the spectrum
        return (0 until n / 2).map { i ->
            val freq  = i.toFloat() * sampleRate / n
            val power = (realArr[i] * realArr[i] + imagArr[i] * imagArr[i]).toFloat()
            Pair(freq, power)
        }
    }

    /** Returns the dominant (peak-power) frequency above 0 Hz. */
    fun dominantFrequency(fftResult: List<Pair<Float, Float>>): Float =
        fftResult.filter { it.first > 0f }.maxByOrNull { it.second }?.first ?: 0f


    // ── SHARED EPOCH ANALYSIS ─────────────────────────────────────────────────
    /**
     * Unified result for both gait and voice epoch analysis.
     *
     * The two metrics are computed identically for both sensors:
     *
     *   Jitter  — normalized TV of pitch periods (T = 1/f).
     *             Captures how much dominant frequency varies epoch-to-epoch.
     *
     *   Shimmer — normalized TV of amplitude (RMS).
     *             Captures how much signal strength varies epoch-to-epoch.
     *
     * "Normalized TV" means:  mean |x[i+1] - x[i]|  /  mean(x)
     *
     * Both gait and voice reduce to the same question:
     * how consistently is this sensor producing the same signal over time?
     *
     * [periods]  — per-epoch pitch periods in seconds (1 / dominantFreqHz).
     * [jitter]   — normalized TV of periods  (dimensionless ratio).
     * [shimmer]  — normalized TV of amplitude (dimensionless ratio).
     */
    data class EpochAnalysisResult(
        val jitter:  Double,
        val shimmer: Double,
        val periods: List<Double>
    )

    /**
     * Analyse epoch-level pitch and amplitude for either sensor.
     *
     * For **gait**: pass per-epoch dominant accelerometer frequencies and RMS magnitudes.
     * For **voice**: pass per-epoch dominant microphone frequencies and RMS amplitudes.
     *
     * @param epochPitches     Dominant frequency (Hz) from each epoch's FFT.
     * @param epochAmplitudes  RMS amplitude from each epoch.
     * @return [EpochAnalysisResult] or null if there is insufficient data.
     */
    fun analyseEpochs(
        epochPitches: List<Float>,
        epochAmplitudes: List<Float>
    ): EpochAnalysisResult? {
        if (epochPitches.size < 2 || epochAmplitudes.size < 2) return null

        // Convert dominant frequencies (Hz) -> periods (seconds): T = 1 / f
        val periods = epochPitches
            .filter { it.isFinite() && it > 0f }
            .map { 1.0 / it }

        val jitter  = normalizedTV(periods)
        val shimmer = normalizedTV(epochAmplitudes.map { it.toDouble() })

        return EpochAnalysisResult(
            jitter  = jitter,
            shimmer = shimmer,
            periods = periods
        )
    }

    /**
     * Normalized total variation: mean absolute step / mean value.
     * This is the single shared primitive behind both jitter and shimmer.
     */
    private fun normalizedTV(values: List<Double>): Double {
        if (values.size < 2) return 0.0
        val meanAbsStep = values.zipWithNext { a, b -> absd(b - a) }.average()
        val mean        = values.average()
        return if (mean != 0.0) meanAbsStep / mean else 0.0
    }


    // ── GAIT ─────────────────────────────────────────────────────────────────
    /**
     * Sliding-window pass over the full session's magnitude stream.
     * Returns per-window dominant frequencies so [analyseEpochs] can
     * compute a second jitter estimate from a finer time resolution.
     */
    fun overlappingWindowFrequencies(
        allMagnitudes: List<Float>,
        windowSec: Float = 2f,
        stepSec: Float   = 1f
    ): List<Float> {
        val windowSize = (GAIT_SAMPLE_RATE * windowSec).toInt()
        val stepSize   = (GAIT_SAMPLE_RATE * stepSec).toInt()
        if (allMagnitudes.size < windowSize) return emptyList()
        val dominantFreqs = mutableListOf<Float>()
        var start = 0
        while (start + windowSize <= allMagnitudes.size) {
            val window = allMagnitudes.subList(start, start + windowSize)
            dominantFreqs.add(dominantFrequency(getFFT(window, GAIT_SAMPLE_RATE)))
            start += stepSize
        }
        return dominantFreqs
    }


    // ── SHARED UTILITIES ──────────────────────────────────────────────────────

    /**
     * Returns the axis (from x, y, z) with the highest variance.
     * Used for gait FFT — the dominant movement axis has the most signal
     * content while the others are mostly noise or static gravity.
     */
    fun maxVarianceAxis(
        xSamples: List<Float>,
        ySamples: List<Float>,
        zSamples: List<Float>
    ): List<Float> {
        fun variance(samples: List<Float>): Double {
            if (samples.size < 2) return 0.0
            val mean = samples.map { it.toDouble() }.average()
            return samples.sumOf { (it - mean) * (it - mean) } / samples.size
        }
        val vx = variance(xSamples)
        val vy = variance(ySamples)
        val vz = variance(zSamples)
        return when {
            vx >= vy && vx >= vz -> xSamples
            vy >= vx && vy >= vz -> ySamples
            else                 -> zSamples
        }
    }

    /** RMS of a Float signal (gait axis samples). */
    fun calculateRMSFloat(samples: List<Float>): Float {
        if (samples.isEmpty()) return 0f
        val sumSq = samples.fold(0.0) { acc, s -> acc + s * s }
        return sqrt(sumSq / samples.size).toFloat()
    }

    /** RMS of a Short signal (voice PCM samples). */
    fun calculateRMS(samples: List<Short>): Float {
        if (samples.isEmpty()) return 0f
        val sumSq = samples.fold(0.0) { acc, s -> acc + s * s }
        return sqrt(sumSq / samples.size).toFloat()
    }

    private fun absd(v: Double) = if (v < 0.0) -v else v

    private fun fft(real: DoubleArray, imag: DoubleArray) {
        val n = real.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                real[i] = real[j].also { real[j] = real[i] }
                imag[i] = imag[j].also { imag[j] = imag[i] }
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wRe = cos(ang); val wIm = sin(ang)
            var i = 0
            while (i < n) {
                var uRe = 1.0; var uIm = 0.0
                for (k in 0 until len / 2) {
                    val tRe = uRe * real[i+k+len/2] - uIm * imag[i+k+len/2]
                    val tIm = uRe * imag[i+k+len/2] + uIm * real[i+k+len/2]
                    real[i+k+len/2] = real[i+k] - tRe; imag[i+k+len/2] = imag[i+k] - tIm
                    real[i+k] += tRe; imag[i+k] += tIm
                    val newU = uRe * wRe - uIm * wIm; uIm = uRe * wIm + uIm * wRe; uRe = newU
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun nextPow2(n: Int): Int { var p = 1; while (p < n) p = p shl 1; return p }
}