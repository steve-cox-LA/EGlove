package com.example.gloveworks50.bluetooth


expect class BlePermission() {
    fun isGranted(): Boolean
    fun request(onResult: (granted: Boolean) -> Unit)
}