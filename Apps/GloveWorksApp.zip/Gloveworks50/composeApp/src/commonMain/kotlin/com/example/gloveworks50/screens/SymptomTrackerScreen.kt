package com.example.gloveworks50.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.gloveworks50.auth.FirebaseAuthManager
import com.example.gloveworks50.data.FirebaseUploader
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.StorageKeys
import com.example.gloveworks50.data.SymptomEntry
import com.example.gloveworks50.data.SymptomSubmission
import com.example.gloveworks50.data.UploadQueue
import com.example.gloveworks50.data.isResearchOptedIn
import com.example.gloveworks50.db.GloveworksRepository
import com.example.gloveworks50.ui.GloveworksInfoDialog
import com.example.gloveworks50.ui.GloveworksTopBar
import kotlinx.coroutines.launch
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

private val physicalQuestions = listOf(
    "Rate your tremor severity today (1 = minimal, 5 = severe)",
    "Rate your rigidity/stiffness today",
    "Rate your balance difficulties today",
    "Rate your walking difficulties today"
)
private val lifestyleQuestions = listOf(
    "Rate your sleep quality last night",
    "Rate your energy levels today",
    "Rate your ability to complete daily tasks today",
    "Rate your exercise/activity level today"
)
private val psychologicalQuestions = listOf(
    "Rate your mood today",
    "Rate your anxiety level today",
    "Rate your cognitive clarity today",
    "Rate your social engagement today"
)

private val symptomQuestionMap = mapOf(
    "Physical"      to physicalQuestions,
    "Lifestyle"     to lifestyleQuestions,
    "Psychological" to psychologicalQuestions
)

private val SYMPTOM_INFO = """
• Select a symptom category: Physical, Lifestyle, or Psychological.
• Tap Track to answer 4 questions for that category on a 1–5 scale.
• 1 = best / lowest severity, 5 = worst / highest severity.
• Tap Submit to save your responses — they are stored locally.
• If opted into research, your submission is also uploaded to the database. Failed uploads are queued and retried automatically.
• Tap History to review past submissions for each category.
• Tap the back arrow on any screen to go back.
""".trim()

private sealed class SymptomScreen {
    object Home : SymptomScreen()
    data class Track(val category: String) : SymptomScreen()
    data class History(val category: String) : SymptomScreen()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalTime::class)
@Composable
fun SymptomTrackerScreen(
    repository: GloveworksRepository,
    uploadQueue: UploadQueue,
    onBack: () -> Unit
) {
    val storage     = remember { LocalStorage() }
    val uploader    = remember { FirebaseUploader() }
    val authManager = remember { FirebaseAuthManager() }
    val scope       = rememberCoroutineScope()

    var currentScreen by remember { mutableStateOf<SymptomScreen>(SymptomScreen.Home) }
    var statusMessage by remember { mutableStateOf("") }

    when (val screen = currentScreen) {
        is SymptomScreen.Home -> SymptomHomeScreen(
            statusMessage = statusMessage,
            onBack        = onBack,
            onTrack       = { category -> currentScreen = SymptomScreen.Track(category) },
            onHistory     = { category -> currentScreen = SymptomScreen.History(category) }
        )
        is SymptomScreen.Track -> {
            val questions = symptomQuestionMap[screen.category] ?: emptyList()
            SymptomQuestionScreen(
                category  = screen.category,
                questions = questions,
                onBack    = { currentScreen = SymptomScreen.Home },
                onSubmit  = { entries ->
                    scope.launch {
                        val userId = storage.getString(StorageKeys.USER_ID) ?: "unknown"
                        val now    = Clock.System.now().toEpochMilliseconds()
                        val submission = SymptomSubmission("${userId}_$now", userId, now, screen.category, entries)

                        try {
                            repository.insertSymptomSubmission(submission)
                            statusMessage = "${screen.category} symptoms saved ✓"
                        } catch (e: Exception) {
                            statusMessage = "Save failed"
                            currentScreen = SymptomScreen.Home
                            return@launch
                        }

                        if (storage.isResearchOptedIn()) {
                            val uid = authManager.currentUid ?: authManager.signInAnonymously()
                            if (uid != null) {
                                uploader.uploadSymptomSubmission(uid, submission)
                                    .onSuccess { statusMessage = "${screen.category} symptoms saved & uploaded ✓" }
                                    .onFailure {
                                        uploadQueue.enqueueSymptomSubmission(submission.submissionId)
                                        statusMessage = "Saved locally — queued for upload"
                                    }
                            } else {
                                uploadQueue.enqueueSymptomSubmission(submission.submissionId)
                            }
                        }
                        currentScreen = SymptomScreen.Home
                    }
                }
            )
        }
        is SymptomScreen.History -> SymptomHistoryScreen(
            category   = screen.category,
            repository = repository,
            storage    = storage,
            onBack     = { currentScreen = SymptomScreen.Home }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SymptomHomeScreen(
    statusMessage: String, onBack: () -> Unit,
    onTrack: (String) -> Unit, onHistory: (String) -> Unit
) {
    var showInfo by remember { mutableStateOf(false) }
    Scaffold(topBar = { GloveworksTopBar(title = "Symptom Tracker", onBack = onBack, onInfo = { showInfo = true }) }) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (statusMessage.isNotEmpty()) {
                Text(statusMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
            listOf("Physical", "Lifestyle", "Psychological").forEach { category ->
                CategoryCard(category = category, onTrack = { onTrack(category) }, onHistory = { onHistory(category) })
            }
        }
    }
    if (showInfo) GloveworksInfoDialog("Symptom Tracker — How It Works", SYMPTOM_INFO) { showInfo = false }
}

@Composable
private fun CategoryCard(category: String, onTrack: () -> Unit, onHistory: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(3.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(text = category, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onHistory) { Text("History") }
                Button(onClick = onTrack, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) { Text("Track", color = MaterialTheme.colorScheme.onSecondary) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SymptomQuestionScreen(
    category: String, questions: List<String>,
    onBack: () -> Unit, onSubmit: (List<SymptomEntry>) -> Unit
) {
    var showInfo by remember { mutableStateOf(false) }
    val responses  = remember { mutableStateListOf<Int>().apply { repeat(questions.size) { add(0) } } }
    val isComplete = responses.none { it == 0 }

    Scaffold(topBar = { GloveworksTopBar(title = category, onBack = onBack, onInfo = { showInfo = true }) }) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)
            .verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            questions.forEachIndexed { index, question ->
                Column {
                    Text(question, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        (1..5).forEach { score ->
                            FilterChip(selected = responses[index] == score,
                                onClick = { responses[index] = score }, label = { Text("$score") })
                        }
                    }
                }
            }
            Button(onClick = { onSubmit(questions.mapIndexed { i, q -> SymptomEntry(q, responses[i]) }) },
                enabled = isComplete, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) { Text("Submit", color = MaterialTheme.colorScheme.onSecondary) }
        }
    }
    if (showInfo) GloveworksInfoDialog("Symptom Tracker — How It Works", SYMPTOM_INFO) { showInfo = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SymptomHistoryScreen(
    category: String, repository: GloveworksRepository,
    storage: LocalStorage, onBack: () -> Unit
) {
    var showInfo by remember { mutableStateOf(false) }
    val userId      = storage.getString(StorageKeys.USER_ID) ?: "unknown"
    val submissions = remember { repository.getSubmissionsByCategory(userId, category) }

    Scaffold(topBar = { GloveworksTopBar(title = "$category History", onBack = onBack, onInfo = { showInfo = true }) }) { innerPadding ->
        if (submissions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                Text("No $category submissions yet.", textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)
                .verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                submissions.forEach { submission ->
                    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(2.dp)) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(submission.displayDate, style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            submission.entries.forEach { entry ->
                                Row(modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text(entry.question, style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.weight(1f))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    val color = when (entry.score) {
                                        1 -> Color(0xFFD32F2F); 2 -> Color(0xFFF57C00)
                                        3 -> Color(0xFF757575); 4 -> Color(0xFF388E3C)
                                        5 -> Color(0xFF1976D2); else -> Color(0xFF757575)
                                    }
                                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                                        color = color.copy(alpha = 0.15f)) {
                                        Text("${entry.score}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold, color = color)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (showInfo) GloveworksInfoDialog("Symptom Tracker — How It Works", SYMPTOM_INFO) { showInfo = false }
}