package com.example.gloveworks50.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.gloveworks50.bluetooth.BleManager
import com.example.gloveworks50.bluetooth.BlePermission
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.StorageKeys
import com.example.gloveworks50.ui.GloveworksInfoDialog
import com.example.gloveworks50.ui.GloveworksTopBar
import kotlin.math.roundToInt

private const val SERVICE_UUID     = "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
private const val CHAR_MOTOR_AMP   = "beb5483e-36e1-4688-b7f5-ea07361b26a8"
private const val CHAR_PATTERN_DUR = "e3223119-9445-4e96-a4a1-85358c4046a2"
private const val CHAR_BURST_DUR   = "e3223119-9445-4e96-a4a1-85358c4046a3"

private val MA_RANGE = 50..100
private val PD_RANGE = 500..1000
private val BD_RANGE = 50..150
private const val DEFAULT_MA  = 100
private const val DEFAULT_PD  = 744
private const val DEFAULT_BD  = 100
private const val DEFAULT_PIN = "1234"

private val GLOVE_INFO = """
• Ensure your phone's Bluetooth and location are enabled.
• Turn on the glove, then tap Start Scanning.
• Grant Bluetooth permission if prompted.
• Tap your glove's name in the device list to connect.
• Use the three sliders to tune the glove:
    - Motor Amplitude: vibration strength (50–100%)
    - Burst Duration: how long each pulse lasts (50–150 ms)
    - Pattern Duration: time between pulse patterns (500–1000 ms)
• Tap Re-Send All Values to push all settings again if needed.
• Tap Disconnect when finished, then the back arrow to return home.
""".trim()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GloveControlScreen(onBack: () -> Unit) {

    val storage       = remember { LocalStorage() }
    val bleManager    = remember { BleManager() }
    val blePermission = remember { BlePermission() }

    var permissionGranted by remember { mutableStateOf(blePermission.isGranted()) }
    val storedPin  = remember { storage.getString(StorageKeys.GLOVE_PIN) ?: DEFAULT_PIN }
    var isUnlocked     by rememberSaveable { mutableStateOf(false) }
    var showPinDialog  by rememberSaveable { mutableStateOf(true) }
    var pinInput       by rememberSaveable { mutableStateOf("") }
    var pinError       by rememberSaveable { mutableStateOf<String?>(null) }

    var motorAmp   by remember { mutableIntStateOf(storage.getInt(StorageKeys.GLOVE_MOTOR_AMP, DEFAULT_MA)) }
    var patternDur by remember { mutableIntStateOf(storage.getInt(StorageKeys.GLOVE_PATTERN_DUR, DEFAULT_PD)) }
    var burstDur   by remember { mutableIntStateOf(storage.getInt(StorageKeys.GLOVE_BURST_DUR, DEFAULT_BD)) }

    val devices     by derivedStateOf { bleManager.devices }
    val isConnected by derivedStateOf { bleManager.isConnected }
    val statusText  by derivedStateOf { bleManager.statusText }

    var showInfo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        permissionGranted = blePermission.isGranted()
        if (!permissionGranted) blePermission.request { granted -> permissionGranted = granted }
        motorAmp   = motorAmp.coerceIn(MA_RANGE)
        burstDur   = burstDur.coerceIn(BD_RANGE)
        val minPd  = (4 * burstDur).coerceIn(PD_RANGE)
        patternDur = patternDur.coerceIn(minPd..PD_RANGE.last)
        persistValues(storage, motorAmp, patternDur, burstDur)
    }

    DisposableEffect(Unit) { onDispose { bleManager.close() } }

    fun persistValues() = persistValues(storage, motorAmp, patternDur, burstDur)

    fun sendAllIfConnected() {
        if (!isConnected) return
        bleManager.writeIntAsString(SERVICE_UUID, CHAR_MOTOR_AMP, motorAmp)
        bleManager.writeIntAsString(SERVICE_UUID, CHAR_PATTERN_DUR, patternDur)
        bleManager.writeIntAsString(SERVICE_UUID, CHAR_BURST_DUR, burstDur)
    }

    fun startScanWithPermission() {
        if (permissionGranted) bleManager.startScan(SERVICE_UUID)
        else blePermission.request { granted -> permissionGranted = granted; if (granted) bleManager.startScan(SERVICE_UUID) }
    }

    // Main UI
    Scaffold(
        topBar = {
            GloveworksTopBar(
                title  = "Glove Control",
                onBack = { bleManager.close(); onBack() },
                onInfo = { showInfo = true }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Scan for your glove, connect, then tune the three parameters below.",
                style = MaterialTheme.typography.bodyMedium)

            if (!permissionGranted) {
                Text("Bluetooth permission required — tap Start Scanning to grant.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { startScanWithPermission() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) { Text("Start Scanning", color = MaterialTheme.colorScheme.onSecondary) }
                Button(onClick = { bleManager.disconnect() }, enabled = isConnected, modifier = Modifier.weight(1f)) { Text("Disconnect") }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("BLE Status:")
                Text(statusText)
            }

            if (devices.isNotEmpty() && !isConnected) {
                Text("Devices Found:", style = MaterialTheme.typography.titleSmall)
                Card {
                    Column(modifier = Modifier.padding(8.dp)) {
                        devices.forEachIndexed { index, device ->
                            OutlinedButton(
                                onClick  = { bleManager.connectByIndex(index) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("${device.name ?: "Unnamed Device"}  •  ${device.address}")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            ParameterSlider(
                title = "Motor Amplitude", value = motorAmp, valueRange = MA_RANGE, enabled = isConnected,
                onValueChanged = { newVal ->
                    motorAmp = newVal.coerceIn(MA_RANGE); persistValues()
                    bleManager.writeIntAsString(SERVICE_UUID, CHAR_MOTOR_AMP, motorAmp)
                }
            )
            ParameterSlider(
                title = "Burst Duration", value = burstDur, valueRange = BD_RANGE, enabled = isConnected,
                onValueChanged = { newVal ->
                    burstDur = newVal.coerceIn(BD_RANGE)
                    val minPd = (4 * burstDur).coerceIn(PD_RANGE)
                    if (patternDur < minPd) { patternDur = minPd; if (isConnected) bleManager.writeIntAsString(SERVICE_UUID, CHAR_PATTERN_DUR, patternDur) }
                    persistValues(); bleManager.writeIntAsString(SERVICE_UUID, CHAR_BURST_DUR, burstDur)
                }
            )
            ParameterSlider(
                title = "Pattern Duration", value = patternDur, valueRange = PD_RANGE, enabled = isConnected,
                onValueChanged = { newVal ->
                    val minPd = (4 * burstDur).coerceIn(PD_RANGE)
                    patternDur = newVal.coerceIn(minPd..PD_RANGE.last)
                    persistValues(); bleManager.writeIntAsString(SERVICE_UUID, CHAR_PATTERN_DUR, patternDur)
                }
            )

            if (isConnected) {
                OutlinedButton(onClick = { sendAllIfConnected() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
                    Text("Re-Send All Values")
                }
            }
        }
    }

    if (showInfo) {
        GloveworksInfoDialog(
            title     = "Glove Control — How It Works",
            body      = GLOVE_INFO,
            onDismiss = { showInfo = false }
        )
    }
}

private fun persistValues(storage: LocalStorage, motorAmp: Int, patternDur: Int, burstDur: Int) {
    storage.putInt(StorageKeys.GLOVE_MOTOR_AMP, motorAmp)
    storage.putInt(StorageKeys.GLOVE_PATTERN_DUR, patternDur)
    storage.putInt(StorageKeys.GLOVE_BURST_DUR, burstDur)
}

@Composable
private fun ParameterSlider(
    title: String, value: Int, valueRange: IntRange, enabled: Boolean,
    onValueChanged: (Int) -> Unit, unit: String? = null, helperText: String? = null
) {
    val displayValue  = if (unit.isNullOrBlank()) "$value" else "$value $unit"
    val disabledAlpha = if (enabled) 1f else 0.45f
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().alpha(disabledAlpha),
        colors   = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (!helperText.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(helperText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                AssistChip(
                    onClick = {}, enabled = false,
                    label = { Text(displayValue, style = MaterialTheme.typography.labelLarge) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        labelColor     = MaterialTheme.colorScheme.onSurfaceVariant,
                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        disabledLabelColor     = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
            Slider(
                value = value.toFloat(),
                onValueChange = { onValueChanged(it.roundToInt().coerceIn(valueRange)) },
                valueRange    = valueRange.first.toFloat()..valueRange.last.toFloat(),
                enabled       = enabled
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(valueRange.first.toString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(valueRange.last.toString(),  style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}