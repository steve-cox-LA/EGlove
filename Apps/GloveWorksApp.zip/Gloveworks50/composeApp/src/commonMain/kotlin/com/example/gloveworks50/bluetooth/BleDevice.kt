package com.example.gloveworks50.bluetooth


data class BleDevice(
    val name: String?,
    val address: String
) {
    val displayName: String
        get() = if (!name.isNullOrBlank()) name else "Unnamed Device"
}