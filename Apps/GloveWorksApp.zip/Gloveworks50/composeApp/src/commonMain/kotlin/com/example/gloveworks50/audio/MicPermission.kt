package com.example.gloveworks50.audio


expect class MicPermission() {
    fun isGranted(): Boolean

    fun request(onResult: (granted: Boolean) -> Unit)
}