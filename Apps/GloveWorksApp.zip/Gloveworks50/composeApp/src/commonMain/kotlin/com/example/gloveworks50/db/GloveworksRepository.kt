package com.example.gloveworks50.db

import com.example.gloveworks50.data.GaitEpoch
import com.example.gloveworks50.data.GaitSession
import com.example.gloveworks50.data.MedOption
import com.example.gloveworks50.data.MedicationHistoryEntry
import com.example.gloveworks50.data.SymptomEntry
import com.example.gloveworks50.data.SymptomSubmission
import com.example.gloveworks50.data.UserProfile
import com.example.gloveworks50.data.UserType
import com.example.gloveworks50.data.VoiceEpoch
import com.example.gloveworks50.data.VoiceSession
import com.example.gloveworks50.data.computeVoiceScore

class GloveworksRepository(driverFactory: DatabaseDriverFactory) {

    private val database = GloveworksDatabase(driverFactory.createDriver())

    private val gaitQueries       = database.gaitSessionQueries
    private val voiceQueries      = database.voiceSessionQueries
    private val symptomQueries    = database.symptomSubmissionQueries
    private val medicationQueries = database.medicationHistoryQueries
    private val profileQueries    = database.userProfileQueries

    // ── Gait ─────────────────────────────────────────────────────────────────

    fun insertGaitSession(session: GaitSession) {
        gaitQueries.insertGaitSession(
            sessionId                  = session.sessionId,
            userId                     = session.userId,
            timestampMs                = session.timestampMs,
            averageDominantFrequencyHz = session.averageDominantFrequencyHz.toDouble(),
            totalVariation             = session.totalVariation
        )
        session.epochs.forEach { epoch ->
            gaitQueries.insertGaitEpoch(
                sessionId           = session.sessionId,
                epochIndex          = epoch.epochIndex.toLong(),
                dominantFrequencyHz = epoch.dominantFrequencyHz.toDouble()
            )
        }
    }

    fun getGaitSessionsByUser(userId: String): List<GaitSession> {
        return gaitQueries.selectGaitSessionsByUser(userId).executeAsList().map { row ->
            val epochs = gaitQueries.selectEpochsForSession(row.sessionId).executeAsList().map { e ->
                GaitEpoch(e.epochIndex.toInt(), e.dominantFrequencyHz.toFloat())
            }
            GaitSession(
                sessionId                  = row.sessionId,
                userId                     = row.userId,
                timestampMs                = row.timestampMs,
                epochs                     = epochs,
                averageDominantFrequencyHz = row.averageDominantFrequencyHz.toFloat(),
                totalVariation             = row.totalVariation
            )
        }
    }

    fun deleteAllGaitSessions() { gaitQueries.deleteAllGaitSessions() }

    // ── Voice ─────────────────────────────────────────────────────────────────

    fun insertVoiceSession(session: VoiceSession) {
        voiceQueries.insertVoiceSession(
            sessionId                  = session.sessionId,
            userId                     = session.userId,
            timestampMs                = session.timestampMs,
            averageRms                 = session.averageRms.toDouble(),
            averageDominantFrequencyHz = session.averageDominantFrequencyHz.toDouble(),
            avgJitter                  = session.avgJitter,
            avgShimmer                 = session.avgShimmer,
            voiceScore                 = session.voiceScore
        )
        session.epochs.forEach { epoch ->
            voiceQueries.insertVoiceEpoch(
                sessionId           = session.sessionId,
                epochIndex          = epoch.epochIndex.toLong(),
                rms                 = epoch.rms.toDouble(),
                dominantFrequencyHz = epoch.dominantFrequencyHz.toDouble(),
                jitterPercent       = epoch.jitterPercent,
                shimmerDb           = epoch.shimmerDb,
                validCycles         = epoch.validCycles.toLong()
            )
        }
    }

    fun getVoiceSessionsByUser(userId: String): List<VoiceSession> {
        return voiceQueries.selectVoiceSessionsByUser(userId).executeAsList().map { row ->
            val epochs = voiceQueries.selectEpochsForSession(row.sessionId).executeAsList().map { e ->
                VoiceEpoch(
                    epochIndex          = e.epochIndex.toInt(),
                    rms                 = e.rms.toFloat(),
                    dominantFrequencyHz = e.dominantFrequencyHz.toFloat(),
                    jitterPercent       = e.jitterPercent,
                    shimmerDb           = e.shimmerDb,
                    validCycles         = e.validCycles.toInt()
                )
            }
            VoiceSession(
                sessionId                  = row.sessionId,
                userId                     = row.userId,
                timestampMs                = row.timestampMs,
                epochs                     = epochs,
                averageRms                 = row.averageRms.toFloat(),
                averageDominantFrequencyHz = row.averageDominantFrequencyHz.toFloat(),
                avgJitter                  = row.avgJitter,
                avgShimmer                 = row.avgShimmer,
                voiceScore                 = row.voiceScore
            )
        }
    }

    /**
     * Returns the last [count] voice sessions for a user, oldest first.
     * Used to compute personal baseline trend.
     */
    fun getRecentVoiceSessions(userId: String, count: Int = 5): List<VoiceSession> {
        return getVoiceSessionsByUser(userId)
            .sortedByDescending { it.timestampMs }
            .take(count)
            .sortedBy { it.timestampMs }
    }

    fun deleteAllVoiceSessions() { voiceQueries.deleteAllVoiceSessions() }

    // ── Symptoms ──────────────────────────────────────────────────────────────

    fun insertSymptomSubmission(submission: SymptomSubmission) {
        symptomQueries.insertSymptomSubmission(
            submissionId = submission.submissionId,
            userId       = submission.userId,
            timestampMs  = submission.timestampMs,
            category     = submission.category
        )
        submission.entries.forEach { entry ->
            symptomQueries.insertSymptomEntry(
                submissionId = submission.submissionId,
                question     = entry.question,
                score        = entry.score.toLong()
            )
        }
    }

    fun getSubmissionsByUser(userId: String): List<SymptomSubmission> {
        return symptomQueries.selectSubmissionsByUser(userId).executeAsList().map { row ->
            val entries = symptomQueries.selectEntriesForSubmission(row.submissionId)
                .executeAsList().map { e -> SymptomEntry(e.question, e.score.toInt()) }
            SymptomSubmission(row.submissionId, row.userId, row.timestampMs, row.category, entries)
        }
    }

    fun getSubmissionsByCategory(userId: String, category: String): List<SymptomSubmission> {
        return symptomQueries.selectSubmissionsByCategory(userId, category).executeAsList().map { row ->
            val entries = symptomQueries.selectEntriesForSubmission(row.submissionId)
                .executeAsList().map { e -> SymptomEntry(e.question, e.score.toInt()) }
            SymptomSubmission(row.submissionId, row.userId, row.timestampMs, row.category, entries)
        }
    }

    fun deleteAllSubmissions() { symptomQueries.deleteAllSubmissions() }

    // ── Medications ───────────────────────────────────────────────────────────

    fun insertMedicationEntry(entry: MedicationHistoryEntry, userId: String) {
        entry.medications.forEach { med ->
            medicationQueries.insertMedicationEntry(
                userId      = userId,
                timestampMs = entry.timestampMs,
                name        = med.name,
                dosage      = med.dosage,
                frequency   = med.frequency
            )
        }
    }

    fun getMedicationsByUser(userId: String): List<MedicationHistoryEntry> {
        return medicationQueries.selectMedicationsByUser(userId).executeAsList()
            .groupBy { it.timestampMs }
            .map { (ts, meds) ->
                MedicationHistoryEntry(ts, meds.map { MedOption(it.name, it.dosage, it.frequency) })
            }
            .sortedByDescending { it.timestampMs }
    }

    fun deleteAllMedications(userId: String) {
        medicationQueries.deleteAllMedicationsByUser(userId)
    }

    // ── User Profile ──────────────────────────────────────────────────────────

    fun insertUserProfile(profile: UserProfile, researchOptIn: Boolean) {
        profileQueries.insertUserProfile(
            userId          = profile.userId,
            userType        = profile.userType.name,
            firstName       = profile.firstName,
            lastName        = profile.lastName,
            email           = profile.email,
            dob             = profile.dob,
            phone           = profile.phone,
            pdqResponses    = profile.pdqResponses?.joinToString(","),
            age             = profile.age,
            diagnosedWithPD = if (profile.diagnosedWithPD == true) 1L else 0L,
            shareMotion     = if (profile.shareMotion) 1L else 0L,
            shareVoice      = if (profile.shareVoice) 1L else 0L,
            researchOptIn   = if (researchOptIn) 1L else 0L
        )
    }

    fun getActiveProfile(): UserProfile? {
        val row = profileQueries.selectActiveProfile().executeAsOneOrNull() ?: return null
        return UserProfile(
            userId          = row.userId,
            userType        = if (row.userType == "GLOVEWORKS") UserType.GLOVEWORKS else UserType.LOCAL,
            firstName       = row.firstName,
            lastName        = row.lastName,
            email           = row.email,
            dob             = row.dob,
            phone           = row.phone,
            pdqResponses    = row.pdqResponses?.split(",")?.mapNotNull { it.toIntOrNull() },
            diagnosedWithPD = row.diagnosedWithPD == 1L,
            shareMotion     = row.shareMotion == 1L,
            shareVoice      = row.shareVoice == 1L
        )
    }

    fun deleteAllProfiles() { profileQueries.deleteAllProfiles() }

    fun clearAllData() {
        deleteAllGaitSessions()
        deleteAllVoiceSessions()
        deleteAllSubmissions()
        deleteAllProfiles()
    }
}