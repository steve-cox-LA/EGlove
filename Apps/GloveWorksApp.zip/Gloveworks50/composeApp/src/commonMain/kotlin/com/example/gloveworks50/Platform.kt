package com.example.gloveworks50

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform