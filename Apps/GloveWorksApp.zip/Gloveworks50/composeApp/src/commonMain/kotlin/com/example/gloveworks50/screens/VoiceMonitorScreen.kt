package com.example.gloveworks50.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gloveworks50.audio.AudioRecorder
import com.example.gloveworks50.audio.MicPermission
import com.example.gloveworks50.auth.FirebaseAuthManager
import com.example.gloveworks50.data.FirebaseUploader
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.StorageKeys
import com.example.gloveworks50.data.UploadQueue
import com.example.gloveworks50.data.VoiceEpoch
import com.example.gloveworks50.data.VoiceSession
import com.example.gloveworks50.data.isResearchOptedIn
import com.example.gloveworks50.db.GloveworksRepository
import com.example.gloveworks50.ui.GloveworksInfoDialog
import com.example.gloveworks50.ui.GloveworksTopBar
import com.example.gloveworks50.ui.JitterShimmerCard
import com.example.gloveworks50.ui.MonitorGraphCard
import com.example.gloveworks50.ui.SharedEpochFreqTrendGraph
import com.example.gloveworks50.ui.SharedFFTGraph
import com.example.gloveworks50.ui.fmtDec
import com.example.gloveworks50.util.FFTUtil
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

private const val VOICE_TOTAL_EPOCHS = 5
private const val VOICE_EPOCH_MS     = 1000L

private val VOICE_INFO = """
• Tap Start to begin a ${VOICE_TOTAL_EPOCHS}-epoch voice recording session (${VOICE_TOTAL_EPOCHS * VOICE_EPOCH_MS / 1000}s total).
• Sustain a vowel sound (e.g. "ahhh") continuously throughout.
• The session runs automatically — no need to stop it manually.
• Two metrics are measured across all epochs:
    Jitter  — epoch-to-epoch pitch period variation
    Shimmer — epoch-to-epoch amplitude variation
• Lower values = more stable voice.
• Microphone permission is required.
• Tap View History to see past sessions and trends.
""".trim()

@OptIn(ExperimentalMaterial3Api::class, ExperimentalTime::class)
@Composable
fun VoiceMonitorScreen(
    repository: GloveworksRepository,
    uploadQueue: UploadQueue,
    onBack: () -> Unit,
    onHistory: () -> Unit
) {
    val storage        = remember { LocalStorage() }
    val recorder       = remember { AudioRecorder() }
    val micPermission  = remember { MicPermission() }
    val uploader       = remember { FirebaseUploader() }
    val authManager    = remember { FirebaseAuthManager() }
    val coroutineScope = rememberCoroutineScope()

    var isRecording       by remember { mutableStateOf(false) }
    var isAnalysing       by remember { mutableStateOf(false) }
    var permissionGranted by remember { mutableStateOf(false) }
    var currentEpoch      by remember { mutableStateOf(0) }
    var uploadStatus      by remember { mutableStateOf("") }
    var sessionJitter     by remember { mutableStateOf<Double?>(null) }
    var sessionShimmer    by remember { mutableStateOf<Double?>(null) }
    var waveformSamples   by remember { mutableStateOf<List<Short>>(emptyList()) }
    var fftDataList       by remember { mutableStateOf<List<Pair<Float, Float>>>(emptyList()) }
    var epochFreqList     by remember { mutableStateOf<List<Pair<Int, Float>>>(emptyList()) }
    var showInfo          by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        permissionGranted = micPermission.isGranted()
        if (!permissionGranted) micPermission.request { granted -> permissionGranted = granted }
    }

    fun stopRecording() { isRecording = false; recorder.stop() }

    fun startRecording() {
        if (!permissionGranted) { micPermission.request { granted -> permissionGranted = granted }; return }
        storage.remove(StorageKeys.VOICE_SESSION_ID)
        isRecording = true; isAnalysing = false
        waveformSamples = emptyList(); fftDataList = emptyList()
        epochFreqList = emptyList(); currentEpoch = 0
        uploadStatus = ""; sessionJitter = null; sessionShimmer = null

        coroutineScope.launch {
            val sampleChannel = Channel<ShortArray>(capacity = Channel.UNLIMITED)
            recorder.start { chunk -> sampleChannel.trySend(chunk) }

            val epochPitches    = mutableListOf<Float>()
            val epochAmplitudes = mutableListOf<Float>()
            val collectedEpochs = mutableListOf<VoiceEpoch>()

            for (epochIndex in 1..VOICE_TOTAL_EPOCHS) {
                currentEpoch = epochIndex
                val epochSamples = mutableListOf<Short>()
                val epochStart   = Clock.System.now().toEpochMilliseconds()
                while (Clock.System.now().toEpochMilliseconds() - epochStart < VOICE_EPOCH_MS) {
                    var chunk = sampleChannel.tryReceive().getOrNull()
                    while (chunk != null) { epochSamples.addAll(chunk.toList()); chunk = sampleChannel.tryReceive().getOrNull() }
                    if (epochSamples.isNotEmpty())
                        waveformSamples = epochSamples.takeLast(FFTUtil.VOICE_SAMPLE_RATE).filterIndexed { i, _ -> i % 10 == 0 }
                    delay(50)
                }
                var remaining = sampleChannel.tryReceive().getOrNull()
                while (remaining != null) { epochSamples.addAll(remaining.toList()); remaining = sampleChannel.tryReceive().getOrNull() }

                val fftResult    = FFTUtil.getFFT(epochSamples, FFTUtil.VOICE_SAMPLE_RATE.toFloat())
                fftDataList      = fftResult
                val dominantFreq = FFTUtil.dominantFrequency(fftResult)
                val rms          = FFTUtil.calculateRMS(epochSamples)
                epochPitches.add(dominantFreq)
                epochAmplitudes.add(rms)
                epochFreqList = epochFreqList + Pair(epochIndex, dominantFreq)
                collectedEpochs.add(VoiceEpoch(epochIndex, rms, dominantFreq, 0.0, 0.0, 0))
            }

            recorder.stop(); sampleChannel.close(); isRecording = false
            isAnalysing = true
            val analysis = FFTUtil.analyseEpochs(epochPitches, epochAmplitudes)
            isAnalysing = false

            val jitter  = analysis?.jitter  ?: 0.0
            val shimmer = analysis?.shimmer ?: 0.0
            sessionJitter = jitter; sessionShimmer = shimmer

            val userId    = storage.getString(StorageKeys.USER_ID) ?: "unknown"
            val sessionId = "voice_${userId}_${Clock.System.now().toEpochMilliseconds()}"
            storage.putString(StorageKeys.VOICE_SESSION_ID, sessionId)

            val session = VoiceSession(
                sessionId   = sessionId, userId = userId,
                timestampMs = Clock.System.now().toEpochMilliseconds(),
                epochs      = collectedEpochs.map { e -> e.copy(jitterPercent = jitter, shimmerDb = shimmer) }
            )
            uploadStatus = "Saving..."
            try { repository.insertVoiceSession(session); uploadStatus = "Saved ✓" }
            catch (e: Exception) { uploadStatus = "Local save failed"; return@launch }

            if (!storage.isResearchOptedIn()) return@launch
            uploadStatus = "Uploading..."
            val uid = authManager.currentUid ?: authManager.signInAnonymously()
            if (uid == null) { uploadQueue.enqueueVoiceSession(sessionId); uploadStatus = "Saved ✓ (queued)"; return@launch }
            uploader.uploadVoiceSession(uid, session)
                .onSuccess { uploadStatus = "Saved & uploaded ✓" }
                .onFailure { uploadQueue.enqueueVoiceSession(sessionId); uploadStatus = "Saved ✓ (queued)" }
        }
    }

    DisposableEffect(Unit) { onDispose { stopRecording() } }

    Scaffold(
        topBar = {
            GloveworksTopBar(title = "Voice Monitor",
                onBack = { stopRecording(); onBack() }, onInfo = { showInfo = true })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isRecording) RecordingIndicator()

            Text(
                text = when {
                    !permissionGranted        -> "Microphone permission required"
                    isAnalysing               -> "Analysing session..."
                    isRecording               -> "Recording epoch $currentEpoch / $VOICE_TOTAL_EPOCHS  •  " +
                            "${currentEpoch * VOICE_EPOCH_MS / 1000}s / ${VOICE_TOTAL_EPOCHS * VOICE_EPOCH_MS / 1000}s"
                    uploadStatus.isNotEmpty() -> uploadStatus
                    else                      -> "Ready — tap Start and sustain a vowel"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = when {
                    isAnalysing -> MaterialTheme.colorScheme.primary
                    isRecording -> MaterialTheme.colorScheme.error
                    else        -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                },
                textAlign = TextAlign.Center
            )

            if (isRecording) {
                LinearProgressIndicator(
                    progress = { currentEpoch.toFloat() / VOICE_TOTAL_EPOCHS },
                    modifier = Modifier.fillMaxWidth(),
                    color    = MaterialTheme.colorScheme.secondary)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Button(onClick = { startRecording() }, enabled = !isRecording && !isAnalysing,
                    modifier = Modifier.weight(1f).height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) { Text("Start", color = MaterialTheme.colorScheme.onSecondary) }
                Button(onClick = { stopRecording() }, enabled = isRecording,
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text("Stop") }
            }

            val jitter  = sessionJitter
            val shimmer = sessionShimmer
            if (jitter != null && shimmer != null) { JitterShimmerCard(jitter, shimmer) }

            // 3 graphs — identical structure to GaitMonitorScreen
            MonitorGraphCard("Real-Time Audio Signal", Modifier.height(150.dp)) {
                VoiceRealTimeGraph(waveformSamples)
            }
            MonitorGraphCard(
                "Fourier Amplitude vs Frequency (Hz) — Epoch $currentEpoch",
                Modifier.height(150.dp)
            ) { SharedFFTGraph(fftDataList) }
            MonitorGraphCard("Peak Frequency per Epoch (Hz)", Modifier.height(180.dp)) {
                SharedEpochFreqTrendGraph(epochFreqList, VOICE_TOTAL_EPOCHS)
            }

            OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("View Session History & Trends")
            }
        }
    }
    if (showInfo) GloveworksInfoDialog("Voice Monitor — How It Works", VOICE_INFO) { showInfo = false }
}

// Voice-specific real-time graph
@Composable
private fun VoiceRealTimeGraph(samples: List<Short>) {
    val lineColor  = MaterialTheme.colorScheme.primary
    val gridColor  = MaterialTheme.colorScheme.surfaceVariant
    val labelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
    val measurer   = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 9.sp, color = labelColor)
    Canvas(modifier = Modifier.fillMaxSize()) {
        val leftPad = 44f; val plotW = size.width - leftPad; val plotH = size.height - 20f
        val minY = -32768f; val maxY = 32767f; val rangeY = maxY - minY
        val midY = plotH / 2f
        listOf(minY to "-32K", 0f to "0", maxY to "+32K").forEach { (v, label) ->
            val y = plotH - ((v - minY) / rangeY) * plotH
            drawLine(gridColor, Offset(leftPad, y), Offset(size.width, y), strokeWidth = 1f)
            val t = measurer.measure(label, labelStyle)
            drawText(t, topLeft = Offset(leftPad - t.size.width - 4f, y - t.size.height / 2f))
        }
        if (samples.size < 2) return@Canvas
        val path = Path()
        samples.forEachIndexed { i, s ->
            val x = leftPad + (i.toFloat() / (samples.size - 1)) * plotW
            val y = plotH   - ((s.toFloat() - minY) / rangeY) * plotH
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, lineColor, style = Stroke(width = 1.5f))
    }
}

@Composable
private fun RecordingIndicator() {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulseSize by transition.animateFloat(16f, 32f,
        infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "pulseSize")
    Box(modifier = Modifier.size(40.dp), contentAlignment = Alignment.Center) {
        Box(modifier = Modifier.size(pulseSize.dp).clip(CircleShape)
            .background(MaterialTheme.colorScheme.error))
    }
}