package com.example.gloveworks50.bluetooth


expect class BleManager() {

    var devices: List<BleDevice>
        private set

    var isConnected: Boolean
        private set

    var statusText: String
        private set

    fun startScan(serviceUuid: String)
    fun stopScan()
    fun connectByIndex(index: Int)
    fun disconnect()
    fun writeIntAsString(serviceUuid: String, characteristicUuid: String, value: Int)
    fun close()
}