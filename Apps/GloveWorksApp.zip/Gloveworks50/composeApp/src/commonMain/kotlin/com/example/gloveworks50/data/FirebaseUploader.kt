package com.example.gloveworks50.data

import dev.gitlive.firebase.Firebase
import dev.gitlive.firebase.database.database
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

@OptIn(ExperimentalTime::class)
class FirebaseUploader {

    private val db get() = Firebase.database
    private fun userRef(uid: String) = db.reference("users/$uid")

    private fun msToDate(ms: Long): String {
        val s  = ms / 1000L
        val mn = ((s / 60L) % 60L).toString().padStart(2, '0')
        val h  = ((s / 3600L) % 24L).toString().padStart(2, '0')
        var rem = s / 86400L; var y = 1970
        while (true) {
            val dy = if ((y%4==0&&y%100!=0)||y%400==0) 366L else 365L
            if (rem < dy) break; rem -= dy; y++
        }
        val ml = intArrayOf(31, if ((y%4==0&&y%100!=0)||y%400==0) 29 else 28,
            31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var mo = 1; for (len in ml) { if (rem < len) break; rem -= len; mo++ }
        return "${y.toString().padStart(4,'0')}-${mo.toString().padStart(2,'0')}-${(rem+1).toString().padStart(2,'0')} $h:$mn UTC"
    }

    suspend fun uploadUserProfile(uid: String, profile: UserProfile): Result<Unit> = runCatching {
        val now = Clock.System.now().toEpochMilliseconds()
        userRef(uid).child("profile").setValue(mapOf(
            "userId"       to profile.userId,
            "userType"     to profile.userType.name,
            "firstName"    to (profile.firstName  ?: ""),
            "lastName"     to (profile.lastName   ?: ""),
            "email"        to (profile.email      ?: ""),
            "dob"          to (profile.dob        ?: ""),
            "phone"        to (profile.phone      ?: ""),
            "pdqResponses" to (profile.pdqResponses?.joinToString(",") ?: ""),
            "shareMotion"  to profile.shareMotion,
            "shareVoice"   to profile.shareVoice,
            "uploadedAt"   to msToDate(now),
            "uploadedAtMs" to now
        ))
    }

    suspend fun uploadGaitSession(uid: String, session: GaitSession): Result<Unit> = runCatching {
        userRef(uid).child("gaitSessions/${session.sessionId}").setValue(mapOf(
            "Date"    to msToDate(session.timestampMs),
            "Jitter"  to session.totalVariation,
            "Shimmer" to session.shimmer
        ))
    }

    suspend fun uploadVoiceSession(uid: String, session: VoiceSession): Result<Unit> = runCatching {
        userRef(uid).child("voiceSessions/${session.sessionId}").setValue(mapOf(
            "Date"    to msToDate(session.timestampMs),
            "Jitter"  to session.avgJitter,
            "Shimmer" to session.avgShimmer
        ))
    }

    suspend fun uploadSymptomSubmission(uid: String, submission: SymptomSubmission): Result<Unit> = runCatching {
        val entriesMap = submission.entries.mapIndexed { i, entry ->
            i.toString() to mapOf("question" to entry.question, "score" to entry.score)
        }.toMap()
        userRef(uid).child("symptomSubmissions/${submission.submissionId}").setValue(mapOf(
            "submissionId" to submission.submissionId,
            "userId"       to submission.userId,
            "date"         to msToDate(submission.timestampMs),
            "timestampMs"  to submission.timestampMs,
            "category"     to submission.category,
            "entries"      to entriesMap
        ))
    }

    suspend fun uploadMedicationEntry(uid: String, entry: MedicationHistoryEntry): Result<Unit> = runCatching {
        val medsMap = entry.medications.mapIndexed { i, med ->
            i.toString() to mapOf("name" to med.name, "dosage" to med.dosage, "frequency" to med.frequency)
        }.toMap()
        userRef(uid).child("medicationEntries/${entry.timestampMs}").setValue(mapOf(
            "date"        to msToDate(entry.timestampMs),
            "timestampMs" to entry.timestampMs,
            "medications" to medsMap
        ))
    }
}