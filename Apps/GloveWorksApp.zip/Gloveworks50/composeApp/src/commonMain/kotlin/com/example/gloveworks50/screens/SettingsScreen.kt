package com.example.gloveworks50.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gloveworks50.auth.FirebaseAuthManager
import com.example.gloveworks50.data.FirebaseUploader
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.StorageKeys
import com.example.gloveworks50.data.UploadQueue
import com.example.gloveworks50.data.UserProfile
import com.example.gloveworks50.data.UserType
import com.example.gloveworks50.data.getOrCreateUserId
import com.example.gloveworks50.data.getUserId
import com.example.gloveworks50.data.isResearchOptedIn
import com.example.gloveworks50.data.setResearchOptIn
import com.example.gloveworks50.db.GloveworksRepository
import kotlinx.coroutines.launch

private val pdqQuestions = listOf(
    "1. Difficulty carrying out daily activities (e.g., getting dressed)?",
    "2. Trouble walking short distances?",
    "3. Difficulty keeping balance or falling over?",
    "4. Difficulty with handwriting or using utensils?",
    "5. Emotional well-being affected (e.g., feeling depressed)?",
    "6. Difficulty speaking clearly?",
    "7. Experiencing bodily discomfort (pain, cramps, etc.)?",
    "8. Feeling isolated from others due to your condition?"
)

private val pdqOptions = listOf("Never", "Occasionally", "Sometimes", "Often", "Always")

private sealed class SettingsNav {
    object Main       : SettingsNav()
    object Onboarding : SettingsNav()
    object UserInfo   : SettingsNav()
    object About      : SettingsNav()
}

@Composable
fun SettingsScreen(
    repository: GloveworksRepository,
    uploadQueue: UploadQueue,
    onBack: () -> Unit
) {
    val storage = remember { LocalStorage() }
    val scope   = rememberCoroutineScope()

    var currentScreen by remember { mutableStateOf<SettingsNav>(SettingsNav.Main) }

    when (currentScreen) {
        is SettingsNav.Main -> SettingsMainScreen(
            storage              = storage,
            scope                = scope,
            uploadQueue          = uploadQueue,
            onBack               = onBack,
            onNavigateOnboarding = { currentScreen = SettingsNav.Onboarding },
            onNavigateUserInfo   = { currentScreen = SettingsNav.UserInfo },
            onNavigateAbout      = { currentScreen = SettingsNav.About }
        )
        is SettingsNav.Onboarding -> OnboardingScreen(
            storage    = storage,
            repository = repository,
            scope      = scope,
            onComplete = { currentScreen = SettingsNav.Main }
        )
        is SettingsNav.UserInfo -> UserInfoScreen(
            storage    = storage,
            repository = repository,
            scope      = scope,
            onBack     = { currentScreen = SettingsNav.Main },
            onReset    = { currentScreen = SettingsNav.Main }
        )
        is SettingsNav.About -> AboutScreen(onBack = { currentScreen = SettingsNav.Main })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsMainScreen(
    storage: LocalStorage,
    scope: kotlinx.coroutines.CoroutineScope,
    uploadQueue: UploadQueue,
    onBack: () -> Unit,
    onNavigateOnboarding: () -> Unit,
    onNavigateUserInfo: () -> Unit,
    onNavigateAbout: () -> Unit
) {
    var optedIn            by remember { mutableStateOf(storage.isResearchOptedIn()) }
    var showResearchDialog by remember { mutableStateOf(false) }
    var statusMessage      by remember { mutableStateOf("") }
    var isSyncing          by remember { mutableStateOf(false) }
    var pendingCount       by remember { mutableStateOf(uploadQueue.pendingCount()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.fillMaxWidth()) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor             = MaterialTheme.colorScheme.primary,
                    titleContentColor          = MaterialTheme.colorScheme.secondary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(24.dp),
            verticalArrangement    = Arrangement.spacedBy(16.dp),
            horizontalAlignment    = Alignment.CenterHorizontally
        ) {
            // Research opt-in card
            Card(modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment     = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Opt-In to Research", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Allows your data and onboarding information to be shared with the research database.",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(
                            checked         = optedIn,
                            onCheckedChange = { enabled ->
                                if (enabled) {
                                    showResearchDialog = true
                                } else {
                                    optedIn = false
                                    storage.setResearchOptIn(false)
                                    statusMessage = "Opted out. Data will stay local."
                                }
                            }
                        )
                    }
                    if (optedIn) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Research ID: ${storage.getUserId() ?: "Generating..."}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
            }

            // Sync card — only shown when opted in
            if (optedIn) {
                Card(modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)) {
                    Column(modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Upload Queue", style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    if (pendingCount == 0) "All data uploaded ✓"
                                    else "$pendingCount item${if (pendingCount == 1) "" else "s"} pending upload",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (pendingCount == 0) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isSyncing) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                            }
                        }
                        Button(
                            onClick = {
                                isSyncing = true
                                statusMessage = "Syncing..."
                                scope.launch {
                                    val uploaded = uploadQueue.flush()
                                    pendingCount = uploadQueue.pendingCount()
                                    isSyncing = false
                                    statusMessage = if (uploaded > 0)
                                        "Synced $uploaded item${if (uploaded == 1) "" else "s"} ✓"
                                    else if (pendingCount == 0)
                                        "Everything is already uploaded ✓"
                                    else
                                        "Sync failed — check your connection"
                                }
                            },
                            enabled  = !isSyncing,
                            modifier = Modifier.fillMaxWidth(),
                            colors   = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.onSecondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sync Now", color = MaterialTheme.colorScheme.onSecondary)
                        }
                    }
                }
            }

            if (statusMessage.isNotEmpty()) {
                Text(statusMessage, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary)
            }

            Button(onClick = onNavigateUserInfo, modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
                Text("User Information", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSecondary)
            }
            Button(onClick = onNavigateAbout, modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
                Text("About", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSecondary)
            }
        }
    }

    if (showResearchDialog) {
        AlertDialog(
            onDismissRequest = { showResearchDialog = false },
            title = { Text("Complete Research Onboarding") },
            text  = { Text("To opt in to research, please complete the onboarding form so your participant information and consent choices can be saved to the database.") },
            confirmButton = {
                Button(onClick = {
                    showResearchDialog = false
                    storage.getOrCreateUserId()
                    storage.setResearchOptIn(true)
                    optedIn = true
                    onNavigateOnboarding()
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) { Text("Continue", color = MaterialTheme.colorScheme.onSecondary) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showResearchDialog = false; optedIn = false; storage.setResearchOptIn(false)
                }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OnboardingScreen(
    storage: LocalStorage,
    repository: GloveworksRepository,
    scope: kotlinx.coroutines.CoroutineScope,
    onComplete: () -> Unit
) {
    val authManager = remember { FirebaseAuthManager() }
    val uploader    = remember { FirebaseUploader() }

    var firstName    by remember { mutableStateOf("") }
    var lastName     by remember { mutableStateOf("") }
    var email        by remember { mutableStateOf("") }
    var dob          by remember { mutableStateOf("") }
    var phone        by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var submitError  by remember { mutableStateOf<String?>(null) }

    val pdqResponses = remember {
        mutableStateListOf<Int>().apply { repeat(pdqQuestions.size) { add(0) } }
    }

    val isFormValid = firstName.isNotBlank() && lastName.isNotBlank() &&
            email.isNotBlank() && dob.isNotBlank() && phone.isNotBlank() &&
            pdqResponses.none { it == 0 }

    fun resetAllFields() {
        firstName = ""; lastName = ""; email = ""; dob = ""; phone = ""
        for (i in pdqResponses.indices) pdqResponses[i] = 0
        submitError = null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Research Onboarding", fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.fillMaxWidth()) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.secondary
                )
            )
        },
        bottomBar = {
            BottomAppBar {
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { resetAllFields() }) { Text("Clear") }
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Complete this form to opt in to research data sharing.")
            OutlinedTextField(value = firstName, onValueChange = { firstName = it },
                label = { Text("First Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = lastName, onValueChange = { lastName = it },
                label = { Text("Last Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = email, onValueChange = { email = it },
                label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
            OutlinedTextField(value = dob, onValueChange = { dob = it },
                label = { Text("Date of Birth (MM/DD/YYYY)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = phone, onValueChange = { phone = it },
                label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))

            Spacer(modifier = Modifier.height(8.dp))
            Text("PDQ-8 Survey", style = MaterialTheme.typography.titleMedium)

            pdqQuestions.forEachIndexed { index, question ->
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(question, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        pdqOptions.forEachIndexed { optIndex, option ->
                            FilterChip(selected = pdqResponses[index] == optIndex + 1,
                                onClick = { pdqResponses[index] = optIndex + 1 },
                                label = { Text(option, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                }
            }

            if (!isFormValid) {
                Text("Please fill all fields and answer all PDQ-8 questions.",
                    color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            if (submitError != null) {
                Text(submitError!!, color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = {
                    scope.launch {
                        isSubmitting = true; submitError = null
                        val userId = storage.getOrCreateUserId()
                        storage.putString(StorageKeys.USER_TYPE, "gloveworks")
                        storage.putString(StorageKeys.USER_NAME, firstName)
                        storage.putString(StorageKeys.USER_LAST_NAME, lastName)
                        storage.putString(StorageKeys.USER_EMAIL, email)
                        storage.putString(StorageKeys.USER_DOB, dob)
                        storage.putString(StorageKeys.USER_PHONE, phone)
                        storage.putString(StorageKeys.USER_PDQ, pdqResponses.joinToString(","))
                        storage.putBoolean(StorageKeys.SHARE_MOTION, true)
                        storage.putBoolean(StorageKeys.SHARE_VOICE, true)

                        val profile = UserProfile(userId, UserType.GLOVEWORKS, firstName, lastName,
                            email, dob, phone, pdqResponses.toList(), shareMotion = true, shareVoice = true)
                        repository.insertUserProfile(profile, researchOptIn = true)

                        val uid = authManager.currentUid ?: authManager.signInAnonymously()
                        if (uid != null) {
                            uploader.uploadUserProfile(uid, profile)
                                .onFailure { submitError = "Profile saved locally. Cloud sync will retry." }
                        }
                        isSubmitting = false
                        onComplete()
                    }
                },
                enabled  = isFormValid && !isSubmitting,
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                if (isSubmitting) CircularProgressIndicator(modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onSecondary)
                else Text("Submit", color = MaterialTheme.colorScheme.onSecondary)
            }
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UserInfoScreen(
    storage: LocalStorage, repository: GloveworksRepository,
    scope: kotlinx.coroutines.CoroutineScope, onBack: () -> Unit, onReset: () -> Unit
) {
    val userId   = storage.getUserId()
    val userType = storage.getString(StorageKeys.USER_TYPE)
    var showResetDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("User Information", fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.fillMaxWidth()) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor             = MaterialTheme.colorScheme.primary,
                    titleContentColor          = MaterialTheme.colorScheme.secondary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (userId == null) {
                Text("No research profile found.", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            } else {
                Text("User Type: ${if (userType == "gloveworks") "Research Participant" else "Local Only"}")
                Text("User ID: $userId")
                Spacer(modifier = Modifier.height(8.dp))
                if (userType == "gloveworks") {
                    val name     = storage.getString(StorageKeys.USER_NAME)      ?: "N/A"
                    val lastName = storage.getString(StorageKeys.USER_LAST_NAME) ?: ""
                    val email    = storage.getString(StorageKeys.USER_EMAIL)     ?: "N/A"
                    val dob      = storage.getString(StorageKeys.USER_DOB)       ?: "N/A"
                    val phone    = storage.getString(StorageKeys.USER_PHONE)     ?: "N/A"
                    val pdqRaw   = storage.getString(StorageKeys.USER_PDQ)
                    Text("Name: $name $lastName"); Text("Email: $email")
                    Text("Date of Birth: $dob");   Text("Phone: $phone")
                    if (!pdqRaw.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("PDQ-8 Responses:", style = MaterialTheme.typography.titleSmall)
                        pdqRaw.split(",").forEachIndexed { index, answer -> Text("Q${index + 1}: $answer") }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { showResetDialog = true }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                Text("Reset All App Data")
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset all app data?") },
            text  = { Text("This will delete all saved local data and database entries on this device. This cannot be undone.") },
            confirmButton = {
                Button(onClick = {
                    showResetDialog = false
                    scope.launch { repository.clearAllData(); storage.clear(); onReset() }
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Reset")
                }
            },
            dismissButton = { TextButton(onClick = { showResetDialog = false }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About", fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.fillMaxWidth()) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor             = MaterialTheme.colorScheme.primary,
                    titleContentColor          = MaterialTheme.colorScheme.secondary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
            Card(modifier = Modifier.fillMaxWidth().padding(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)) {
                Column(modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("GloveWorks App", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Version: 1.0.0")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Developed by:")
                    Text("Ali Nazım Aslan & Niel Salero", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    Text("for Española GloveWorks")
                    Text("at Northern New Mexico College, 2025")
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Learn more at:")
                    Text("sites.google.com/nnmc.edu/espanolagloveworks",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}