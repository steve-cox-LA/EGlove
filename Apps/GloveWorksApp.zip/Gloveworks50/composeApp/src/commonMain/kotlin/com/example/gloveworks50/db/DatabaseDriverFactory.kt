package com.example.gloveworks50.db

import app.cash.sqldelight.db.SqlDriver


expect class DatabaseDriverFactory() {
    fun createDriver(): SqlDriver
}