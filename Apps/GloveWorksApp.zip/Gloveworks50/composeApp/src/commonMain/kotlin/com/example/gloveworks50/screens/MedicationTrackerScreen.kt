package com.example.gloveworks50.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.gloveworks50.auth.FirebaseAuthManager
import com.example.gloveworks50.data.FirebaseUploader
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.MedOption
import com.example.gloveworks50.data.MedicationHistoryEntry
import com.example.gloveworks50.data.StorageKeys
import com.example.gloveworks50.data.UploadQueue
import com.example.gloveworks50.data.isResearchOptedIn
import com.example.gloveworks50.db.GloveworksRepository
import com.example.gloveworks50.ui.GloveworksInfoDialog
import com.example.gloveworks50.ui.GloveworksTopBar
import kotlinx.coroutines.launch
import kotlin.time.Clock
import kotlin.time.ExperimentalTime

private val medOptions = listOf(
    "Carbidopa/Levodopa (Sinemet)", "Pramipexole (Mirapex)", "Ropinirole (Requip)",
    "Rotigotine (Neupro patch)", "Apomorphine (Apokyn)", "Rasagiline (Azilect)",
    "Selegiline (Eldepryl/Zelapar)", "Safinamide (Xadago)", "Entacapone (Comtan)",
    "Opicapone (Ongentys)", "Benztropine (Cogentin)", "Trihexyphenidyl (Artane)",
    "Amantadine (Symmetrel)", "Amantadine ER (Gocovri)"
)

private val frequencyOptions = listOf(
    "Once daily", "2x daily", "3x daily", "4x daily",
    "Every 4 hours", "Every 6 hours", "Every 8 hours", "At bedtime", "As needed"
)

private val dosageUnits = listOf("mg", "mcg", "g", "mg/ml", "patch", "injection", "tablet", "capsule")

private val MED_INFO = """
• Select your medication from the dropdown list.
• Enter your dosage amount (numbers only) and select the unit.
• Choose your frequency from the dropdown.
• Tap Confirm to save the entry locally.
• If opted into research, the entry is also uploaded to the database. Failed uploads are queued and retried automatically.
• Tap Medication History to view all past entries.
• Tap the back arrow to return to the home screen.
""".trim()

private sealed class MedScreen {
    object Main    : MedScreen()
    object History : MedScreen()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalTime::class)
@Composable
fun MedicationTrackerScreen(
    repository: GloveworksRepository,
    uploadQueue: UploadQueue,
    onBack: () -> Unit
) {
    val storage       = remember { LocalStorage() }
    val scope         = rememberCoroutineScope()
    var currentScreen by remember { mutableStateOf<MedScreen>(MedScreen.Main) }

    when (currentScreen) {
        is MedScreen.Main -> MedicationMainScreen(
            storage = storage, scope = scope, repository = repository,
            uploadQueue = uploadQueue, onBack = onBack,
            onViewHistory = { currentScreen = MedScreen.History }
        )
        is MedScreen.History -> MedicationHistoryScreen(
            storage = storage, scope = scope, repository = repository,
            onBack = { currentScreen = MedScreen.Main }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalTime::class)
@Composable
private fun MedicationMainScreen(
    storage: LocalStorage, scope: kotlinx.coroutines.CoroutineScope,
    repository: GloveworksRepository, uploadQueue: UploadQueue,
    onBack: () -> Unit, onViewHistory: () -> Unit
) {
    val uploader    = remember { FirebaseUploader() }
    val authManager = remember { FirebaseAuthManager() }

    var selectedMed       by remember { mutableStateOf<String?>(null) }
    var dosageAmount      by remember { mutableStateOf("") }
    var selectedUnit      by remember { mutableStateOf(dosageUnits.first()) }
    var selectedFrequency by remember { mutableStateOf(frequencyOptions.first()) }
    var medExpanded       by remember { mutableStateOf(false) }
    var unitExpanded      by remember { mutableStateOf(false) }
    var freqExpanded      by remember { mutableStateOf(false) }
    var showGreatJobDialog by remember { mutableStateOf(false) }
    var showInfo          by remember { mutableStateOf(false) }
    var dosageError       by remember { mutableStateOf(false) }

    fun resetInputs() {
        selectedMed = null; dosageAmount = ""; selectedUnit = dosageUnits.first()
        selectedFrequency = frequencyOptions.first(); dosageError = false
    }

    fun buildDosageString(): String {
        val amount = dosageAmount.trim()
        return if (amount.isBlank()) "(not set)" else "$amount $selectedUnit"
    }

    fun onConfirm() {
        val med = selectedMed ?: return
        if (dosageAmount.isNotBlank() && dosageAmount.toFloatOrNull() == null) { dosageError = true; return }
        val entry = MedicationHistoryEntry(
            timestampMs = Clock.System.now().toEpochMilliseconds(),
            medications = listOf(MedOption(med, buildDosageString(), selectedFrequency.trim().ifBlank { "(not set)" }))
        )
        scope.launch {
            try {
                val userId = storage.getString(StorageKeys.USER_ID) ?: "unknown"
                repository.insertMedicationEntry(entry, userId)
                showGreatJobDialog = true
            } catch (e: Exception) { println("Medication save failed: ${e.message}"); resetInputs(); return@launch }

            if (storage.isResearchOptedIn()) {
                val uid = authManager.currentUid ?: authManager.signInAnonymously()
                if (uid != null) {
                    uploader.uploadMedicationEntry(uid, entry)
                        .onFailure { uploadQueue.enqueueMedicationEntry(entry.timestampMs) }
                } else {
                    uploadQueue.enqueueMedicationEntry(entry.timestampMs)
                }
            }
            resetInputs()
        }
    }

    Scaffold(topBar = { GloveworksTopBar(title = "Medications", onBack = onBack, onInfo = { showInfo = true }) }) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)
            .verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Select a medication, then enter your dosage and frequency.")

            ExposedDropdownMenuBox(expanded = medExpanded, onExpandedChange = { medExpanded = !medExpanded }) {
                OutlinedTextField(value = selectedMed.orEmpty(), onValueChange = {}, readOnly = true,
                    label = { Text("Select Medication") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = medExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = medExpanded, onDismissRequest = { medExpanded = false }) {
                    medOptions.forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = {
                            selectedMed = option; dosageAmount = ""; selectedUnit = dosageUnits.first()
                            selectedFrequency = frequencyOptions.first(); dosageError = false; medExpanded = false
                        })
                    }
                }
            }

            // Dosage
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top) {
                OutlinedTextField(
                    value           = dosageAmount,
                    onValueChange   = { dosageAmount = it.filter { ch -> ch.isDigit() || ch == '.' }; dosageError = false },
                    label           = { Text("Amount") },
                    placeholder     = { Text("e.g. 25") },
                    singleLine      = true,
                    isError         = dosageError,
                    supportingText  = if (dosageError) { { Text("Enter a number only", color = MaterialTheme.colorScheme.error) } } else null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier        = Modifier.weight(1f)
                )
                ExposedDropdownMenuBox(expanded = unitExpanded, onExpandedChange = { unitExpanded = !unitExpanded },
                    modifier = Modifier.width(110.dp)) {
                    OutlinedTextField(value = selectedUnit, onValueChange = {}, readOnly = true,
                        label = { Text("Unit") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = unitExpanded, onDismissRequest = { unitExpanded = false }) {
                        dosageUnits.forEach { unit ->
                            DropdownMenuItem(text = { Text(unit) }, onClick = { selectedUnit = unit; unitExpanded = false })
                        }
                    }
                }
            }

            ExposedDropdownMenuBox(expanded = freqExpanded, onExpandedChange = { freqExpanded = !freqExpanded }) {
                OutlinedTextField(value = selectedFrequency, onValueChange = {}, readOnly = true,
                    label = { Text("Frequency") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = freqExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = freqExpanded, onDismissRequest = { freqExpanded = false }) {
                    frequencyOptions.forEach { freq ->
                        DropdownMenuItem(text = { Text(freq) }, onClick = { selectedFrequency = freq; freqExpanded = false })
                    }
                }
            }

            Button(onClick = { onConfirm() }, modifier = Modifier.fillMaxWidth(),
                enabled = selectedMed != null,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) { Text("Confirm", color = MaterialTheme.colorScheme.onSecondary) }
            Button(onClick = onViewHistory, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) { Text("Medication History", color = MaterialTheme.colorScheme.onSecondary) }
        }
    }

    if (showGreatJobDialog) {
        AlertDialog(onDismissRequest = { showGreatJobDialog = false },
            title = { Text("Great Job!") }, text = { Text("Medication entry saved.") },
            confirmButton = { Button(onClick = { showGreatJobDialog = false }) { Text("OK") } })
    }
    if (showInfo) GloveworksInfoDialog("Medication Tracker — How It Works", MED_INFO) { showInfo = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MedicationHistoryScreen(
    storage: LocalStorage, scope: kotlinx.coroutines.CoroutineScope,
    repository: GloveworksRepository, onBack: () -> Unit
) {
    val userId           = storage.getString(StorageKeys.USER_ID) ?: "unknown"
    var history          by remember { mutableStateOf(repository.getMedicationsByUser(userId)) }
    var showClearWarning by remember { mutableStateOf(false) }
    var showInfo         by remember { mutableStateOf(false) }

    Scaffold(topBar = { GloveworksTopBar(title = "Medication History", onBack = onBack, onInfo = { showInfo = true }) }) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)
            .verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (history.isNotEmpty()) {
                Button(onClick = { showClearWarning = true }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Clear Medication History")
                }
            }
            if (history.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("No medication history yet.", textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text("Go to Medications and press Confirm to save an entry.",
                            textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                    }
                }
            } else {
                history.forEach { entry ->
                    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(4.dp)) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(entry.displayDate, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            entry.medications.forEach { med ->
                                Text("• ${med.name}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text("  ${med.dosage}  •  ${med.frequency}", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearWarning) {
        AlertDialog(onDismissRequest = { showClearWarning = false },
            title = { Text("Clear medication history?") },
            text  = { Text("This will permanently delete all saved medication history. This cannot be undone.") },
            confirmButton = {
                Button(onClick = { showClearWarning = false; scope.launch { repository.deleteAllMedications(userId); history = emptyList() } },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Clear") }
            },
            dismissButton = { Button(onClick = { showClearWarning = false }) { Text("Cancel") } })
    }
    if (showInfo) GloveworksInfoDialog("Medication Tracker — How It Works", MED_INFO) { showInfo = false }
}