package com.example.gloveworks50.data


expect class LocalStorage() {
    fun putString(key: String, value: String)
    fun getString(key: String): String?
    fun putBoolean(key: String, value: Boolean)
    fun getBoolean(key: String, default: Boolean = false): Boolean
    fun putInt(key: String, value: Int)
    fun getInt(key: String, default: Int = 0): Int
    fun remove(key: String)
    fun clear()
}


object StorageKeys {
    // User profile
    const val USER_ID           = "user_id"
    const val USER_TYPE         = "type"
    const val USER_NAME         = "name"
    const val USER_LAST_NAME    = "lastName"
    const val USER_EMAIL        = "email"
    const val USER_DOB          = "dob"
    const val USER_PHONE        = "phone"
    const val USER_PDQ          = "pdq"
    const val SHARE_MOTION      = "share_motion"
    const val SHARE_VOICE       = "share_voice"
    const val USER_AGE          = "age"
    const val DIAGNOSED_PD      = "diagnosedWithPD"

    // Research opt-in
    const val RESEARCH_OPT_IN   = "research_opt_in"

    // Session IDs
    const val MOTION_SESSION_ID = "motion_session_id"
    const val VOICE_SESSION_ID  = "voice_session_id"

    // Glove control
    const val GLOVE_PIN         = "glove_control_pin"
    const val GLOVE_MOTOR_AMP   = "MAval"
    const val GLOVE_PATTERN_DUR = "PDval"
    const val GLOVE_BURST_DUR   = "BDval"

    // Symptom history
    const val SYMPTOM_HISTORY_PHYSICAL      = "symptom_history_physical"
    const val SYMPTOM_HISTORY_LIFESTYLE     = "symptom_history_lifestyle"
    const val SYMPTOM_HISTORY_PSYCHOLOGICAL = "symptom_history_psychological"

    // Medication history
    const val MEDICATION_HISTORY = "medication_history_v1"
}

// Research opt-in helpers

fun LocalStorage.isResearchOptedIn(): Boolean = getBoolean(StorageKeys.RESEARCH_OPT_IN, false)
fun LocalStorage.setResearchOptIn(value: Boolean) = putBoolean(StorageKeys.RESEARCH_OPT_IN, value)

// User ID helper

fun LocalStorage.getUserId(): String? = getString(StorageKeys.USER_ID)

fun LocalStorage.getOrCreateUserId(): String {
    val existing = getString(StorageKeys.USER_ID)
    if (existing != null) return existing
    val newId = generateUserId()
    putString(StorageKeys.USER_ID, newId)
    return newId
}

@OptIn(kotlin.time.ExperimentalTime::class)
fun generateUserId(): String {
    val timestamp = kotlin.time.Clock.System.now().toEpochMilliseconds()
    val random    = (0..999999).random().toString().padStart(6, '0')
    return "glw_${timestamp}_$random"
}

// Symptom history helpers

fun SymptomSubmission.serialize(): String {
    val entriesPart = entries.joinToString("|") { e ->
        "${e.question.replace("|", "/")}:${e.score}"
    }
    return "$timestampMs|$category|$entriesPart"
}

fun deserializeSubmission(userId: String, raw: String): SymptomSubmission? {
    return try {
        val parts = raw.split("|")
        if (parts.size < 3) return null
        val timestampMs = parts[0].toLong()
        val category    = parts[1]
        val entries = parts.drop(2).mapNotNull { entry ->
            val colonIdx = entry.lastIndexOf(':')
            if (colonIdx < 0) return@mapNotNull null
            val question = entry.substring(0, colonIdx)
            val score    = entry.substring(colonIdx + 1).toIntOrNull() ?: return@mapNotNull null
            SymptomEntry(question, score)
        }
        SymptomSubmission(
            submissionId = "${userId}_$timestampMs",
            userId       = userId,
            timestampMs  = timestampMs,
            category     = category,
            entries      = entries
        )
    } catch (_: Exception) { null }
}

fun LocalStorage.saveSymptomSubmission(submission: SymptomSubmission) {
    val key = when (submission.category) {
        "Physical"      -> StorageKeys.SYMPTOM_HISTORY_PHYSICAL
        "Lifestyle"     -> StorageKeys.SYMPTOM_HISTORY_LIFESTYLE
        "Psychological" -> StorageKeys.SYMPTOM_HISTORY_PSYCHOLOGICAL
        else            -> return
    }
    val existing   = getString(key) ?: ""
    val serialized = submission.serialize()
    val updated    = if (existing.isBlank()) serialized else "$existing\n$serialized"
    putString(key, updated)
}

fun LocalStorage.loadSymptomHistory(userId: String, key: String): List<SymptomSubmission> {
    val raw = getString(key) ?: return emptyList()
    return raw.split("\n")
        .filter { it.isNotBlank() }
        .mapNotNull { deserializeSubmission(userId, it) }
        .sortedByDescending { it.timestampMs }
}

// Medication history helpers

fun MedicationHistoryEntry.serialize(): String {
    val medsPart = medications.joinToString("|") { med ->
        "${med.name.replace("|","/")}::${med.dosage.replace("|","/")}::${med.frequency.replace("|","/")}".replace("~", "-")
    }
    return "$timestampMs~$medsPart"
}

fun deserializeMedEntry(raw: String): MedicationHistoryEntry? {
    return try {
        val tildeIdx = raw.indexOf('~')
        if (tildeIdx < 0) return null
        val timestampMs = raw.substring(0, tildeIdx).toLong()
        val medsPart    = raw.substring(tildeIdx + 1)
        val medications = medsPart.split("|").mapNotNull { medStr ->
            val parts = medStr.split("::")
            if (parts.size < 3) return@mapNotNull null
            MedOption(name = parts[0], dosage = parts[1], frequency = parts[2])
        }
        MedicationHistoryEntry(timestampMs = timestampMs, medications = medications)
    } catch (_: Exception) { null }
}

fun LocalStorage.saveMedicationEntry(entry: MedicationHistoryEntry) {
    val existing   = getString(StorageKeys.MEDICATION_HISTORY) ?: ""
    val serialized = entry.serialize()
    val updated    = if (existing.isBlank()) serialized else "$existing\n$serialized"
    putString(StorageKeys.MEDICATION_HISTORY, updated)
}

fun LocalStorage.loadMedicationHistory(): List<MedicationHistoryEntry> {
    val raw = getString(StorageKeys.MEDICATION_HISTORY) ?: return emptyList()
    return raw.split("\n")
        .filter { it.isNotBlank() }
        .mapNotNull { deserializeMedEntry(it) }
        .sortedByDescending { it.timestampMs }
}

fun LocalStorage.clearMedicationHistory() {
    remove(StorageKeys.MEDICATION_HISTORY)
}