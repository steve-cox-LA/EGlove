package com.example.gloveworks50.data


expect class DataUploader() {
    suspend fun uploadGaitSession(session: GaitSession): Result<Unit>
    suspend fun uploadVoiceSession(session: VoiceSession): Result<Unit>
    suspend fun uploadUserProfile(profile: UserProfile): Result<Unit>
    suspend fun uploadSymptomSubmission(submission: SymptomSubmission): Result<Unit>
    suspend fun uploadMedicationEntry(entry: MedicationHistoryEntry): Result<Unit>
}