package com.example.gloveworks50.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Shared formatting
fun fmtDec(v: Double, d: Int): String {
    var f = 1L; repeat(d) { f *= 10L }
    val sc = v * f; val r = if (sc >= 0.0) (sc + 0.5).toLong() else (sc - 0.5).toLong()
    val ip = r / f; val raw = r % f; val fp = if (raw < 0L) -raw else raw
    return "$ip.${fp.toString().padStart(d, '0')}"
}
fun fmtMetric(v: Double) = fmtDec(v, 4)

// KMP-safe date formatter
fun fullDate(ms: Long): String {
    val s  = ms / 1000L
    val mn = ((s / 60L) % 60L).toString().padStart(2, '0')
    val h  = ((s / 3600L) % 24L).toString().padStart(2, '0')
    var rem = s / 86400L; var y = 1970
    while (true) {
        val dy = if ((y%4==0&&y%100!=0)||y%400==0) 366L else 365L
        if (rem < dy) break; rem -= dy; y++
    }
    val ml = intArrayOf(31, if ((y%4==0&&y%100!=0)||y%400==0) 29 else 28,
        31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    var mo = 1; for (len in ml) { if (rem < len) break; rem -= len; mo++ }
    return "${y.toString().padStart(4,'0')}-${mo.toString().padStart(2,'0')}-${(rem+1).toString().padStart(2,'0')} $h:$mn UTC"
}


// Shared scorecard
@Composable
fun JitterShimmerCard(jitter: Double, shimmer: Double) {
    ElevatedCard(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(4.dp)
    ) {
        Row(
            modifier              = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            MetricItem("Jitter",  fmtMetric(jitter))
            MetricItem("Shimmer", fmtMetric(shimmer))
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color      = MaterialTheme.colorScheme.secondary)
        Text(label, style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


// Shared graph card wrapper
@Composable
fun MonitorGraphCard(
    label: String,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Card(modifier = modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall,
                color    = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier.padding(bottom = 4.dp))
            Box(modifier = Modifier.fillMaxSize(), content = content)
        }
    }
}


// Shared FFT graph
@Composable
fun SharedFFTGraph(fftData: List<Pair<Float, Float>>) {
    val gridColor  = MaterialTheme.colorScheme.surfaceVariant
    val labelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
    val lineColor  = MaterialTheme.colorScheme.secondary
    val measurer   = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 9.sp, color = labelColor)
    Canvas(modifier = Modifier.fillMaxSize()) {
        val leftPad   = 44f
        val bottomPad = 20f
        val plotW     = size.width  - leftPad
        val plotH     = size.height - bottomPad
        if (fftData.size < 2) return@Canvas
        val maxPow = fftData.maxOfOrNull { it.second }?.coerceAtLeast(1f) ?: 1f
        val maxFrq = fftData.maxOfOrNull { it.first  }?.coerceAtLeast(0.001f) ?: 1f
        listOf(0f, 0.5f, 1f).forEach { frac ->
            val y = plotH - frac * plotH
            drawLine(gridColor, Offset(leftPad, y), Offset(size.width, y), strokeWidth = 1f)
            val t = measurer.measure("${(frac * 100).toInt()}%", labelStyle)
            drawText(t, topLeft = Offset(leftPad - t.size.width - 4f, y - t.size.height / 2f))
        }
        listOf(0f, 0.5f, 1f).forEach { frac ->
            val hz = frac * maxFrq
            val x  = leftPad + frac * plotW
            val t  = measurer.measure(fmtDec(hz.toDouble(), 1), labelStyle)
            drawText(t, topLeft = Offset(x - t.size.width / 2f, plotH + 4f))
        }
        val path = Path()
        fftData.forEachIndexed { i, (f, p) ->
            val x = leftPad + (f / maxFrq) * plotW
            val y = plotH   - (p / maxPow) * plotH
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, lineColor, style = Stroke(width = 3f))
    }
}


// Shared epoch frequency trend graph
@Composable
fun SharedEpochFreqTrendGraph(epochFreqList: List<Pair<Int, Float>>, totalEpochs: Int) {
    val lineColor  = MaterialTheme.colorScheme.tertiary
    val gridColor  = MaterialTheme.colorScheme.surfaceVariant
    val labelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
    val measurer   = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 9.sp, color = labelColor)
    Canvas(modifier = Modifier.fillMaxSize()) {
        val leftPad   = 44f
        val bottomPad = 20f
        val plotW     = size.width  - leftPad
        val plotH     = size.height - bottomPad
        if (epochFreqList.isEmpty()) return@Canvas
        val maxY = (epochFreqList.maxOfOrNull { it.second } ?: 1f).coerceAtLeast(1f)
        listOf(0.25f, 0.5f, 0.75f, 1f).forEach { frac ->
            val v = frac * maxY
            val y = plotH - frac * plotH
            drawLine(gridColor, Offset(leftPad, y), Offset(size.width, y), strokeWidth = 1f)
            val t = measurer.measure(fmtDec(v.toDouble(), 1), labelStyle)
            drawText(t, topLeft = Offset(leftPad - t.size.width - 4f, y - t.size.height / 2f))
        }
        // Derive X labels from totalEpochs — no hardcoded numbers
        val step = (totalEpochs / 4).coerceAtLeast(1)
        (1..totalEpochs step step).plus(totalEpochs).distinct().forEach { ep ->
            val x = leftPad + ((ep - 1f) / (totalEpochs - 1f)) * plotW
            val t = measurer.measure("$ep", labelStyle)
            drawText(t, topLeft = Offset(x - t.size.width / 2f, plotH + 4f))
        }
        if (epochFreqList.size < 2) {
            drawCircle(lineColor, radius = 5f,
                center = Offset(leftPad, plotH - (epochFreqList[0].second / maxY) * plotH))
            return@Canvas
        }
        val path = Path()
        epochFreqList.forEachIndexed { i, (epoch, freq) ->
            val x = leftPad + ((epoch - 1f) / (totalEpochs - 1f)) * plotW
            val y = plotH   - (freq.coerceIn(0f, maxY) / maxY) * plotH
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, lineColor, style = Stroke(width = 2.5f))
        epochFreqList.forEach { (epoch, freq) ->
            val x = leftPad + ((epoch - 1f) / (totalEpochs - 1f)) * plotW
            val y = plotH   - (freq.coerceIn(0f, maxY) / maxY) * plotH
            drawCircle(lineColor, radius = 4f, center = Offset(x, y))
        }
    }
}


// Shared metric trend graph (history screens)
@Composable
fun SharedMetricTrendGraph(values: List<Float>) {
    val primaryColor  = MaterialTheme.colorScheme.primary
    val tertiaryColor = MaterialTheme.colorScheme.tertiary
    val gridColor     = MaterialTheme.colorScheme.surfaceVariant
    val labelColor    = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
    val measurer      = rememberTextMeasurer()
    val labelStyle    = TextStyle(fontSize = 9.sp, color = labelColor)
    Canvas(modifier = Modifier.fillMaxSize()) {
        if (values.isEmpty()) return@Canvas
        val leftPad   = 44f
        val bottomPad = 20f
        val plotW     = size.width  - leftPad
        val plotH     = size.height - bottomPad
        val minY   = 0f
        val maxY   = (values.maxOrNull() ?: 1f).coerceAtLeast(0.001f)
        val rangeY = maxY - minY
        listOf(0f, 0.5f, 1f).forEach { frac ->
            val v = minY + frac * rangeY
            val y = plotH - frac * plotH
            drawLine(gridColor, Offset(leftPad, y), Offset(size.width, y), strokeWidth = 1f)
            val t = measurer.measure(fmtDec(v.toDouble(), 4), labelStyle)
            drawText(t, topLeft = Offset(leftPad - t.size.width - 4f, y - t.size.height / 2f))
        }
        if (values.size >= 2) {
            listOf(0, values.size / 2, values.size - 1).forEach { idx ->
                val x = leftPad + (idx.toFloat() / (values.size - 1)) * plotW
                val t = measurer.measure("${idx + 1}", labelStyle)
                drawText(t, topLeft = Offset(x - t.size.width / 2f, plotH + 4f))
            }
        }
        if (values.size == 1) {
            val y = plotH - ((values[0] - minY) / rangeY) * plotH
            drawCircle(primaryColor, radius = 8f, center = Offset(leftPad + plotW / 2f, y))
            return@Canvas
        }
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = leftPad + (i.toFloat() / (values.size - 1)) * plotW
            val y = plotH   - ((v - minY) / rangeY) * plotH
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, primaryColor, style = Stroke(width = 3f))
        values.forEachIndexed { i, v ->
            val x = leftPad + (i.toFloat() / (values.size - 1)) * plotW
            val y = plotH   - ((v - minY) / rangeY) * plotH
            drawCircle(tertiaryColor, radius = 6f, center = Offset(x, y))
            drawCircle(primaryColor,  radius = 3f, center = Offset(x, y))
        }
    }
}