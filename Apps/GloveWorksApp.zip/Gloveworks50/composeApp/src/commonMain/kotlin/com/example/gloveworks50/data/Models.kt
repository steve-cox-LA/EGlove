package com.example.gloveworks50.data

import kotlin.math.exp


// Voice scoring
const val JITTER_THRESHOLD  = 1.0     // %
const val SHIMMER_THRESHOLD = 0.35    // dB
const val VOICE_ALPHA       = 0.5     // exponential decay tuning

/**
 * Combined voice score (1–10).
 * R = 0.5 × (jitter/threshold + shimmer/threshold)
 * score = 1 + 9 × e^(-α × R)
 */
fun computeVoiceScore(avgJitter: Double, avgShimmer: Double): Double {
    val r = 0.5 * (avgJitter / JITTER_THRESHOLD + avgShimmer / SHIMMER_THRESHOLD)
    return 1.0 + 9.0 * exp(-VOICE_ALPHA * r)
}

fun voiceScoreLabel(score: Double): String = when {
    score >= 8.0 -> "Good"
    score >= 5.5 -> "Moderate"
    else         -> "Variable"
}


// Gait scoring
// Thresholds for normalised TV (dimensionless ratio — different scale to voice)
const val GAIT_JITTER_THRESHOLD  = 0.15   // normalised frequency TV
const val GAIT_SHIMMER_THRESHOLD = 0.10   // normalised amplitude TV
const val GAIT_ALPHA             = 0.5

/**
 * Combined gait score (1–10). Identical formula to voice, different thresholds.
 * R = 0.5 × (jitter/threshold + shimmer/threshold)
 * score = 1 + 9 × e^(-α × R)
 */
fun computeGaitScore(jitter: Double, shimmer: Double): Double {
    val r = 0.5 * (jitter / GAIT_JITTER_THRESHOLD + shimmer / GAIT_SHIMMER_THRESHOLD)
    return 1.0 + 9.0 * exp(-GAIT_ALPHA * r)
}

fun gaitScoreLabel(score: Double): String = when {
    score >= 8.0 -> "Stable"
    score >= 5.5 -> "Moderate"
    else         -> "Variable"
}


// Gait models
data class GaitEpoch(
    val epochIndex: Int,
    val dominantFrequencyHz: Float,
    val accelerometerSamples: List<Triple<Float, Float, Float>> = emptyList()
)

data class GaitSession(
    val sessionId: String,
    val userId: String,
    val timestampMs: Long,
    val epochs: List<GaitEpoch>,
    val averageDominantFrequencyHz: Float = if (epochs.isEmpty()) 0f
    else epochs.map { it.dominantFrequencyHz }.average().toFloat(),
    val totalVariation: Double = if (epochs.size < 2) 0.0
    else epochs.zipWithNext().sumOf { (a, b) ->
        val diff = (b.dominantFrequencyHz - a.dominantFrequencyHz).toDouble()
        if (diff < 0.0) -diff else diff
    },
    val shimmer: Double = 0.0
)


// Voice models
data class VoiceEpoch(
    val epochIndex: Int,
    val rms: Float,
    val dominantFrequencyHz: Float,
    val jitterPercent: Double,
    val shimmerDb: Double,
    val validCycles: Int
)

data class VoiceSession(
    val sessionId: String,
    val userId: String,
    val timestampMs: Long,
    val epochs: List<VoiceEpoch>,
    val averageRms: Float = if (epochs.isEmpty()) 0f
    else epochs.map { it.rms }.average().toFloat(),
    val averageDominantFrequencyHz: Float = if (epochs.isEmpty()) 0f
    else epochs.map { it.dominantFrequencyHz }.average().toFloat(),
    val avgJitter: Double = if (epochs.isEmpty()) 0.0
    else epochs.map { it.jitterPercent }.average(),
    val avgShimmer: Double = if (epochs.isEmpty()) 0.0
    else epochs.map { it.shimmerDb }.average(),
    val voiceScore: Double = computeVoiceScore(
        if (epochs.isEmpty()) 0.0 else epochs.map { it.jitterPercent }.average(),
        if (epochs.isEmpty()) 0.0 else epochs.map { it.shimmerDb }.average()
    )
)


// Symptom models
data class SymptomEntry(val question: String, val score: Int)

data class SymptomSubmission(
    val submissionId: String,
    val userId: String,
    val timestampMs: Long,
    val category: String,
    val entries: List<SymptomEntry>
) {
    val displayDate: String get() {
        val s  = timestampMs / 1000
        val mn = ((s / 60) % 60).toString().padStart(2, '0')
        val h  = ((s / 3600) % 24).toString().padStart(2, '0')
        return "Submitted at $h:$mn"
    }
}


// Medication models
data class MedOption(val name: String, val dosage: String, val frequency: String)

data class MedicationHistoryEntry(
    val timestampMs: Long,
    val medications: List<MedOption>
) {
    val displayDate: String get() {
        val s   = timestampMs / 1000
        val mn  = ((s / 60) % 60).toString().padStart(2, '0')
        val h   = ((s / 3600) % 24).toString().padStart(2, '0')
        val d   = s / 86400
        var rem = d; var y = 1970
        while (true) {
            val dy = if ((y%4==0&&y%100!=0)||y%400==0) 366L else 365L
            if (rem < dy) break; rem -= dy; y++
        }
        val ml = intArrayOf(31, if ((y%4==0&&y%100!=0)||y%400==0) 29 else 28,
            31,30,31,30,31,31,30,31,30,31)
        var mo = 1; for (len in ml) { if (rem < len) break; rem -= len; mo++ }
        return "$y-${mo.toString().padStart(2,'0')}-${(rem+1).toString().padStart(2,'0')} $h:$mn"
    }
}


// User profile models
enum class UserType { GLOVEWORKS, LOCAL }

data class UserProfile(
    val userId: String,
    val userType: UserType,
    val firstName: String?  = null,
    val lastName: String?   = null,
    val email: String?      = null,
    val dob: String?        = null,
    val phone: String?      = null,
    val pdqResponses: List<Int>? = null,
    val age: String?        = null,
    val diagnosedWithPD: Boolean? = null,
    val shareMotion: Boolean = false,
    val shareVoice: Boolean  = false
)