package com.example.gloveworks50.data

import com.example.gloveworks50.auth.FirebaseAuthManager
import com.example.gloveworks50.db.GloveworksRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class UploadQueue(
    private val storage: LocalStorage,
    private val repository: GloveworksRepository,
    private val uploader: FirebaseUploader,
    private val authManager: FirebaseAuthManager
) {
    //Queue key constants

    companion object {
        const val KEY_GAIT     = "upload_queue_gait"
        const val KEY_VOICE    = "upload_queue_voice"
        const val KEY_SYMPTOMS = "upload_queue_symptoms"
        const val KEY_MEDS     = "upload_queue_meds"
    }

    // Enqueue helpers — called when a save succeeds but upload fails

    fun enqueueGaitSession(sessionId: String) = appendToQueue(KEY_GAIT, sessionId)
    fun enqueueVoiceSession(sessionId: String) = appendToQueue(KEY_VOICE, sessionId)
    fun enqueueSymptomSubmission(submissionId: String) = appendToQueue(KEY_SYMPTOMS, submissionId)
    fun enqueueMedicationEntry(timestampMs: Long) = appendToQueue(KEY_MEDS, timestampMs.toString())

    private fun appendToQueue(key: String, id: String) {
        val existing = storage.getString(key) ?: ""
        val updated  = if (existing.isBlank()) id else "$existing,$id"
        storage.putString(key, updated)
    }

    private fun readQueue(key: String): List<String> {
        val raw = storage.getString(key) ?: return emptyList()
        return raw.split(",").filter { it.isNotBlank() }
    }

    private fun removeFromQueue(key: String, id: String) {
        val updated = readQueue(key).filter { it != id }.joinToString(",")
        storage.putString(key, updated)
    }

    // Queue sizes

    fun pendingCount(): Int =
        readQueue(KEY_GAIT).size +
                readQueue(KEY_VOICE).size +
                readQueue(KEY_SYMPTOMS).size +
                readQueue(KEY_MEDS).size

    // Flush — attempt to upload everything in the queue

    suspend fun flush(): Int {
        if (!storage.isResearchOptedIn()) return 0

        val uid = authManager.currentUid ?: authManager.signInAnonymously() ?: return 0
        val userId = storage.getUserId() ?: return 0
        var successCount = 0

        // Gait sessions
        val gaitIds = readQueue(KEY_GAIT)
        if (gaitIds.isNotEmpty()) {
            val allSessions = repository.getGaitSessionsByUser(userId)
            gaitIds.forEach { sessionId ->
                val session = allSessions.find { it.sessionId == sessionId }
                if (session != null) {
                    uploader.uploadGaitSession(uid, session)
                        .onSuccess { removeFromQueue(KEY_GAIT, sessionId); successCount++ }
                } else {
                    // Session no longer exists locally — remove from queue
                    removeFromQueue(KEY_GAIT, sessionId)
                }
            }
        }

        // Voice sessions
        val voiceIds = readQueue(KEY_VOICE)
        if (voiceIds.isNotEmpty()) {
            val allSessions = repository.getVoiceSessionsByUser(userId)
            voiceIds.forEach { sessionId ->
                val session = allSessions.find { it.sessionId == sessionId }
                if (session != null) {
                    uploader.uploadVoiceSession(uid, session)
                        .onSuccess { removeFromQueue(KEY_VOICE, sessionId); successCount++ }
                } else {
                    removeFromQueue(KEY_VOICE, sessionId)
                }
            }
        }

        // Symptom submissions
        val symptomIds = readQueue(KEY_SYMPTOMS)
        if (symptomIds.isNotEmpty()) {
            val allSubmissions = repository.getSubmissionsByUser(userId)
            symptomIds.forEach { submissionId ->
                val submission = allSubmissions.find { it.submissionId == submissionId }
                if (submission != null) {
                    uploader.uploadSymptomSubmission(uid, submission)
                        .onSuccess { removeFromQueue(KEY_SYMPTOMS, submissionId); successCount++ }
                } else {
                    removeFromQueue(KEY_SYMPTOMS, submissionId)
                }
            }
        }

        // Medication entries
        val medTimestamps = readQueue(KEY_MEDS)
        if (medTimestamps.isNotEmpty()) {
            val allMeds = repository.getMedicationsByUser(userId)
            medTimestamps.forEach { tsString ->
                val ts    = tsString.toLongOrNull() ?: run { removeFromQueue(KEY_MEDS, tsString); return@forEach }
                val entry = allMeds.find { it.timestampMs == ts }
                if (entry != null) {
                    uploader.uploadMedicationEntry(uid, entry)
                        .onSuccess { removeFromQueue(KEY_MEDS, tsString); successCount++ }
                } else {
                    removeFromQueue(KEY_MEDS, tsString)
                }
            }
        }

        return successCount
    }

    // Convenience: flush on a background coroutine

    fun flushAsync(scope: CoroutineScope, onComplete: ((Int) -> Unit)? = null) {
        scope.launch(Dispatchers.Default) {
            val count = flush()
            onComplete?.invoke(count)
        }
    }
}