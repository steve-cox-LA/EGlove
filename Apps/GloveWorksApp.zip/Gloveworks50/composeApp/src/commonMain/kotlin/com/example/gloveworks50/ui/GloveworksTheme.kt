package com.example.gloveworks50.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Reds (primary)
private val Red900      = Color(0xFF7B1A13)
private val Red800      = Color(0xFF9C2318)
private val Red700      = Color(0xFFB02D1E)
private val Red600      = Color(0xFFC0392B)
private val Red500      = Color(0xFFD94030)
private val Red400      = Color(0xFFE74C3C)
private val Red100      = Color(0xFFFFDAD6)
private val Red050      = Color(0xFFFFF0EE)

// Yellows / Golds
private val Gold600     = Color(0xFFD4920A)
private val Gold500     = Color(0xFFF0A500)
private val Gold400     = Color(0xFFF5BC35)
private val Gold100     = Color(0xFFFFF0C0)
private val Gold050     = Color(0xFFFFFBED)

// Warm Orange
private val Orange500   = Color(0xFFE8621A)
private val Orange100   = Color(0xFFFFDDBB)

// Neutrals
private val WarmGray700 = Color(0xFF3D2B28)
private val WarmGray600 = Color(0xFF5C3D39)
private val WarmGray100 = Color(0xFFF9F3F2)
private val WarmGray050 = Color(0xFFFDF8F7)
private val White       = Color(0xFFFFFFFF)
private val NearBlack   = Color(0xFF2D1A17)

// Semantic
private val ErrorRed     = Color(0xFFB91C1C)
private val ErrorRedDark = Color(0xFFEF5350)


// Light colour scheme
private val LightColors = lightColorScheme(
    primary            = Red600,
    onPrimary          = White,
    primaryContainer   = Red050,
    onPrimaryContainer = Red800,

    secondary          = Gold500,
    onSecondary        = NearBlack,
    secondaryContainer = Gold050,
    onSecondaryContainer = Gold600,

    tertiary           = Orange500,
    onTertiary         = White,
    tertiaryContainer  = Orange100,
    onTertiaryContainer = Red700,

    background         = WarmGray100,
    onBackground       = NearBlack,

    surface            = WarmGray050,
    onSurface          = NearBlack,
    surfaceVariant     = Color(0xFFF5E8E6),
    onSurfaceVariant   = WarmGray600,

    outline            = Color(0xFFD4A8A4),
    outlineVariant     = Color(0xFFEDD5D2),

    error              = ErrorRed,
    onError            = White,
    errorContainer     = Red100,
    onErrorContainer   = Red900,

    inverseSurface     = Red800,
    inverseOnSurface   = Red050,
    inversePrimary     = Red400,

    scrim              = Red900.copy(alpha = 0.5f)
)


// Dark colour scheme
private val DarkColors = darkColorScheme(
    primary            = Red400,
    onPrimary          = Red900,
    primaryContainer   = Red700,
    onPrimaryContainer = Red100,

    secondary          = Gold400,
    onSecondary        = NearBlack,
    secondaryContainer = Gold600,
    onSecondaryContainer = Gold050,

    tertiary           = Color(0xFFF0924A),
    onTertiary         = Red900,
    tertiaryContainer  = Orange500,
    onTertiaryContainer = Gold050,

    background         = Color(0xFF221210),
    onBackground       = Color(0xFFF5E8E6),

    surface            = Color(0xFF2E1A17),
    onSurface          = Color(0xFFF5E8E6),
    surfaceVariant     = Color(0xFF4A2520),
    onSurfaceVariant   = Red100,

    outline            = Color(0xFF7A4540),
    outlineVariant     = Color(0xFF5A3030),

    error              = ErrorRedDark,
    onError            = Color(0xFF690005),
    errorContainer     = Color(0xFF93000A),
    onErrorContainer   = Red100,

    inverseSurface     = Color(0xFFF5DDD9),
    inverseOnSurface   = Red800,
    inversePrimary     = Red600,

    scrim              = Red900.copy(alpha = 0.7f)
)


// Gradient background
private val LightGradient = Brush.verticalGradient(
    colors = listOf(
        Red050,
        Color(0xFFFCF6F5),
        WarmGray100
    )
)

private val DarkGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF2E1A17),
        Color(0xFF271410),
        Color(0xFF221210)
    )
)

@Composable
fun GloveworksBackground(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(brush = if (darkTheme) DarkGradient else LightGradient)
    ) {
        content()
    }
}


// Theme composable
@Composable
fun GloveworksTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colorScheme,
        content     = content
    )
}