package com.example.gloveworks50

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gloveworks50.auth.FirebaseAuthManager
import com.example.gloveworks50.data.FirebaseUploader
import com.example.gloveworks50.data.LocalStorage
import com.example.gloveworks50.data.UploadQueue
import com.example.gloveworks50.db.DatabaseDriverFactory
import com.example.gloveworks50.db.GloveworksRepository
import com.example.gloveworks50.screens.*

// Route constants
object Routes {
    const val HOME               = "home"
    const val GAIT_MONITOR       = "gait_monitor"
    const val GAIT_HISTORY       = "gait_history"
    const val VOICE_MONITOR      = "voice_monitor"
    const val VOICE_HISTORY      = "voice_history"
    const val GLOVE_CONTROL      = "glove_control"
    const val SYMPTOM_TRACKER    = "symptom_tracker"
    const val MEDICATION_TRACKER = "medication_tracker"
    const val SETTINGS           = "settings"
}

// App Navigation Host
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val scope         = rememberCoroutineScope()
    val repository    = remember { GloveworksRepository(DatabaseDriverFactory()) }

    // Shared UploadQueue instance
    val uploadQueue = remember {
        UploadQueue(
            storage     = LocalStorage(),
            repository  = repository,
            uploader    = FirebaseUploader(),
            authManager = FirebaseAuthManager()
        )
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        uploadQueue.flushAsync(scope)
    }

    val exitApp = getExitHandler()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onExit     = exitApp,
                onNavigate = { title ->
                    when (title) {
                        "Gait Monitor"       -> navController.navigate(Routes.GAIT_MONITOR)
                        "Voice Monitor"      -> navController.navigate(Routes.VOICE_MONITOR)
                        "Glove Control"      -> navController.navigate(Routes.GLOVE_CONTROL)
                        "Symptom Tracker"    -> navController.navigate(Routes.SYMPTOM_TRACKER)
                        "Medication Tracker" -> navController.navigate(Routes.MEDICATION_TRACKER)
                        "Settings"           -> navController.navigate(Routes.SETTINGS)
                    }
                }
            )
        }
        composable(Routes.GAIT_MONITOR) {
            GaitMonitorScreen(
                repository  = repository,
                uploadQueue = uploadQueue,
                onBack      = { navController.popBackStack() },
                onHistory   = { navController.navigate(Routes.GAIT_HISTORY) }
            )
        }
        composable(Routes.GAIT_HISTORY) {
            GaitHistoryScreen(repository = repository, onBack = { navController.popBackStack() })
        }
        composable(Routes.VOICE_MONITOR) {
            VoiceMonitorScreen(
                repository  = repository,
                uploadQueue = uploadQueue,
                onBack      = { navController.popBackStack() },
                onHistory   = { navController.navigate(Routes.VOICE_HISTORY) }
            )
        }
        composable(Routes.VOICE_HISTORY) {
            VoiceHistoryScreen(repository = repository, onBack = { navController.popBackStack() })
        }
        composable(Routes.GLOVE_CONTROL) {
            GloveControlScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SYMPTOM_TRACKER) {
            SymptomTrackerScreen(
                repository  = repository,
                uploadQueue = uploadQueue,
                onBack      = { navController.popBackStack() }
            )
        }
        composable(Routes.MEDICATION_TRACKER) {
            MedicationTrackerScreen(
                repository  = repository,
                uploadQueue = uploadQueue,
                onBack      = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                repository  = repository,
                uploadQueue = uploadQueue,
                onBack      = { navController.popBackStack() }
            )
        }
    }
}

@Composable
expect fun getExitHandler(): () -> Unit