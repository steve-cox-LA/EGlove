package com.example.gloveworks50.auth


expect class FirebaseAuthManager() {
    val currentUid: String?
    suspend fun signInAnonymously(): String?
    suspend fun signOut()
}