package com.example.gloveworks50

import androidx.compose.runtime.Composable

@Composable
actual fun getExitHandler(): () -> Unit = {}