package com.example.gloveworks50.audio

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.get
import platform.AVFAudio.*
import platform.posix.INT16_MAX


@OptIn(ExperimentalForeignApi::class)
actual class AudioRecorder actual constructor() {

    private val engine = AVAudioEngine()

    actual var isRecording: Boolean = false
        private set

    actual fun start(onAudioData: (samples: ShortArray) -> Unit) {
        if (isRecording) return

        try {
            val session = AVAudioSession.sharedInstance()
            session.setCategory(AVAudioSessionCategoryRecord, error = null)
            session.setPreferredSampleRate(44100.0, error = null)
            session.setActive(true, error = null)

            val inputNode = engine.inputNode

            // Use the hardware's native format — never hardcode the sample rate
            val hardwareFormat = inputNode.inputFormatForBus(0u)

            inputNode.installTapOnBus(
                bus = 0u,
                bufferSize = 4096u,
                format = hardwareFormat
            ) { buffer, _ ->
                buffer ?: return@installTapOnBus
                val channelData = buffer.floatChannelData ?: return@installTapOnBus
                val frameCount = buffer.frameLength.toInt()

                val channel = channelData[0] ?: return@installTapOnBus
                val shorts = ShortArray(frameCount) { i ->
                    val sample = channel[i]
                    (sample * INT16_MAX).toInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        .toShort()
                }
                onAudioData(shorts)
            }

            engine.prepare()
            engine.startAndReturnError(null)
            isRecording = true

        } catch (e: Exception) {
            isRecording = false
        }
    }

    actual fun stop() {
        isRecording = false
        try {
            engine.inputNode.removeTapOnBus(0u)
            engine.stop()
            AVAudioSession.sharedInstance().setActive(false, error = null)
        } catch (_: Exception) {}
    }
}