package com.example.gloveworks50.data

import platform.Foundation.NSLog


actual class DataUploader actual constructor() {

    actual suspend fun uploadGaitSession(session: GaitSession): Result<Unit> {
        return try {
            NSLog("DataUploader: Gait session ${session.sessionId} ready. " +
                    "Avg freq: ${session.averageDominantFrequencyHz} Hz, ${session.epochs.size} epochs.")
            Result.success(Unit)
        } catch (e: Exception) {
            NSLog("DataUploader: Gait upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadVoiceSession(session: VoiceSession): Result<Unit> {
        return try {
            NSLog("DataUploader: Voice session ${session.sessionId} ready. " +
                    "Avg RMS: ${session.averageRms}, ${session.epochs.size} epochs.")
            Result.success(Unit)
        } catch (e: Exception) {
            NSLog("DataUploader: Voice upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadUserProfile(profile: UserProfile): Result<Unit> {
        return try {
            NSLog("DataUploader: User profile ${profile.userId} ready. Type: ${profile.userType}")
            Result.success(Unit)
        } catch (e: Exception) {
            NSLog("DataUploader: Profile upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadSymptomSubmission(submission: SymptomSubmission): Result<Unit> {
        return try {
            NSLog("DataUploader: Symptom submission ${submission.submissionId} ready. " +
                    "Category: ${submission.category}, ${submission.entries.size} answers.")
            Result.success(Unit)
        } catch (e: Exception) {
            NSLog("DataUploader: Symptom upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadMedicationEntry(entry: MedicationHistoryEntry): Result<Unit> {
        return try {
            NSLog("DataUploader: Medication entry ${entry.timestampMs} ready. " +
                    "${entry.medications.size} medication(s): " +
                    entry.medications.joinToString { it.name })
            Result.success(Unit)
        } catch (e: Exception) {
            NSLog("DataUploader: Medication upload failed: ${e.message}")
            Result.failure(e)
        }
    }
}