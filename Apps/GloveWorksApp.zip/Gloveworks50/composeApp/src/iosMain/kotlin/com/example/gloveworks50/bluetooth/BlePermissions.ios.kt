package com.example.gloveworks50.bluetooth

import platform.CoreBluetooth.CBCentralManager
import platform.CoreBluetooth.CBManagerAuthorizationAllowedAlways
import platform.CoreBluetooth.CBManagerAuthorizationDenied
import platform.CoreBluetooth.CBManagerAuthorizationNotDetermined
import platform.CoreBluetooth.CBManagerAuthorizationRestricted


actual class BlePermission actual constructor() {

    actual fun isGranted(): Boolean {
        return when (CBCentralManager.authorization) {
            CBManagerAuthorizationAllowedAlways -> true
            CBManagerAuthorizationDenied,
            CBManagerAuthorizationRestricted -> false
            CBManagerAuthorizationNotDetermined -> false
            else -> false
        }
    }

    actual fun request(onResult: (granted: Boolean) -> Unit) {
        onResult(isGranted())
    }
}