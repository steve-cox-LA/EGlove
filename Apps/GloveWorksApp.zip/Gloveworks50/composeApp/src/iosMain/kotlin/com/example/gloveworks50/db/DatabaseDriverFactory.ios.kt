package com.example.gloveworks50.db

import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.native.NativeSqliteDriver

actual class DatabaseDriverFactory actual constructor() {
    actual fun createDriver(): SqlDriver {
        return NativeSqliteDriver(
            schema = GloveworksDatabase.Schema,
            name   = "gloveworks.db"
        )
    }
}