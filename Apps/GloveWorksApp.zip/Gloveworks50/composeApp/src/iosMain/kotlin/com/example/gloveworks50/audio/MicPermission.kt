package com.example.gloveworks50.audio

import platform.AVFAudio.AVAudioSession
import platform.AVFAudio.AVAudioSessionRecordPermissionGranted


actual class MicPermission actual constructor() {

    actual fun isGranted(): Boolean {
        return AVAudioSession.Companion.sharedInstance().recordPermission ==
                AVAudioSessionRecordPermissionGranted
    }

    actual fun request(onResult: (granted: Boolean) -> Unit) {
        if (isGranted()) {
            onResult(true)
            return
        }
        AVAudioSession.Companion.sharedInstance().requestRecordPermission { granted ->
            onResult(granted)
        }
    }
}