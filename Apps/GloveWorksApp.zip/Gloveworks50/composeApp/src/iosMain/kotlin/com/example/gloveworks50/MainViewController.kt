package com.example.gloveworks50

import androidx.compose.ui.window.ComposeUIViewController
import com.example.gloveworks50.ui.GloveworksBackground
import com.example.gloveworks50.ui.GloveworksTheme

fun MainViewController() = ComposeUIViewController {
    GloveworksTheme {
        GloveworksBackground {
            AppNavigation()
        }
    }
}