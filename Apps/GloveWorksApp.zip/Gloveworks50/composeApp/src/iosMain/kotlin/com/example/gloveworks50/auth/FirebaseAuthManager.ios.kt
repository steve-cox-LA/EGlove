package com.example.gloveworks50.auth

import dev.gitlive.firebase.Firebase
import dev.gitlive.firebase.auth.auth


actual class FirebaseAuthManager actual constructor() {

    private val auth get() = Firebase.auth

    actual val currentUid: String?
        get() = auth.currentUser?.uid

    actual suspend fun signInAnonymously(): String? {
        return try {
            auth.currentUser?.uid ?: run {
                val result = auth.signInAnonymously()
                result.user?.uid
            }
        } catch (e: Exception) {
            null
        }
    }

    actual suspend fun signOut() {
        try {
            auth.signOut()
        } catch (_: Exception) {}
    }
}