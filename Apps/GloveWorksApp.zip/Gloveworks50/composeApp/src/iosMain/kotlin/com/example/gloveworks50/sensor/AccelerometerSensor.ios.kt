package com.example.gloveworks50.sensor

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import platform.CoreMotion.CMMotionManager
import platform.Foundation.NSOperationQueue


@OptIn(ExperimentalForeignApi::class)
actual class AccelerometerSensor actual constructor() {

    private val motionManager = CMMotionManager()

    actual fun start(onData: (x: Float, y: Float, z: Float) -> Unit) {
        if (!motionManager.accelerometerAvailable) return

        // 50 Hz = 0.02 second interval
        motionManager.accelerometerUpdateInterval = 0.02

        motionManager.startAccelerometerUpdatesToQueue(NSOperationQueue.mainQueue) { data, _ ->
            val acceleration = data?.acceleration ?: return@startAccelerometerUpdatesToQueue
            acceleration.useContents {
                onData(
                    (x * 9.81).toFloat(),
                    (y * 9.81).toFloat(),
                    (z * 9.81).toFloat()
                )
            }
        }
    }

    actual fun stop() {
        motionManager.stopAccelerometerUpdates()
    }
}