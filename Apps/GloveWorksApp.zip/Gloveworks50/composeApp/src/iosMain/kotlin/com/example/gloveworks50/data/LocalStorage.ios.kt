package com.example.gloveworks50.data

import platform.Foundation.NSUserDefaults


actual class LocalStorage actual constructor() {

    private val defaults = NSUserDefaults.standardUserDefaults

    actual fun putString(key: String, value: String) {
        defaults.setObject(value, forKey = key)
    }

    actual fun getString(key: String): String? {
        return defaults.stringForKey(key)
    }

    actual fun putBoolean(key: String, value: Boolean) {
        defaults.setBool(value, forKey = key)
    }

    actual fun getBoolean(key: String, default: Boolean): Boolean {
        return if (defaults.objectForKey(key) != null) {
            defaults.boolForKey(key)
        } else {
            default
        }
    }

    actual fun putInt(key: String, value: Int) {
        defaults.setInteger(value.toLong(), forKey = key)
    }

    actual fun getInt(key: String, default: Int): Int {
        return if (defaults.objectForKey(key) != null) {
            defaults.integerForKey(key).toInt()
        } else {
            default
        }
    }

    actual fun remove(key: String) {
        defaults.removeObjectForKey(key)
    }

    actual fun clear() {
        // Explicit key list — Kotlin reflection is not supported in Kotlin/Native
        listOf(
            StorageKeys.USER_ID,
            StorageKeys.USER_TYPE,
            StorageKeys.USER_NAME,
            StorageKeys.USER_LAST_NAME,
            StorageKeys.USER_EMAIL,
            StorageKeys.USER_DOB,
            StorageKeys.USER_PHONE,
            StorageKeys.USER_PDQ,
            StorageKeys.SHARE_MOTION,
            StorageKeys.SHARE_VOICE,
            StorageKeys.USER_AGE,
            StorageKeys.DIAGNOSED_PD,
            StorageKeys.MOTION_SESSION_ID,
            StorageKeys.VOICE_SESSION_ID,
            StorageKeys.GLOVE_PIN,
            StorageKeys.GLOVE_MOTOR_AMP,
            StorageKeys.GLOVE_PATTERN_DUR,
            StorageKeys.GLOVE_BURST_DUR
        ).forEach { defaults.removeObjectForKey(it) }
    }
}