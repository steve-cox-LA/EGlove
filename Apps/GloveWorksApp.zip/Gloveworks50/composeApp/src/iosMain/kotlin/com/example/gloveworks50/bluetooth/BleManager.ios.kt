package com.example.gloveworks50.bluetooth

import androidx.compose.runtime.*
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.usePinned
import platform.CoreBluetooth.*
import platform.Foundation.*
import platform.darwin.NSObject


actual class BleManager actual constructor() {

    actual var devices: List<BleDevice> by mutableStateOf(emptyList())
        private set
    actual var isConnected: Boolean by mutableStateOf(false)
        private set
    actual var statusText: String by mutableStateOf("Disconnected")
        private set

    private var connectedPeripheral: CBPeripheral? = null
    private var targetServiceUuid: String? = null
    private var pendingScan: Boolean = false
    private val discoveredPeripherals = mutableListOf<CBPeripheral>()
    private val characteristicCache = mutableMapOf<String, CBCharacteristic>()
    private val pendingWrites = mutableListOf<Triple<String, String, Int>>()

    private val delegate = BleDelegate()
    private val centralManager: CBCentralManager

    init {
        delegate.onStateChanged = { state ->
            when (state) {
                CBManagerStatePoweredOn -> {
                    statusText = "Bluetooth ready"
                    if (pendingScan) {
                        pendingScan = false
                        targetServiceUuid?.let { startScanInternal(it) }
                    }
                }
                CBManagerStatePoweredOff     -> statusText = "Bluetooth is off"
                CBManagerStateUnauthorized   -> statusText = "Bluetooth not authorized"
                CBManagerStateUnsupported    -> statusText = "Bluetooth not supported"
                else                         -> statusText = "Bluetooth unavailable"
            }
        }

        delegate.onDeviceFound = { peripheral ->
            if (discoveredPeripherals.none {
                    it.identifier.UUIDString == peripheral.identifier.UUIDString
                }) {
                discoveredPeripherals.add(peripheral)
                devices = discoveredPeripherals.map {
                    BleDevice(name = it.name, address = it.identifier.UUIDString)
                }
            }
        }

        delegate.onConnected = { peripheral ->
            connectedPeripheral = peripheral
            statusText = "Discovering services..."
            targetServiceUuid?.let { uuid ->
                peripheral.discoverServices(listOf(CBUUID.UUIDWithString(uuid)))
            }
        }

        delegate.onDisconnected = {
            connectedPeripheral?.delegate = null
            connectedPeripheral = null
            isConnected = false
            statusText = "Disconnected"
            characteristicCache.clear()
            pendingWrites.clear()
        }

        delegate.onScanFailed = { error ->
            statusText = "Scan failed: $error"
        }
        delegate.onCharacteristicDiscovered = { uuid, characteristic ->
            characteristicCache[uuid.uppercase()] = characteristic
        }
        delegate.onDiscoveryComplete = {
            isConnected = true
            statusText = "Connected"
            flushPendingWrites()
        }

        centralManager = CBCentralManager(delegate, null)
    }

    //Scan

    actual fun startScan(serviceUuid: String) {
        targetServiceUuid = serviceUuid
        devices = emptyList()
        discoveredPeripherals.clear()

        if (centralManager.state == CBManagerStatePoweredOn) {
            startScanInternal(serviceUuid)
        } else {
            pendingScan = true
            statusText = "Waiting for Bluetooth..."
        }
    }

    private fun startScanInternal(serviceUuid: String) {
        val uuids = listOf(CBUUID.UUIDWithString(serviceUuid))
        centralManager.scanForPeripheralsWithServices(uuids, null)
        statusText = "Scanning..."
    }

    actual fun stopScan() {
        centralManager.stopScan()
        pendingScan = false
        if (!isConnected) statusText = "Disconnected"
    }

    //Connect

    actual fun connectByIndex(index: Int) {
        if (index !in discoveredPeripherals.indices) return
        stopScan()
        pendingWrites.clear()
        characteristicCache.clear()
        val peripheral = discoveredPeripherals[index]
        statusText = "Connecting..."
        centralManager.connectPeripheral(peripheral, null)
    }

    //Disconnect

    actual fun disconnect() {
        pendingWrites.clear()
        connectedPeripheral?.let {
            it.delegate = null
            centralManager.cancelPeripheralConnection(it)
        }
        connectedPeripheral = null
        isConnected = false
        statusText = "Disconnected"
        characteristicCache.clear()
        discoveredPeripherals.clear()
        devices = emptyList()
        pendingScan = false
    }

    //Write

    @OptIn(ExperimentalForeignApi::class)
    actual fun writeIntAsString(serviceUuid: String, characteristicUuid: String, value: Int) {
        val peripheral = connectedPeripheral ?: return
        val key = characteristicUuid.uppercase()
        val characteristic = characteristicCache[key]

        if (characteristic == null) {
            pendingWrites.removeAll { it.second == key }
            pendingWrites.add(Triple(serviceUuid, key, value))
            return
        }

        doWrite(peripheral, characteristic, value)
    }

    @OptIn(ExperimentalForeignApi::class)
    private fun doWrite(peripheral: CBPeripheral, characteristic: CBCharacteristic, value: Int) {
        val bytes = value.toString().encodeToByteArray()
        val data = bytes.toNSData()
        peripheral.writeValue(
            data,
            forCharacteristic = characteristic,
            type = CBCharacteristicWriteWithResponse
        )
    }

    //Flush pending writes

    @OptIn(ExperimentalForeignApi::class)
    private fun flushPendingWrites() {
        val peripheral = connectedPeripheral ?: return
        val snapshot = pendingWrites.toList()
        pendingWrites.clear()
        for ((_, charUuid, value) in snapshot) {
            val characteristic = characteristicCache[charUuid] ?: continue
            doWrite(peripheral, characteristic, value)
        }
    }

    //Close

    actual fun close() {
        disconnect()
    }
}

// ByteArray → NSData
@OptIn(ExperimentalForeignApi::class)
private fun ByteArray.toNSData(): NSData = this.usePinned { pinned ->
    NSData.create(
        bytes = pinned.addressOf(0),
        length = this.size.toULong()
    )
}

// CoreBluetooth delegate
private class BleDelegate : NSObject(),
    CBCentralManagerDelegateProtocol,
    CBPeripheralDelegateProtocol {

    var onStateChanged: ((CBManagerState) -> Unit)? = null
    var onDeviceFound: ((CBPeripheral) -> Unit)? = null
    var onConnected: ((CBPeripheral) -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    var onScanFailed: ((String) -> Unit)? = null
    var onCharacteristicDiscovered: ((String, CBCharacteristic) -> Unit)? = null
    var onDiscoveryComplete: (() -> Unit)? = null
    private var pendingServiceCount = 0

    override fun centralManagerDidUpdateState(central: CBCentralManager) {
        onStateChanged?.invoke(central.state)
    }

    override fun centralManager(
        central: CBCentralManager,
        didDiscoverPeripheral: CBPeripheral,
        advertisementData: Map<Any?, *>,
        RSSI: NSNumber
    ) {
        didDiscoverPeripheral.delegate = this
        onDeviceFound?.invoke(didDiscoverPeripheral)
    }

    override fun centralManager(
        central: CBCentralManager,
        didConnectPeripheral: CBPeripheral
    ) {
        pendingServiceCount = 0
        onConnected?.invoke(didConnectPeripheral)
    }

    override fun centralManager(
        central: CBCentralManager,
        didDisconnectPeripheral: CBPeripheral,
        error: NSError?
    ) {
        onDisconnected?.invoke()
    }
    override fun peripheral(
        peripheral: CBPeripheral,
        didDiscoverServices: NSError?
    ) {
        val services = peripheral.services ?: return
        pendingServiceCount = services.size
        if (pendingServiceCount == 0) {
            onDiscoveryComplete?.invoke()
            return
        }
        services.forEach { service ->
            val cbService = service as? CBService ?: run {
                pendingServiceCount--
                if (pendingServiceCount == 0) onDiscoveryComplete?.invoke()
                return@forEach
            }
            peripheral.discoverCharacteristics(null, forService = cbService)
        }
    }
    override fun peripheral(
        peripheral: CBPeripheral,
        didDiscoverCharacteristicsForService: CBService,
        error: NSError?
    ) {
        didDiscoverCharacteristicsForService.characteristics?.forEach { char ->
            val cbChar = char as? CBCharacteristic ?: return@forEach
            onCharacteristicDiscovered?.invoke(
                cbChar.UUID.UUIDString.uppercase(),
                cbChar
            )
        }
        pendingServiceCount--
        if (pendingServiceCount == 0) {
            onDiscoveryComplete?.invoke()
        }
    }
}