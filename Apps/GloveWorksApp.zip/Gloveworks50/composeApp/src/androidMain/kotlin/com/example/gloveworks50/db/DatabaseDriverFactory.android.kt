package com.example.gloveworks50.db

import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.android.AndroidSqliteDriver
import com.example.gloveworks50.sensor.AppContextHolder


actual class DatabaseDriverFactory actual constructor() {
    actual fun createDriver(): SqlDriver {
        val context = AppContextHolder.context
            ?: error("AppContextHolder not initialized. Call AppContextHolder.init(context) in MainActivity.onCreate()")
        return AndroidSqliteDriver(
            schema   = GloveworksDatabase.Schema,
            context  = context,
            name     = "gloveworks.db",
            callback = AndroidSqliteDriver.Callback(GloveworksDatabase.Schema)
        )
    }
}