package com.example.gloveworks50.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager


actual class AccelerometerSensor actual constructor() {

    private var sensorManager: SensorManager? = null
    private var listener: SensorEventListener? = null

    actual fun start(onData: (x: Float, y: Float, z: Float) -> Unit) {
        val context = AppContextHolder.context
            ?: error("AppContextHolder not initialized. Call AppContextHolder.init(context) in MainActivity.onCreate()")

        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val accelerometer = sensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            ?: return

        listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let { onData(it.values[0], it.values[1], it.values[2]) }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        // Request 50 Hz — 20000 microseconds sampling period
        sensorManager!!.registerListener(
            listener,
            accelerometer,
            20000,   // samplingPeriodUs = 20ms = 50 Hz
            0
        )
    }

    actual fun stop() {
        listener?.let { sensorManager?.unregisterListener(it) }
        listener = null
        sensorManager = null
    }
}