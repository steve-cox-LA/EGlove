package com.example.gloveworks50.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.os.Build
import android.os.ParcelUuid
import androidx.compose.runtime.*
import com.example.gloveworks50.sensor.AppContextHolder
import java.nio.charset.Charset
import java.util.UUID


actual class BleManager actual constructor() {

    private val context get() = AppContextHolder.context
        ?: error("AppContextHolder not initialized")

    private val bluetoothManager by lazy {
        context.getSystemService(android.content.Context.BLUETOOTH_SERVICE) as BluetoothManager
    }
    private val adapter: BluetoothAdapter? get() = bluetoothManager.adapter
    private val scanner: BluetoothLeScanner? get() = adapter?.bluetoothLeScanner
    private var gatt: BluetoothGatt? = null
    private var connectedDevice: BluetoothDevice? = null
    private val pendingWrites = mutableListOf<Triple<String, String, Int>>()
    actual var devices: List<BleDevice> by mutableStateOf(emptyList())
        private set
    actual var isConnected: Boolean by mutableStateOf(false)
        private set
    actual var statusText: String by mutableStateOf("Disconnected")
        private set

    @SuppressLint("MissingPermission")
    actual fun startScan(serviceUuid: String) {
        statusText = "Scanning..."
        devices = emptyList()
        _androidDevices.clear()

        val s = scanner ?: run {
            statusText = "Bluetooth not available"
            return
        }

        val filters = listOf(
            ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(UUID.fromString(serviceUuid)))
                .build()
        )
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        s.startScan(filters, settings, scanCallback)
    }

    @SuppressLint("MissingPermission")
    actual fun stopScan() {
        scanner?.stopScan(scanCallback)
        if (!isConnected) statusText = "Disconnected"
    }

    // ── Connect ───────────────────────────────────────────────────────────────

    actual fun connectByIndex(index: Int) {
        if (index !in devices.indices) return
        stopScan()
        connectDevice(index)
    }

    @SuppressLint("MissingPermission")
    private fun connectDevice(index: Int) {
        if (index !in _androidDevices.indices) return
        val device = _androidDevices[index]
        connectedDevice = device
        statusText = "Connecting..."
        pendingWrites.clear()
        gatt?.close()
        gatt = device.connectGatt(context, false, gattCallback)
    }

    // ── Disconnect ────────────────────────────────────────────────────────────

    @SuppressLint("MissingPermission")
    actual fun disconnect() {
        stopScan()
        pendingWrites.clear()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        connectedDevice = null
        isConnected = false
        statusText = "Disconnected"
    }

    // ── Write ─────────────────────────────────────────────────────────────────

    @SuppressLint("MissingPermission")
    actual fun writeIntAsString(serviceUuid: String, characteristicUuid: String, value: Int) {
        val g = gatt ?: return

        val service = g.getService(UUID.fromString(serviceUuid))
        if (service == null) {
            // Services not discovered yet — queue and replay later
            pendingWrites.removeAll { it.second == characteristicUuid }
            pendingWrites.add(Triple(serviceUuid, characteristicUuid, value))
            return
        }

        val ch = service.getCharacteristic(UUID.fromString(characteristicUuid)) ?: return
        doWrite(g, ch, value)
    }

    @SuppressLint("MissingPermission")
    private fun doWrite(g: BluetoothGatt, ch: BluetoothGattCharacteristic, value: Int) {
        val bytes = value.toString().toByteArray(Charset.forName("UTF-8"))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
        } else {
            @Suppress("DEPRECATION")
            ch.value = bytes
            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            @Suppress("DEPRECATION")
            g.writeCharacteristic(ch)
        }
    }

    // ── Close ─────────────────────────────────────────────────────────────────

    actual fun close() {
        disconnect()
    }

    // ── Internal device list ──────────────────────────────────────────────────

    private val _androidDevices = mutableListOf<BluetoothDevice>()

    // ── Scan callback ─────────────────────────────────────────────────────────

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            if (_androidDevices.none { it.address == device.address }) {
                _androidDevices.add(device)
                devices = _androidDevices.map {
                    BleDevice(
                        name = try { it.name } catch (_: SecurityException) { null },
                        address = it.address
                    )
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            statusText = "Scan failed: $errorCode"
        }
    }

    // ── GATT callback ─────────────────────────────────────────────────────────

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                // Don't set isConnected yet — wait for service discovery.
                // The UI sliders stay disabled until services are ready.
                statusText = "Discovering services..."
                gatt.discoverServices()
            } else {
                isConnected = false
                statusText = "Disconnected"
                pendingWrites.clear()
                try { gatt.close() } catch (_: Exception) {}
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // NOW it is safe to mark connected and flush any queued writes
                isConnected = true
                statusText = "Connected"
                flushPendingWrites(gatt)
            } else {
                statusText = "Service discovery failed ($status)"
                isConnected = false
                gatt.close()
            }
        }
    }

    // ── Flush pending writes after discovery ──────────────────────────────────

    @SuppressLint("MissingPermission")
    private fun flushPendingWrites(g: BluetoothGatt) {
        val snapshot = pendingWrites.toList()
        pendingWrites.clear()
        for ((svcUuid, charUuid, value) in snapshot) {
            val service = g.getService(UUID.fromString(svcUuid)) ?: continue
            val ch = service.getCharacteristic(UUID.fromString(charUuid)) ?: continue
            doWrite(g, ch, value)
        }
    }
}