package com.example.gloveworks50.data

import android.util.Log


actual class DataUploader actual constructor() {

    actual suspend fun uploadGaitSession(session: GaitSession): Result<Unit> {
        return try {
            Log.d("DataUploader", "Gait session ${session.sessionId} ready. " +
                    "Avg freq: ${session.averageDominantFrequencyHz} Hz, ${session.epochs.size} epochs.")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("DataUploader", "Gait upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadVoiceSession(session: VoiceSession): Result<Unit> {
        return try {
            Log.d("DataUploader", "Voice session ${session.sessionId} ready. " +
                    "Avg RMS: ${session.averageRms}, ${session.epochs.size} epochs.")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("DataUploader", "Voice upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadUserProfile(profile: UserProfile): Result<Unit> {
        return try {
            Log.d("DataUploader", "User profile ${profile.userId} ready. Type: ${profile.userType}")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("DataUploader", "Profile upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadSymptomSubmission(submission: SymptomSubmission): Result<Unit> {
        return try {
            Log.d("DataUploader", "Symptom submission ${submission.submissionId} ready. " +
                    "Category: ${submission.category}, ${submission.entries.size} answers.")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("DataUploader", "Symptom upload failed: ${e.message}")
            Result.failure(e)
        }
    }

    actual suspend fun uploadMedicationEntry(entry: MedicationHistoryEntry): Result<Unit> {
        return try {
            Log.d("DataUploader", "Medication entry ${entry.timestampMs} ready. " +
                    "${entry.medications.size} medication(s): " +
                    entry.medications.joinToString { it.name })
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("DataUploader", "Medication upload failed: ${e.message}")
            Result.failure(e)
        }
    }
}