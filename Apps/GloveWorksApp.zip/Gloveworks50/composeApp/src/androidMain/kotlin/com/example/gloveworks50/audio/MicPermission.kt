package com.example.gloveworks50.audio

import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.example.gloveworks50.MicPermissionCallback
import com.example.gloveworks50.sensor.AppContextHolder


actual class MicPermission actual constructor() {

    actual fun isGranted(): Boolean {
        val context = AppContextHolder.context ?: return false
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    actual fun request(onResult: (granted: Boolean) -> Unit) {
        if (isGranted()) {
            onResult(true)
            return
        }

        val launcher = AppContextHolder.micPermissionLauncher ?: run {
            onResult(false)
            return
        }

        MicPermissionCallback.set(onResult)
        launcher.launch(Manifest.permission.RECORD_AUDIO)
    }
}