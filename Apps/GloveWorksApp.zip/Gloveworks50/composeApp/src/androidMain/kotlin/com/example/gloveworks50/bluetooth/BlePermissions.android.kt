package com.example.gloveworks50.bluetooth

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.gloveworks50.BlePermissionCallback
import com.example.gloveworks50.sensor.AppContextHolder


actual class BlePermission actual constructor() {

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    actual fun isGranted(): Boolean {
        val context = AppContextHolder.context ?: return false
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    actual fun request(onResult: (granted: Boolean) -> Unit) {
        if (isGranted()) {
            onResult(true)
            return
        }

        val launcher = AppContextHolder.blePermissionLauncher ?: run {
            onResult(false)
            return
        }

        BlePermissionCallback.set(onResult)
        launcher.launch(requiredPermissions)
    }
}