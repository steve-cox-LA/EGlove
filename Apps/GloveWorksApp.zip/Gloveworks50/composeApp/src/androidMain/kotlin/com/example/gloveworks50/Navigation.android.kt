package com.example.gloveworks50

import androidx.activity.ComponentActivity
import androidx.compose.runtime.Composable
import com.example.gloveworks50.sensor.AppContextHolder


@Composable
actual fun getExitHandler(): () -> Unit {
    val activity = AppContextHolder.context as? ComponentActivity
    return { activity?.moveTaskToBack(true) }
}