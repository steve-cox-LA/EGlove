package com.example.gloveworks50.sensor

import android.content.Context
import androidx.activity.result.ActivityResultLauncher


object AppContextHolder {
    var context: Context? = null
        private set
    var blePermissionLauncher: ActivityResultLauncher<Array<String>>? = null
    var micPermissionLauncher: ActivityResultLauncher<String>? = null

    fun init(context: Context) {
        this.context = context.applicationContext
    }
}