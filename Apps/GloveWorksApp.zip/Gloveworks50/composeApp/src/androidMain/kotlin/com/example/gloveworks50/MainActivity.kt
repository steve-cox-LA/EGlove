package com.example.gloveworks50

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.example.gloveworks50.sensor.AppContextHolder
import com.example.gloveworks50.ui.GloveworksBackground
import com.example.gloveworks50.ui.GloveworksTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        AppContextHolder.init(this)

        // Register BLE permission launcher before setContent
        AppContextHolder.blePermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { results ->
            BlePermissionCallback.invoke(results.values.all { it })
        }

        // Register mic permission launcher before setContent
        AppContextHolder.micPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            MicPermissionCallback.invoke(granted)
        }

        setContent {
            GloveworksTheme {
                GloveworksBackground {
                    AppNavigation()
                }
            }
        }
    }
}

// Permission callback holders

object BlePermissionCallback {
    private var callback: ((Boolean) -> Unit)? = null
    fun set(cb: (Boolean) -> Unit) { callback = cb }
    fun invoke(granted: Boolean) { callback?.invoke(granted); callback = null }
}

object MicPermissionCallback {
    private var callback: ((Boolean) -> Unit)? = null
    fun set(cb: (Boolean) -> Unit) { callback = cb }
    fun invoke(granted: Boolean) { callback?.invoke(granted); callback = null }
}